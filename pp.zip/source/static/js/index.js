var Index = function() {
	return this;
}

Index.prototype = {
	init: function() {
		this.pageinit();
		this.getNotice();
	},
	pageinit: function() {
		var _this = this;
		//首页接口 合并后的home接口，包含banner和首页产品
		GHutils.load({
			url: "/actives1/public/V1home",
			data: {
				"getBanner": true,
				"getProductList": true
			},
			type: "post",
			async: false,
			callback: function(result) {
				
				_this.forBanner(result);
				//添加在首页加载产品 product
				_this.forProduct(result.data.product.rows);
			}
		});
		
		//加载基金产品
		// var fund = "";
		// var buys = "";
		// var fund_url="http://www.erichfund.com/wallet/sumofnav2wallet.js";
		// $.ajax({
		// 	url: location.host=='www.zhangyuelicai.com'?'/static/js/sumofnav2wallet.js':fund_url,
		// 	dataType: "script",
		// 	cache: true
		// }).done(function() {
		// 	var fundest = sumofnav;
		// 	fundest += '<span class="f_18">%</span>';
		// 	var num = (sumofnav / 100 * 10000 / 365 * 7).toString().match(new RegExp("\\d+\\.\\d{" + 4 + "}", "gm"));
		// 	buys += '<span class="khb_buy buttom_border_redius"><a href="http://www.erichfund.com" rel="nofollow" target="view_window">立即抢购</a></span>';
		// 	fund += '<div class="clearfix newProduct_t0"><p><h2>长量钱包</h2><div class="row"><div class="col-md-2 zxb_col" style="text-align:left;margin-right:80px;"><span class="font1_span">' + fundest + '</span><p>七日年化收益率</p></div><div class="col-md-2 col-md-2_5"><span class="font_span">1.00<em>元</em></span><p>起投金额</p></div><div class="col-md-2" style="margin-left:120px"><span class="font_span">' + num + '<em>元</em></span><p>七日平均万元收益</p></div><div class="col-md-2"></div><div class="khb_buyf1">' + buys + '</div></div></p></div>'
		// 	$("#funds").html(fund);
		// });
		//加载资讯分类
		this.getInfomation();
	},
	forProduct:function(resultProducts){
		var _this=this;
		var recommendObj = {};
		var tnlist = "";
		var tnlistLen = 0;
		var t0listLen = 1;
		for(var i = 0; i < resultProducts.length; i++) {
			if(resultProducts[i].productType == "REGULAR") {
				if(tnlistLen < 3) {
					tnlist += _this.protnlist(resultProducts[i])
				}
				tnlistLen++;
			}
			if(resultProducts[i].productType == "CURRENT") {
				if(t0listLen == 1) {
					$('#index_product_t0').html('<div class="product-title"><span class="titles">掌薪宝</span><a href="product-t0.html"class="mores">查看更多&gt;</a></div><ul>'+_this.prot0list(resultProducts[i])+'</ul>')
					t0listLen++;
				}
			}
		}
		if(tnlist){
			tnlist='<div class="product-title"><span class="titles">定期产品</span><a href="product-tn-list.html"class="mores">查看更多&gt;</a></div><ul class="newProduct_tn">'+tnlist+'</ul>'
			$('#index_product_tn').html(tnlist);
			$("#index_product_tn .newProduct_tn>li").each(function() {
				if($(this).find("h2").width() < $(this).find(".proname").width() + $(this).find(".bqscon").width()) {
					$(this).find(".bqscon").css("display", "block");
					$(this).find("h2").css("marginBottom", "26px");
				}
			})
			_this.bindEvent()
		}
	},
	forBanner:function(result){
		var _this=this;
		//banner 
		var bannerHtml = '';
		var indicatorHtml = '';
		if(result.code != 10000) {
			bannerHtml += '<div style="text-align:center"><img src="static/images/banner-def.png" alt=""></div>'
			$(".carousel-control").addClass("none")
			$("#carousel-example-generic").remove()
			$("#annual-yidld").before(bannerHtml)
			return;
		} else {
			var banner = result.data.banner;		
			if(banner && banner.rows && banner.rows.length > 0) {
				var banners=banner.rows;
				for(var i in banners) {
					var imageUrl = banners[i].imageUrl || "";
					var linkUrl = banners[i].linkUrl || "";
					var title = banners[i].title || "";
					var isLink = banners[i].isLink || ""; //0链接 1:跳转
					var toPage = banners[i].toPage || ""; //T1:理财 T2:加薪宝
					var _imgname = banners[i].imageUrl.split("/")[2] || "";
					var relativePath = HOST + imageUrl || "";
					var onlineUrl = HOST + imageUrl || "";
					var indicatorActive = '';
					var cp = linkUrl == "" ? "" : "cp"
					if(i == 0) {
						bannerHtml += '<div class="item active item-link ' + cp + '" data-topage="' + toPage + '" data-url="' + linkUrl + '" style="background-image:url(' + relativePath + ')"></div>'
						indicatorHtml += '<li data-target="#carousel-example-generic" data-slide-to="' + i + '" class="active"></li>'
					} else {
						bannerHtml += '<div class="lazy item  item-link ' + cp + '" data-topage="' + toPage + '" data-url="' + linkUrl + '" data-src="' + relativePath + '"></div>'
						indicatorHtml += '<li data-target="#carousel-example-generic" data-slide-to="' + i + '" class=""></li>'
					}
				}
				$("#carousel-inner").html(bannerHtml)
				$("#carousel-indicators").html(indicatorHtml)


				$('#carousel-example-generic').bind('slid.bs.carousel', function() {
					lazyContainer0(this);
					setTimeout(function() {
						lazyContainer(this);
					}.bind(this), 2000)
				});
				lazyContainer0(this);
				setTimeout(function() {
					lazyContainer('#carousel-example-generic');
				}, 2000)
			} else {
				$(".carousel-control").addClass("none")
				$("#carousel-example-generic").remove()
				$("#annual-yidld").before(bannerHtml)
			}

			
			
		}
		
		function lazyContainer0(searchNode) {
			$(searchNode).find('.active.lazy').each(function() {
				var imgSrc = $(this).attr('data-src');
				if(imgSrc) {
					$(this).attr('style', 'background-image:url(' + imgSrc + ')');
					$(this).attr('data-src', '');
					$(this).removeClass('lazyok').addClass('lazy');
				}
			});
		}

		function lazyContainer(searchNode) {
			var idx = $(".item").index($(searchNode).find('.item.active'));
			var target;
			if(idx < $('.item').length - 1) {
				target = $('.item')[idx + 1];
			}
			var imgSrc = $(target).attr('data-src');
			if(imgSrc) {
				$(target).attr('style', 'background-image:url(' + imgSrc + ')');
				$(target).attr('data-src', '');
				$(target).removeClass('lazyok').addClass('lazy');
			}
		}
		
	},
	getNotice: function() {
		var _this = this;
		//公告中的数据加载
		GHutils.load({
			url: '/notice1/pc/index_top.json?r='+GHutils.getMinutesTimestamp(),
			type: "get",
			async: false,
			callback: function(result) {
				if(result.errorCode != 0) {
					$("#index_notice").html("暂无公告")
					return;
				} else {
					//公告
					if(result && result.rows.length > 0) {
						var htmls = '<ul>';
						for(var i = 0; i <= result.rows.length - 1; i++) {
							htmls += '<li><a href="/notice1/pc/index.html?r='+GHutils.getMinutesTimestamp()+'">' + result.rows[i].title + '</a></li>'
						}
						$("#index_notice").html(htmls + '</ul>').vTicker();

					} else {
						$("#index_notice").html("暂无公告")
					}

				}
			}
		});
	},
	getInfomation: function() {
		var _this = this;
		//加载资讯分类
		GHutils.load({
			url: "/information/mtjson/",
			data: {},
			type: "get",
			async: false,
			callback: function(result) {
				result.length > 0 && $("#left_information").html(_this.getDetail(result[0]));
				result.length > 1 && $("#right_information").html(_this.getDetail(result[1]))
			}
		});
	},
	getDetail: function(result) {
		//加载掌悦金融动态
		var newsHtml = '';

		for(var i in result) {
			newsHtml += '<li><a href="' + result[i].url + '" target="_blank"><span class="dot" style="float:left;"></span><span class="index_zyzx">' + result[i].title + '</span><span style="float: right;">' + result[i].inputtime + '</span></a></li>'
		}
		if(newsHtml == '') {
			newsHtml = '暂无资讯'
		}
		return newsHtml;
	},
	prot0list: function(product) {
		var products = '';
		var labels = "";
		
		var labelicon = '';
		for(var i in product.labelList) {
			var code = product.labelList[i].labelNo;
			var type = product.labelList[i].labelType;
			if(type == "extend") {
				labels += '<span>' + product.labelList[i].labelName + '</span>';
			}
			
		}
		var interest = GHutils.toFixeds(product.expAror, 2)
		var profit0 = ""
		interest+= '<span class="f_18">%</span>'
		if(product.rewardInterest&&(product.rewardInterest-0)){
			interest += '<span><span class="f_18">+</span>'+GHutils.toFixeds(product.rewardInterest, 2)+'<span class="f_18">%</span></span>'
			profit0 += '<div class="col-md-3 zxb_col"><span class="font1_span">'+interest+'</span><p style="position:relative"><span style="vertical-align:middle;">历史年化收益率</span><span class="incomehint4i" style="margin-left: 6px;"></span></p></div>'

		} else {
			profit0 += '<div class="col-md-2 zxb_col" style="text-align:left"><span class="font1_span">'+interest+'</span><p style="position:relative"><span style="vertical-align:middle;">历史年化收益率</span><span class="incomehint4i" style="margin-left: 6px;"></span></p></div>'

		}
		products += '<li class="clearfix newProduct_t0"><span class="new-icon">' + labelicon + '</span><h2>' + product.name + '&nbsp;' + labels + '</h2><div class="row">' + profit0 + '<div class="col-md-2 col-md-2_5"><span class="font_span"> ' +
		GHutils.formatCurrency(product.investMin == null ? "0" : product.investMin) + '<em>元</em></span><p>起投金额</p></div><div class="col-md-2"><span class="font_span"><em>' + product.paybackTypeName + '</em></span><p>收益方式</p></div><div class="col-md-2"><span class="font_span">' +
			(product.tenThousandIncome - 0).toFixed(2) + '<em>元</em></span><p>每万元收益</p></div><div class="khb_buyf1"><span class="khb_buy buttom_border_redius"><a  href="product-t0.html?productOid='+product.productOid+'">立即抢购</a></span></div></div></li>' //<a  class="asset-t0-invest" data-oid="'+product.productOid+'" href="javascript:;">立即抢购</a>
		return products;
	},
	protnlist: function(product) {
		var products = ''
		var labels = "";
		
		var labelicon = '';
		
		for(var i in product.labelList) {
			var code = product.labelList[i].labelNo;
			var type = product.labelList[i].labelType;

			if(product.generalLabels==1000506) {
				labelicon = '<img src="static/images/index_tnlist_icon1.png"/>'
			}

			if(type == "extend") {
				//循环图标
				if(product.labelList[i].labelName == '一锤定音') {
					labels += '<img title="一锤定音:此项目满标者可获惊喜红包" src="static/images/chuizi.png" height="20" style="padding:0 3px"/>'
				} else if(product.labelList[i].labelName == '一鸣惊人') {
					labels += '<img title="一鸣惊人:此项目单笔投资最高者可获惊喜红包" src="static/images/famous.png" height="20" style="padding:0 3px"/>'
				} else if(product.labelList[i].labelNo == 'A5') {
					labels += '<img title="投资惊喜:此产品成功投资有机会获得惊喜礼包" src="static/images/touzijinxi.png" height="20" style="padding:0 3px"/>'
				}
				//循环标签
				if(product.labelList[i].labelName != '一锤定音'&&product.labelList[i].labelName != '一鸣惊人'&&product.labelList[i].labelNo != 'A5') {
					labels += '<span>' + product.labelList[i].labelName + '</span>';
				}
			}
		}


		product.netUnitShare = 1;
		var amount = product.raisedTotalNumber
		var percent = Math.min(100, product.percent)
		if(percent === "100.00") {
			percent = 100;
		}

		if(amount > 100000000) {
			amount = GHutils.formatCurrency(amount / 100000000) + "<em>亿</em>";
		} else if(amount > 10000) {
			amount = GHutils.formatCurrency(amount / 10000) + "<em>万</em>";
		} else {
			amount = GHutils.formatCurrency(amount);
		}
		//根据金砖最新的收益率显示规则 0.00% 或 0.00%+0.00%。暂无区间收益。
		var interest = GHutils.toFixeds(product.expAror, 2)
		interest += '<span class="f_18">%</span>'
		if(product.rewardInterest) {
			interest += '<span><span class="f_18">+</span>' + GHutils.toFixeds(product.rewardInterest, 2) + '<span class="f_18">%</span></span>'
		}
		var gobuy = ''
		var pronone = '';
		var btnTxt = '';
		var enable = true;
		if(GHutils.getProductStatus(product.state)==1||(GHutils.Fmul(GHutils.Fsub(product.raisedTotalNumber , product.collectedVolume ), product.netUnitShare) - product.lockCollectedVolume - (product.investMin == null ? 0:product.investMin) < 0)){
			enable = false
			pronone = 'none';
			amount = '0.00'
			btnTxt = '已售罄';
		}else if(GHutils.getProductStatus(product.state)==-1){
			enable = false
			btnTxt = '预售';
		}else if(GHutils.getProductStatus(product.state)==0){
			enable = true
			btnTxt = '立即抢购';
		}
        var times = '';
        if(product.durationPeriodType == 'DAY') {
            times = '天';
        } else if(product.durationPeriodType == 'MONTH') {
            times = '月';
        }
		
		gobuy += '<span class="khb_buy buttom_border_redius"><a href="javascript:;" class="tnProductInfo ' + (enable ? '' : 'disabled') + '" style="' + (enable ? '' : 'color:#656565;background:#dcdcdc;') + '" data-oid="' + product.productOid + '">' + btnTxt + '</a>'

			if(product.raisedTotalNumber > 10000){
				product.raisedTotalNumber = GHutils.formatCurrency(product.raisedTotalNumber/10000)+"<em>万</em>";
			} else {
				product.raisedTotalNumber = GHutils.formatCurrency(product.raisedTotalNumber);
			}
			var jindu = "";
			if(pronone=="none") {
				jindu += '<div class="m_l"><div style="height:5px"></div></div>';
			} else {
				jindu += '<div class="m_l"><div class="progress r_process dqd_process"></div><div id="progressbar" class="progress-bar process_blue" role="progressbar" aria-valuenow="10	" aria-valuemin="0" aria-valuemax="100" style="width:'+ percent*2.93 +'px"></div></div>';
			}

			var titleds = '<h2 class="titleds"><i class="proname" style="font-style:normal;">' + product.name +'&nbsp;</i><i class="bqscon" style="font-style:normal;">'+ labels +' </i></h2>';
			
			products += '<li><span class="new-icon">'+ labelicon +'</span>'+ titleds +'<div><div class="zxb_col"><span class="font1_span" >'
			+ interest +'</span><p style="position:relative"><span style="vertical-align:middle;">历史年化收益率</span><span class="incomehint4is" style="margin-left: 6px;"></span></p></div>'+jindu+'<ul class="xingxi"><li>'+GHutils.formatCurrencys(product.investMin||0)+'元起投</li><li>'+product.paybackName+'</li><li>'+product.durationPeriodDays+times+'锁定</li></ul><div class="khb_buyf">'+gobuy+'</span></div></div></li>'
	
		
		return products;			

	},
	parseExpAror: function(expAror) {

	},
	bindEvent: function() {
		//banner跳转
		$(".item-link").off().on("click", function() {
			var links = $(this).attr("data-url") || '';
			var topage = $(this).attr("data-topage") || '';

			// 添加日志上报
			GHutils.writeLoad({
				data:{
					evt:'BannerClick',
					ext:{
						"index": links || topage || ""
					},
					ret:""
				}
			})

			if(topage == 'T1') {
				window.location.href = "product-t0.html"
			} else if(topage == 'T2') {
				window.location.href = "regular.html"
			} else if(topage == 'T3') {
				$("#userRegister").css({
					"display": "block"
				})
			} else if(links != '') {
				window.location.href = links
			}
		});
		$('.tnProductInfo').on('click', function() {
			var oid=$(this).attr('data-oid');
			if($(this).hasClass("disabled")){
				if(!GHutils.getUserInfo()) {
					//显示弹窗
					location.href="/regandlog.html?type=log";
					return
				} 
				GHutils.load({
					url:"/zybusiness/user/check/invest",
					data:{productId:oid},
					type:"post",
					callback:function(data){
						if(data.code==10000&&data.data.hasInvest){
							window.location.href = 'product-tn.html?productOid=' + oid
						}else{
							$('#soldout-box').modal('show')
						}
					},
					errcallback:function(){
						$('#soldout-box').modal('show')
					}
				})
				
			}else{
				window.location.href = 'product-tn.html?productOid=' + oid
			}
		})
	}
}

$(function() {
	new Index().init();
	//banner操作
	$(".banner").on("mouseenter", function() {
		$(".jiantous").css("display", "block");
	}).on("mouseleave", function() {
		$(".jiantous").css("display", "none");
	})
})