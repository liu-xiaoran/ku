var ProductTnList = function() {
	this.durationPeriodDayslists = []
	this.interestTotallists = []
	return this;
}

ProductTnList.prototype = {
	init: function() {
		this.mytns = {};
		this.loginStatus = 'no'
		this.bindEvent();
	},
	bindEvent: function() {
		var _this = this
		_this.getData(' ', 1, true)

		var PeriodDaysList = '';
		var interestTotal = '';

		for(var i in _this.durationPeriodDayslists) {
			PeriodDaysList += '<p class="perDay_btn">' + (_this.durationPeriodDayslists[i]+'').slice(1) + ((_this.durationPeriodDayslists[i]+'').charAt(0)==2?'个月':'天') +'</p>'
		}
		for(var i in _this.interestTotallists) {
			interestTotal += '<p class="interest_btn">' + GHutils.toFixeds(_this.interestTotallists[i], 2) + '%</p>'
		}
		$(".durationPeriodDaysList").html(PeriodDaysList);
		$(".interestTotalList").html(interestTotal);
		$(".perDay_btn").on("click", function() {
			var index = $(this).index();
			_this.getData({
				durationPeriodDays: _this.durationPeriodDayslists[index]
			}, 1, true)
			$(this).parent().siblings().addClass("active");
			$(this).parents("li").siblings().find("a").removeClass("active");
			$(this).parents("li").siblings().find(".blackcon").css("display", "inline").siblings(".redcon").css("display", "none");
			$(this).parents("li").siblings().find("p").removeClass("xuanzhong");
			if($(this).parent().siblings().hasClass("active")) {
				$(this).addClass("xuanzhong").siblings("p").removeClass("xuanzhong");
				$(this).parents(".duration").stop().animate({
					'height': '0'
				}, 100)
			} else {
				$(this).parents("li").siblings().find("a").removeClass("active");
				$(this).parents("li").find("a").addClass("active");
			}
		})
		$(".interest_btn").on("click", function() {
			var index = $(this).index();
			_this.getData({
				interestTotal: _this.interestTotallists[index]
			}, 1, true)
			$(this).parent().siblings().addClass("active");
			$(this).parents("li").siblings().find("a").removeClass("active");
			$(this).parents("li").siblings().find(".blackcon").css("display", "inline").siblings(".redcon").css("display", "none");
			$(this).parents("li").siblings().find("p").removeClass("xuanzhong");
			if($(this).parent().siblings().hasClass("active")) {
				$(this).addClass("xuanzhong").siblings("p").removeClass("xuanzhong");
				$(this).parents(".duration").stop().animate({
					'height': '0'
				}, 100)
			} else {
				$(this).parents("li").siblings().find("a").removeClass("active");
				$(this).parents("li").find("a").addClass("active");
			}
		})
		var heights = $(".duration p").height();
		$("#sort .upcon").on("mouseenter", function() {
			var nums = $(this).find(".duration").children("p").length;
			$(this).find(".duration").stop().animate({
				'height': nums * heights
			}, 300)
			$(this).find(".redcon").css("display", "inline").siblings(".blackcon").css("display", "none");
		}).on("mouseleave", function() {
			$(this).find(".duration").stop().animate({
				'height': '0'
			}, 300)
			if($(this).find("a").hasClass("active")) {
				return;
			} else {
				$(this).find(".blackcon").css("display", "inline").siblings(".redcon").css("display", "none");
			}
		})
		$("#sort .no").on("click", function() {
			_this.getData(' ', 1, true);
			$(this).addClass("active");
			$(this).parent().siblings().find("a").removeClass("active");
			$(this).parent().siblings().find("p").removeClass("xuanzhong");
			$(this).parent().siblings().find(".blackcon").css("display", "inline").siblings(".redcon").css("display", "none");
		})
	},
	//获取定期产品列表
	getData: function(urlParam, page, isFlag) {
		var _this = this
		var rows = 10
		GHutils.load({
			url: "/actives1/product/getRegularProductList",
			data: {
				channelOid: contractId,
				pageInfo: {
					pageNo: page,
					pageSize: rows,
				},
				durationPeriodDays: urlParam.durationPeriodDays,
				interestTotal: urlParam.interestTotal
			},
			type: "post",
			async: false,
			callback: function(result) {

				if(result.code != 10000) {
					return;
				} else {
					var products = ""
					//兼容ie8 forEach循环；
					if(!Array.prototype.forEach) {
						Array.prototype.forEach = function forEach(callback, thisArg) {
							var T, k;
							if(this == null) {
								throw new TypeError("this is null or not defined");
							}
							var O = Object(this);
							var len = O.length >>> 0;
							if(typeof callback !== "function") {
								throw new TypeError(callback + " is not a function");
							}
							if(arguments.length > 1) {
								T = thisArg;
							}
							k = 0;
							while(k < len) {
								var kValue;
								if(k in O) {
									kValue = O[k];
									callback.call(T, kValue, k, O);
								}
								k++;
							}
						};
					}
					//结束
					// 获取筛选条件
					_this.durationPeriodDayslists = result.data.durationPeriodDays
					_this.interestTotallists = result.data.interestTotal
					if(!result.data.content){
						$('.tn_list_ul1').html('<li class="noDataTips" style="border: none;padding-top: 150px;height: 400px;"><img src="static/images/app-nodata1.png" alt="暂无收益_掌悦理财" /></li>');
                        $(".tcdPageCode").hide();
						return false
					}
						
					// 获取定期产品列表
					result.data.content.forEach(function(product) {
							var labels = "";
							
							var labelicon = '';
							//循环标签
							for(var i in product.labelList) {
								if(product.labelList[i].labelType == "extend") {
									//循环图标
									if(product.labelList[i].labelName == '一锤定音') {
										labels += '<span style="border:none;padding:3px 0"><img title="一锤定音:此项目满标者可获惊喜红包" src="static/images/chuizi.png" height="20"/></span>'
									} else if(product.labelList[i].labelName == '一鸣惊人') {
										labels += '<span style="border:none;padding:3px 0"><img title="一鸣惊人:此项目单笔投资最高者可获惊喜红包" src="static/images/famous.png" height="20"/></span>'
									} else if(product.labelList[i].labelNo == 'A5') {
										labels += '<span style="border:none;padding:3px 0"><img title="投资惊喜:此产品成功投资有机会获得惊喜礼包" src="static/images/touzijinxi.png" height="20"/></span>'
									} 

									//循环标签
									if(product.labelList[i].labelName != '一锤定音'&&product.labelList[i].labelName != '一鸣惊人'&&product.labelList[i].labelNo != 'A5') {
										labels += '<span>' + product.labelList[i].labelName + '</span>';
									}
								}
							}

							product.netUnitShare = 1
							var amount = product.raisedTotalNumber;
							var percent = Math.min(100, product.percent)
							if(amount > 100000000) {
								amount = GHutils.formatCurrency(amount / 100000000) + "亿";
							} else if(amount > 10000) {
								amount = GHutils.formatCurrency(amount / 10000) + "万";
							} else {
								amount = GHutils.formatCurrency(amount);
							}
							var interest = GHutils.toFixeds(product.expAror, 2) + "%"
							if(product.rewardInterest&&(product.rewardInterest-0)) {
								interest += '<span>+' + GHutils.toFixeds(product.rewardInterest, 2) + '%</span>'
							}
							var gobuy = '',
								btnTxt = '';
							var pronone = '';
							var enable = true;
							if(GHutils.getProductStatus(product.state)==1||(GHutils.Fmul(GHutils.Fsub(product.raisedTotalNumber , product.collectedVolume ), product.netUnitShare) - product.lockCollectedVolume - (product.investMin == null ? 0:product.investMin) < 0)){
								enable = false
								pronone = 'none';
								amount = '0.00'
								btnTxt = '已售罄';
							}else if(GHutils.getProductStatus(product.state)==-1){
								enable = false
								btnTxt = '预售';
							}else if(GHutils.getProductStatus(product.state)==0){
								enable = true
								btnTxt = '立即抢购';
							}
							
							gobuy += '<span class="khb_buy buttom_border_redius"><a href="javascript:;" class="tnProductInfo '+(enable?"":"disabled")+'" style="' + (enable ? '' : 'color:#656565;background:#dcdcdc;') + '" data-oid="' + product.productOid + '">' + btnTxt + '</a>'
							// 标签
							product.raisedTotalNumber = GHutils.formatCurrency(product.raisedTotalNumber / 10000) + "万";
							var investMins = product.investMin || 0
							var times = '';
							if(product.durationPeriodType == 'DAY') {
                                times = '天';
							} else if(product.durationPeriodType == 'MONTH') {
                                times = '月';
							}
							products += '<li><div class="clearfix" style="width: 100%;"><div class="tn_titlecons"><p>' +
								product.name + '</p>' + labels + '</div></div><div class="rows"><div class="col-md-2 zxb_col" style="min-width:160px"><span class="font1_span" style="font-size:24px;color:#d5582c;">' +
								interest + '</span><p>历史年化收益率</p></div><div class="col-md-2 zxb_col2" style="text-align:center;"><span class="font_span">' +
								product.durationPeriodDays + times +'</span><p>投资期限</p></div><div class="col-md-2" style="text-align:center;"><span class="font_span">' +
								GHutils.formatCurrency(investMins) + '元</span><p>起投金额</p></div><div class="col-md-2" style="text-align:center;width:16%"><span class="font_span">' +
								product.raisedTotalNumber + '</span><p>募资总额</p></div><div class="col-md-2" style="min-width:220px"><div class="' +
								pronone + '"><div class="col-xs-1"></div><div class="col-xs-11 dqdm" style="text-align:center;"><div style="position:relative"><div class="progress r_process dqd_process"></div><div id="progressbar" class="progress-bar process_blue progress-bars" role="progressbar" aria-valuenow="10	" aria-valuemin="0" aria-valuemax="100" style="width:' +
								percent * 1.04 + 'px"></div></div><p>募集进度</p></div><span style="font-size:16px; color: #ff8b6c; line-height: 33px;margin-left:5px;">' + percent + '%</span></div></div><div class="col-md-2 zxb_col4 khb_buyf1 khb_buyf1s">' + gobuy + '</span></div></div></li>'
					})
					$('.tn_list_ul1').html(products);
					var total = result.data.pageInfo.totalSize
					$('#tnListPage').html('<li>共' + total + '个产品</li><li><i style="color: #ff2400;font-style:normal;">' + page + '</i>/' + Math.ceil(total / rows) + '</li><li><span class="getprevious"><img src="static/images/' + (page == 1 ? 'arrow_1.png' : 'arrow_1_h.png') + '"/></span> <span class="getnext"><img src="static/images/' + (GHutils.Fmul(rows, page) >= result.data.total ? 'arrow_2.png' : 'arrow_2_h.png') + '"/></span></li>')
					$('.tn_pagenum').html('	第' + page + '页  &nbsp;共' + Math.ceil(total / rows) + '页</div>')
					_this.nextPage();
					if(isFlag) {
						_this.createPage(urlParam, Math.ceil(total / rows));
					}
				}
			}
		});
	},
	createPage: function(urlParam, pageCount) {
		var _this = this;
        $(".tcdPageCode").show()
        if(pageCount <= 1) {
            $(".tcdPageCode").hide()
        }
		$(".tcdPageCode").createPage({
			pageCount: pageCount,
			current: 1,
			backFn: function(page) {
				_this.getData(urlParam, page, false);
			}
		});
	},
	nextPage: function() {
		var _this = this
		$('.getnext').on('click', function() {
			$('.tcdPageCode span.current').next().click()
		})
		$('.getprevious').on('click', function() {
			$('.tcdPageCode span.current').prev().click()
		})
		$('.tnProductInfo').on('click', function() {
			var oid=$(this).attr('data-oid');
			if($(this).hasClass("disabled")){
				if(!GHutils.getUserInfo()) {
					//显示弹窗
					location.href="/regandlog.html?type=log";
					return
				} 
				GHutils.load({
					url:"/zybusiness/user/check/invest",
					data:{productId:oid},
					type:"post",
					callback:function(data){
						if(data.code==10000&&data.data.hasInvest){
							window.location.href = 'product-tn.html?productOid=' + oid
						}else{
							$('#soldout-box').modal('show')
						}
					},
					errcallback:function(){
						$('#soldout-box').modal('show')
					}
				})

			}else{
				window.location.href = 'product-tn.html?productOid=' + oid
			}

		})
	}
}

$(function() {
	new ProductTnList().init();
})