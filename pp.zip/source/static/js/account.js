var Account = function() {
	return this;
}

Account.prototype = {
	init: function() {
		this.pageInit();
		this.bindEvent();
		var myChartOfPie;
		var capitalAmount;
		var capitalAmounts;
	},
	pageInit: function() {
		var _this = this
		//账户总览
		GHutils.load({
			url: "/payment/account/myAsset",
			data: {},
			type: "post",
			callback: function(result) {
				if(result.code != 10000) {
					return false;
				}
				var tndetail = '';
				var t0detail = '';
				var sqdetail = '';
				GHutils.forEach(result.data.regularProducts, function(idx, tnProduct) {
					tndetail += '<li>' + tnProduct.productName + seeOrProductData(GHutils.formatCurrency(tnProduct.productAmount)+'元') + '</li>'
				})
				$('#part_tnCapitalDetails').html(tndetail)
				GHutils.forEach(result.data.currentProducts, function(idx, product) {
					t0detail += '<li>' + product.productName + seeOrProductData(GHutils.formatCurrency(product.productAmount)+'元') + '</li>'
				})
				$('#part_t0CapitalDetails').html(t0detail)
				GHutils.forEach(result.data.applyCapitalDetails, function(idx, sqProduct) {
					sqdetail += '<li>' + sqProduct.productName + seeOrProductData(GHutils.formatCurrency(sqProduct.productAmount)+'元') + '</li>'
				})
				$('#part_applyCapitalDetails').html(sqdetail)
				seeOrHideData("capitalAmount", GHutils.formatCurrency(result.data.totalAsset))
				seeOrHideData("capitalAmounts", GHutils.formatCurrency(result.data.totalAsset))
				seeOrHideData('tatalIncomoe', GHutils.formatCurrency(result.data.accumulativeIncome))
				seeOrHideData('todayIncome', GHutils.formatCurrency(result.data.yesterdayIncome))
				seeOrHideData('allIncome', GHutils.formatCurrency(result.data.accumulativeIncome))
				seeOrHideData('yesterIncome', GHutils.formatCurrency(result.data.yesterdayIncome))
				seeOrHideData('balance', GHutils.formatCurrency(result.data.cashBalance))
				seeOrHideData('part_balance', GHutils.formatCurrency(result.data.cashBalance)+'元')
				seeOrHideData('part_onWayBalance', GHutils.formatCurrency(result.data.frozenBalance)+'元')
				//掌薪宝
				seeOrHideData("part_t0CapitalAmount", GHutils.formatCurrency(result.data.currentAsset)+'元')
				//定期
				seeOrHideData("part_tnCapitalAmount", GHutils.formatCurrency(result.data.regularAsset)+'元')
				seeOrHideData("part_applyAmt", GHutils.formatCurrency(result.data.applyingAsset)+'元')

				initChart(result.data)
			}
		})

		if(GHutils.getCookie('see')) {
			$('#seecapitalAmount').attr('src', 'static/images/eyeClose-icon.png')
		} else {
			$('#seecapitalAmount').attr('src', 'static/images/eye-icon.png')
		}

		function seeOrHideData(id, data) {
			if(GHutils.getCookie('see')) {
				$('#' + id).attr('data-amount', data)
				$('#' + id).html('***')
			} else {
				$('#' + id).attr('data-amount', '***')
				$('#' + id).html(data)
			}
		}

		function seeOrProductData(data) {
			var strs = ''
			if(GHutils.getCookie('see')) {
				strs = '<span  class="account-data" data-amount="' + data + '">***</span></li>'
			} else {
				strs = '<span  class="account-data" data-amount="***">' + data + '</span></li>'
			}
			return strs
		}

		function seeOrHideChart() {
			var strs = ''
			if(GHutils.getCookie('see')) {
				strs = '<span  class="account-data" data-amount="' + data + '">***</span></li>'
			} else {
				strs = '<span  class="account-data" data-amount="***">' + data + '</span></li>'
			}
			return strs

			var option = _this.myChartOfPie.getOption()
			option.title[0].subtext = $('#capitalAmount').html()
			_this.myChartOfPie.setOption(option)
		}

		//初始化chart，
		function initChart(result) {
			var subtext = GHutils.formatCurrency(result.totalAsset)
			if(GHutils.getCookie('see')) {
				subtext = '***'
			}
			// 基于准备好的dom，初始化echarts实例
			_this.myChartOfPie = echarts.init(document.getElementById('assetPartsPie'));
			option = {
				tooltip: {
					trigger: 'item',
					formatter: "{a} <br/>{b}: {c} ({d}%)"
				},
				//			    title: {
				//			        text: '总资产',
				//					subtext:subtext,
				//			        x: 'center',
				//			        y: 'center',
				//			        itemGap: 20,
				//			        textStyle: {
				//			        	fontSize: 16,
				//					    color: '#666'
				//			        },
				//			        subtextStyle: {
				//			        	fontSize: 28,
				//			        	color: '#e45038',
				//			        	align: 'right'
				//			        }
				//			    },
				color: ['#ffaa25', '#ffc435', '#9c4cd1', '#2e8ef2'],
				series: [{
					name: '资产分布',
					type: 'pie',
					radius: ['65%', '85%'],
					center: [185, 181],
					avoidLabelOverlap: false,
					label: {
						normal: {
							show: false,
							position: 'center'
						},
						emphasis: {
							show: false
						}
					},
					labelLine: {
						normal: {
							show: false
						}
					},
					data: [{
							value: result.currentAsset || 0,
							name: '掌薪宝资产'
						},
						{
							value: result.regularAsset || 0,
							name: '定期资产'
						},
						// {
						// 	value: result.applyingAsset || 0,
						// 	name: '申请中的资产'
						// },
						{
							value: result.cashBalance || 0,
							name: '可用余额'
						},
						{
							value: result.frozenBalance || 0,
							name: '冻结金额'
						}
						//{value:result.experienceCouponAmount, name:'体验金'}
					]
				}]
			};
			// 使用刚指定的配置项和数据显示图表。
			_this.myChartOfPie.setOption(option);
		}

		//收益曲线图
		var date = new Date();
		GHutils.load({
			url: "/zybusiness/user/myMonthIncome/pc",
			data: {},
			type: "post",
			callback: function(result) {
				if(result.code != 10000) {
					return false;
				}
				if(result.data.list && result.data.list.length > 0) { //收益不为空
					$('#noReCord').hide()
					$('#assetProfitLine').show()
				} else {
                    $('#noReCord').show()
                    $('#assetProfitLine').hide()
				}
				var ydatas = [];
				var xdatas = [];
//				var i = 0;
				var maxIcome = 0
//				result.details.rows.forEach(function(income){
//					ydatas[i]= income.date.substring(5).replace('-','/')
//					xdatas[i]=(income.t0Income+income.tnIncome)
//					if(xdatas[i] > maxIcome){
//						maxIcome = xdatas[i]
//					}
//					i++;
//				})
				GHutils.forEach(result.data.list, function(i, income) {
					ydatas[i] = GHutils.formatTimestamp({
						time: income.incomeDate,
						showtime: "true"
					}).substring(5).replace('-', '/')
					xdatas[i] = GHutils.Fadd(income.currentIncome , income.regularIncome)
					if(xdatas[i] > maxIcome) {
						maxIcome = xdatas[i]
					}
				})
				if(maxIcome > 20) {
					maxIcome = GHutils.Fmul(GHutils.Fadd(Math.floor(GHutils.Fdiv(maxIcome, 4)), 1), 4)
				} else {
					maxIcome = maxIcome
				}
				initIncomeChart(ydatas, xdatas, maxIcome)
			}
		})

		function initIncomeChart(ydatas, xdatas, maxIcome) {
			var myChartOfLine = echarts.init(document.getElementById('assetProfitLine'));
			option = {
				tooltip: {
					trigger: 'item'
				},
				xAxis: [{
					type: 'category',
					boundaryGap: false,
					scale: false,
					axisLabel: {
						textStyle: {
							fontSize: "16px",
							color: '#a7aab3'
						}
					},
					// x轴的横坐标边框线
					axisLine: {
						show: false
					},
					axisTick: {
						show: false
					},
					// 背景图的内置表格中的“边框”的颜色线条， 这个是x轴的竖线
					splitLine: {
						show: true,
						lineStyle: {
							color: '#ddd',
							type: 'solid'
						}
					},
					data: ydatas //['10/27','10/28','10/29','10/30','10/31','11/01','11/02'],
				}],

				yAxis: [{
						type: 'value',
						max: maxIcome,
						axisLabel: {
							formatter: '{value}%'
						},
						axisLine: {
							show: false,
							lineStyle: {
								color: 'e4e4e4'
							}
						},
						axisLabel: {
							show: true,
							textStyle: {
								fontSize: "16px",
								color: "#a7aab3"
							}
						},
						axisTick: {
							show: false,
						},
						splitLine: { //终于找到了，背景图的内置表格中“边框”的颜色线条   这个是y轴的横线
							show: true,
							lineStyle: {
								color: "#ddd",
								type: "solid",
							}
						}
					}

				],
				dataZoom: {
					type: 'inside',
					width: 500,
					height: 500
				},
				lineStyle: {
					normal: {
						type: 'solid',
						color: '#28a5fc',
						opacity: '0.5'
					}
				},
				backgroundColor: "#FFFFFF", //背景颜色
				borderWidth: 0.1,

				series: [{
					name: '收益',
					type: 'line',
					smooth: false,
					barGap: '30%',
					lineStyle: {
						normal: {
							type: 'solid',
							color: "#4799F0",
							opacity: "0.5"
						}
					},
					/*设置区域渐变色*/
					areaStyle: {
						normal: {
							color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
								offset: 0,
								color: 'rgba(53, 132, 234, 0.67)'
							}, {
								offset: 1,
								color: 'rgba(218, 245, 253, 0.33)'
							}])

						}
					},
					itemStyle: {
						normal: {
							areaStyle: {
								type: 'default'
							}
						}
					},
					data: xdatas //[5.0, 4.5, 5.5, 4.7, 5.8, 5.2, 5.9]
				}]
			};

			// 使用刚指定的配置项和数据显示图表。
			myChartOfLine.setOption(option);
		}

	},
	bindEvent: function() {
		var _this = this
		//点击眼睛图标
		$('#seecapitalAmount').on('click', function() {
			var capitalAmount = ''
			$('.account-data').each(function(i, e) {
				capitalAmount = $(e).html()
				$(e).html($(e).attr('data-amount'))
				$(e).attr('data-amount', capitalAmount)
			})

			var option = _this.myChartOfPie.getOption()
			//			option.title[0].subtext = $('#capitalAmount').html()
			_this.myChartOfPie.setOption(option)

			if(GHutils.getCookie('see')) {
				GHutils.setCookie('see', '')
				$(this).removeClass('see')
				$(this).attr('src', 'static/images/eye-icon.png')
			} else {
				GHutils.setCookie('see', 'see')
				$(this).addClass('see')
				$(this).attr('src', 'static/images/eyeClose-icon.png')

			}
		})
	}
}

$(function() {
	new Account().init();
})