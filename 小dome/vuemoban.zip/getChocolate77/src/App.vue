<template>
  <div id="app">
    <Headers></Headers>
    <router-view class="activite"></router-view>
    <Lists></Lists>
    <Footers></Footers>
  </div>
</template>

<script>
import Headers from './components/pages/Header'
import Footers from './components/pages/Foot'
import Lists from './components/pages/lists'
import router from './router'
export default {
  name: 'app',
  components:{
    	 Headers,
       Footers,
       Lists
  },
  created(){
      router.push({ name: 'Activite', params: { data: "{}" } })
  }
}

</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: #2c3e50;
  margin-top: 60px;
}
html,body{height: 100%;background: #460f77;}
section,img {
  display: block;
  width: 100%;
}
a {
  text-decoration: none;
}
ul,li {
  list-style: none;
}
input {
  tap-highlight-color: rgba(0,0,0,0);
  -webkit-tap-highlight-color: rgba(0,0,0,0);
  -moz-tap-highlight-color: rgba(0,0,0,0);
  -o-tap-highlight-color: rgba(0,0,0,0);
  border:none;
}
img {
  border: none;
}
#app {
  font-family: '微软雅黑';
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  width: 10rem;
  margin: 0 auto;
  color: #e6c6ff;
}
.ovfHiden {
  overflow-y: hidden;
  height: 100%;
}
.activite{
  height: 7.3733rem;
  width: 100%;
  background: url(assets/activite.png) no-repeat center;
  background-size: 100% auto;
}
</style>
