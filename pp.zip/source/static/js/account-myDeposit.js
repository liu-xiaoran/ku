var AccountMyDeposit = function() {
	return this;
}

AccountMyDeposit.prototype = {
	init: function() {
		this.pageInit();
		this.bindEvent();
		this.param = {
			orderType: 'ALL',
			dateType: 'ALL',
			pageInfo: {
				pageNo: 1,
				pageSize: 7
			}
		}
		this.parseParam(true)
	},
	pageInit: function() {
		
	},
	getRecords: function(urlParam) {
		var _this = this
		GHutils.load({
			url: "/payment/trade/queryBankOrder",
			data: urlParam,
			type: 'post',
			loginStatus: function(resp) {
				window.location.href = "index.html"
			},
			callback: function(result) {
				var records = '';
				if(result.code == 9999) {
					records = '';
					return false
				}
				if(result.data.list) {
					$("#noRecord").hide()
					$("#hasRecord").show()
                    $('#hadRecord').show()
				} else {
                    $("#noRecord").show()
                    $("#hasRecord").hide()
                    $('#hadRecord').hide()
				}
				GHutils.forEach(result.data.list, function(idx, record) {
					var type = record.orderType == 'RECHARGE' ? "充值" : "提现"
					var orderStatusDisp = record.statusDesc || ''
					records += '<ul class="container-fluid-contents"><li class="col-xs-3">' + type + '</li><li class="col-xs-3">' + GHutils.formatCurrency(record.orderAmount == null ? 0 : record.orderAmount) + '元</li><li class="col-xs-3" style="color:#ec9437">' + orderStatusDisp + '</li><li class="col-xs-3">' + GHutils.formatTimestamp({
						time: record.createTime,
						showtime: "false"
					}) + '</li></ul>'
				})
				// 如果无数据，跳过判断
				$('#deposit-Record').html(records)
				_this.createPage(Math.ceil(result.data.pageInfo.totalSize/7),urlParam.pageInfo.pageNo)
			},
			errcallback: function(error) {

			}
		})
	},
	bindEvent: function() {
		var _this = this
		//选择交易类型
		$('#typeOptions li a').on('click', function() {
			$('#typeOptions li a').removeClass('active')
			$(this).addClass('active')
			_this.param.orderType = $(this).attr('data-orderType')
			_this.param.pageInfo.pageNo = 1
			$('#moreRecord').attr('data-page', 1)
			_this.parseParam(true)
		})

		$('#timeTypeOptions li a').on('click', function() {
			if($(this).attr('class') == 'active') {
				return false;
			}
			$('#timeTypeOptions').find('a').removeClass('active')
			if($(this).attr('data-timeType')) {
				$(this).addClass('active')
			} else {
				$('.quanbu').addClass('active')
			}
			if($(this).attr('data-timeType')) {
				_this.param.dateType = $(this).attr('data-timeType')
			} else {
				_this.param.dateType = "ALL"
			}
			_this.param.pageInfo.pageNo = 1
			$('#moreRecord').attr('data-page', 1)
			_this.parseParam(true)
		})
		$('#moreRecord').on('click', function() {
			if($(this).is('.active')) {
				return false;
			}
			_this.param.pageInfo.pageNo = parseInt($(this).attr('data-page')) + 1
			$(this).attr('data-page', _this.param.pageInfo.pageNo)
			_this.parseParam()
		})
	},
	parseParam: function() {
		var _this = this
		// 每页数据量
		_this.param.pageInfo.pageSize = 7
		_this.getRecords(_this.param)
	},
	createPage: function(pageCount,current) {
        $(".tcdPageCode").show()
        if(pageCount <= 1) {
            $(".tcdPageCode").hide()
        }
		var _this = this;
		$(".tcdPageCode").createPage({
			pageCount: pageCount,
			current: current,
			backFn: function(page) {
                _this.param.pageInfo.pageNo = page;
				_this.getRecords(_this.param);
			}
		});
	}
}

$(function() {
	new AccountMyDeposit().init();
})