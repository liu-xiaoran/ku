var ZYWechat = require('./lib/wechat');
import req from './lib/req'
export {ZYWechat,req}