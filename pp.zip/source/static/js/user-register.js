var time = 0
//获取验证码
$("#register_getVerifyCodes").click(function() {
	if($(this).hasClass('sending')) { //正在进行倒计时
		return;
	}
	var userPhone = GHutils.trim($("#register_userPhones").val());

	GHutils.writeLoad({
		data:{
			evt:'RegisterGetVeriCodeClick',
			ext:{
				'tellength':userPhone.length,
				"tel" : userPhone.substring(userPhone.length - 4)
			},
			ret:""
		}
	})

	if(userPhone == "") {
		$("#register_errorMessages").html("提示： 手机号不能为空");
		$(".promit_box").show();
		return;
	}
	// if(!(/^1(3|4|5|7|8)\d{9}$/.test(userPhone))) {
	// 	$("#register_errorMessages").html("提示： 手机号格式不正确");
	// 	$(".promit_box").show();
	// 	return;
	// } else {
		GHutils.load({
			url: "/platform1/Userpub/sendsms",
			data: {
				phone: userPhone,
				smsType: "regist"
			},
			type: "post",
			callback: function(result) {
                if(result.data && result.data.ttl) {
                    time = result.data.ttl
                } else {
                    time = 120
				}
				if(result.code == 10000||result.code == 99995){
					$('#register_getVerifyCodes').addClass('sending')
					countdown()
				}
				if(result.code != 10000) {
					$("#register_errorMessages").html('提示： ' + result.message);
					$(".promit_box").show();
					return false;
				}
				$(".promit_box").hide();
			},
			errcallback: function() {}
		});
	// }
})

//倒计时
var countdown = function() {
	if(time > 1 && $('#register_getVerifyCodes').is('.sending')) {
		time -= 1
		$('#register_getVerifyCodes').html("重新获取(" + time + ")")
		setTimeout(countdown, 1000)
	} else {
		$('#register_getVerifyCodes').html('获取验证码')
		$('#register_getVerifyCodes').removeClass('sending')
	}
}

var doRegister = function() { //注册
	var _this = this
	var param = {
		phone: GHutils.trim($("#register_userPhones").val()),
		userPwd: GHutils.trim($("#land_pwd").val()),
		veriCode: GHutils.trim($("#register_verifyCodes").val()),
		inviteCode: "",
		platform: "pc",
		contractId: contractId,
		otherArgs: encodeURIComponent(location.search.substring(1))
	}
	GHutils.load({
		url: "/platform1/Userpub/login",
		data: param,
		type: "post",
		callback: function(result) {
			$("#registerSubmit").removeClass('submiting')
			if(result.code != 10000) {
				GHutils.writeLoad({
					data:{
						evt:'RegisterResult',
						ext:result,
						ret:"fail"
					}
				})

				$('#register_errorMessages').html('提示： ' + result.message)
				$(".promit_box").show();
				return false;
			} else {
                GHutils.setCookie("headerinfo", '{"data":{},"extendInfo":{"NewLetter":0,"UserBasicInfo":{"login":1}}}')
				$(".promit_box").hide();
				if(location.href.indexOf("sjzc_landingpage") >= 0 || location.href.indexOf("xczc_landingpage") >= 0) {
					location.href = "result_landpage.html";
				}
				if(location.href.indexOf("regandlog") >= 0) {
					// if(document.referrer&&document.referrer.indexOf("regandlog")<0) {
					// 	location.href = document.referrer;
					// } else {
					// 	location.href = "/";
					// }
                    $('#registerSuccess').modal('show');
				}else{
					location.href = "/";
				}
			}
		}
	});
}
var isCheck = true;
$("#protocolChecks").click(function() {
	isCheck = !isCheck;
	if(isCheck) {
		$(".checkboxs").css("background",'#518dd0')
		$(".checks").show();
	} else {
		$(".checkboxs").css("background",'#fff')
		$(".checks").hide();
	}
})

$("#registerSubmits").click(function() {
	GHutils.writeLoad({
		data:{
			evt:'RegisterClick',
			ext:{
				'tellength':GHutils.trim($("#register_userPhones").val()).length,
				"tel" : GHutils.trim($("#register_userPhones").val()).substring(GHutils.trim($("#register_userPhones").val()).length - 4),
				'vericode':GHutils.trim($("#register_verifyCodes").val())
			},
			ret:""
		}
	})

	if(GHutils.trim($("#register_userPhones").val()) == "") {
		$("#register_errorMessages").html("提示： 手机号不能为空");
		$(".promit_box").show();
		return false;
	// } else if(!(/^1(3|4|5|7|8)\d{9}$/.test(GHutils.trim($("#register_userPhones").val())))) {
	// 	$("#register_errorMessages").html("提示： 手机号格式不正确");
	// 	$(".promit_box").show();
	// 	return false;
	} else if(GHutils.trim($("#land_pwd").val()) == "") {
		$("#register_errorMessages").html("提示： 密码不能为空");
		$(".promit_box").show();
		return false;
	} else if(GHutils.trim($("#land_pwd").val()).length<6||GHutils.trim($("#land_pwd").val()).length>16) {
		$("#register_errorMessages").html("提示： 密码格式不正确");
		$(".promit_box").show();
		return false;
	} else if(GHutils.trim($("#register_verifyCodes").val()) == "") {
		$("#register_errorMessages").html("提示： 验证码不能为空");
		$(".promit_box").show();
		return false;
	} else if(!(/^\d{6}$/.test(GHutils.trim($("#register_verifyCodes").val())))) {
		$("#register_errorMessages").html("提示： 验证码格式不正确");
		$(".promit_box").show();
		return false;
	} else if(!isCheck) {
		$('#register_errorMessages').html('提示： 请同意《平台服务协议》')
		$(".promit_box").show();
		return false;
	} else {
		doRegister();
	}
});

$(document).keyup(function (e) {
    if($(".reglog_registers").css("display")=="block"||$(".land_registers").css("display")=="block") {
        if (e.keyCode === 13) {
            $("#registerSubmits").click()
        }
    }
})