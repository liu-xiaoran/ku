var AccountMyCard = function() {
	return this;
}

AccountMyCard.prototype = {
	init: function() {
		this.bankbg = null;
		this.bankImg = null;
		this.bankcode = null;
		this.pageInit();
		this.btntime = null;
	},
	pageInit: function() {
		_this = this;
		//获取用户账户详情
		GHutils.load({
			url: "/payment/account/myBankcard",
			data: {},
			type: "post",
			callback: function(result) {
				if(result.code == 10000) {
					$('#bankCard').show();
					$("#bkCardUsrCont").css({
						background: "none",
						backgroundColor: "#fff",
						border: "1px solid #cacaca"
					})
					$(".con_bank_icon span img").attr("src", result.data.bankBigLogo)
					$('#bankcardNum').html("**** ***** ***** *** " + result.data.bankCardNo.substr(-4))
					$('#singleQuota').html('单笔可支付' + GHutils.formatCurrency(result.data.payOneLimit) + '元')
					$('#addBkCardUsrCont').hide()
					$('#bkCardUsrCont').show();
				} else {
					$('#addBkCardUsrCont').show()
					$('#bkCardUsrCont').hide();
					$("#bkCardUsrCont").css("backgroundImage", "none")
				}
			}
		})
		$("#nowAddCard").on("click",function(){
			$('#getBanklist').trigger("click")
		})
	},
	callBackFun: function() {
		var _this = this
		_this.pageInit();
	}
}

$(function() {
	new AccountMyCard().init();
	window.pageFun = new AccountMyCard();
})