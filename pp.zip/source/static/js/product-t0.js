var HUOQI = function () {
	this.tips = $("#invest_errorMessage");
	return this;
}

HUOQI.prototype = {
	init: function () {
		this.pageInit();
		this.bindEvent();
		this.param = {};
		this.timer="";
		this.formKey=""
	},
	getDetail: function (oid) {
		$.get("/actives1/product/getV1CurrentIntro?productOid=" + oid+"&r="+GHutils.getMinutesTimestamp(), function (templates) {
			if(typeof templates !="string"){
				templates=""
			}
			var begin = templates.indexOf('<body');
			var end = templates.indexOf('</body>');
			var temp = templates.substring(begin, end);
			$(".cents").html(temp);
			// 借款协议
			var btns = $('.box .goWebView');
			for (var i = btns.length - 1; i >= 0; i--) {
				GHutils.addProtocols($(btns[i]));
			}
		});
		$.get("/actives1/product/getV1CurrentIncome?productOid=" + oid+"&r="+GHutils.getMinutesTimestamp(), function (templates) {
			if(typeof templates !="string"){
				templates=""
			}
			var begin = templates.indexOf('<body');
			var end = templates.indexOf('</body>');
			var temp = templates.substring(begin, end);
			$(".cent3s").html(temp);
		});
	},
	pageInit: function () {
		var _this = this;
		var content = {
			serviceFilesContent: '',
			investFilesContent: ''
		}
		var uraParam = GHutils.parseUrlParam(window.location.href)
		if (uraParam.productOid) {
			_this.getDetail(uraParam.productOid);
			productInfo(uraParam.productOid)
			return false;
		} else {
			productInfo();
		}

		//产品详情
		function productInfo(oid) {
			GHutils.load({
				url: "/actives1/product/getV1CurrentDetail",
				data: { productOid: oid },
				type: "post",
				callback: function (result) {
					var product = result.data.content;
					if (result.code == 10000) {
						if (!oid) _this.getDetail(product.oid);
						$('#productName').html(product.productName)
						$('#tableProductName').html(product.productName) //可用不可用
						//产品标签是只选第一个
						var labels = "";
						for (var i in product.labelList) {
							if (product.labelList[i].labelType == "extend") {
								labels += '<span class="quick_banner_yu_tui">' + product.labelList[i].labelName + '</span>';
							}
						}
						$('#durationName').html(product.durationName);
						$('#paybackName').html(product.paybackTypeName);
						$('#label').html(labels)
						if (product.state == 'RAISED' || product.state == 'CLEARED') {
							$('#goInvest').css({
								'background': 'grey',
								'color': '#FFFFFF'
							}).html('已售罄').off()
						} else if (GHutils.getProductStatus(product.state) == -1) {
							$('#goInvest').css({
								'background': 'grey',
								'color': '#FFFFFF'
							}).html('待售').off() //立即抢购按钮置灰
						} else if (GHutils.getProductStatus(product.state) == 0 || product.state == 'DURATIONING') {
							enable = true
							btnTxt = '立即抢购';
						}

						var interest = GHutils.toFixeds(product.expAror, 2);
						interest += '<span style="font-size:26px">%</span>';
						if (product.rewardInterest&&(product.rewardInterest-0)) {
							interest += '<span><span style="font-size:26px">+</span>' + GHutils.toFixeds(product.rewardInterest, 2) + '<span style="font-size:26px">%</span></span>'
						}
						_this.param.annualInterestSec = switchShowType(product, false);
						$('#annualInterestSec').html(interest).css({
							"font-size": "44px"
						})
						$('#investMin').html(GHutils.formatIntCurrencys(product.investMin ? product.investMin : 0) + '<span style="font-size:26px">元<span>')
						_this.param=product;
						_this.param.minMoney = (product.investMin == null ? 0 : product.investMin)
						_this.param.addMoney = product.increaseInvestAmount
						_this.param.incomeCalcBasis = parseInt(product.incomeCalcBasis)
						_this.param.productOid = product.oid
						_this.param.typeCode = product.typeCode
						_this.param.lockCollectedVolume = product.collectedVolume
						GHutils.colculate("t0",_this.param.incomeCalcBasis);
						$("#introduce-purchasingAmount").html(_this.param.minMoney)
						$("#introduce-increaseAmount").html(_this.param.addMoney)
						$('.introduce-productName').html(product.productName)
						$('#introduce-investDay').html(product.investTime)
						$('#introduce-income').html(product.interestsFirstDate)
						$('#introduce-incomeDay').html(product.interestsPayBackDate)
						$('#invest').attr('placeholder', (GHutils.formatCurrencys(_this.param.minMoney) + '元起投，' + GHutils.formatCurrency(_this.param.addMoney) + '元递增'))
						_this.getData(1, true, product.oid)
						//风险提示书
						$("#serviceFiles").on("click", function () {
							if ($(this).hasClass("app_btn_loading")) {
								return
							}
							$(this).addClass("app_btn_loading")
							$("#title").html("风险提示书")
							$("#content").html('');
							if (_this.param.serviceFiles && _this.param.serviceFiles.furl) {
								$.get(_this.param.serviceFiles.furl, function (templates) {
									var begin = templates.indexOf('<body');
									var end = templates.indexOf('</body>');
									var temp = templates.substr(begin, end);
									$("#content").html(temp);
								});
								$("#content-box").modal("show")
								$("#serviceFiles").removeClass("app_btn_loading")
							}
						})
						//转让页面过来自动填写金额
						var withdrawMoney = GHutils.parseUrlParam(window.location.href).withdrawMoney
						if (withdrawMoney) {
							$("#invest").val(withdrawMoney)
							_this.param.pType="t0"
							GHutils.calcIncome(withdrawMoney,_this.param,function(income){
								if(income=="calcing"){
									$('#income').html("计算中");
								}else{
									$('#income').html('<font color="#e45038">'+income+'</font>元');
								}
							});
						}
						// GHutils.addProtocols('.invest-protocol', 0, _this.param.investFiles.furl);
					} else {
						$('#invest_errorMessage').html(GHutils.errorMessage(result.message))
					}
				}
			});
		}

		function switchShowType(tradeObj, detail) {
			interestSec = tradeObj.expAror;
			if (tradeObj.rewardInterest) {
				interestSec += "+" + GHutils.toFixeds(tradeObj.rewardInterest, 2)
			}
			return interestSec;
		}

	},
	
	bindEvent: function () {
		var _this = this;

		// 添加收益 历史年化提示
		$(".recordsincome").on("mouseover", function () {
			var widthint = parseInt($("#income").css("width")) - 56
			widthint = 36 - widthint / 2
			$(".incomehint").css("left", widthint + "px")
			$(".incomehint").show()
		})
		$(".recordsincome").on("mouseout", function () {
			$(".incomehint").hide()
		})


		var investMoney = 0
		//监听投资借文本框change事件
		$('#invest')
			.on('focus', function () {
				$('#invest').keyup(function (e) {
					var money = $(this).val()
					if (money) {
						//正则表达式??????????????????????????????????//////
						if (money.match(/^(([1-9]\d*)|0)(\.\d{0,2})?$/g) || money.match(/^[1-9]\d*?$/g) || ('' + money).indexOf('.') == (money.length - 1)) {
							money = parseFloat(money)
							if (money < _this.param.minMoney) {
								return false;
							} else if (GHutils.Fdiv(GHutils.Fsub(money, _this.param.minMoney), _this.param.addMoney) % 1 != 0) { }
							investMoney = money
							_this.param.pType="t0"
							GHutils.calcIncome(investMoney,_this.param,function(income){
								if(income=="calcing"){
									$('#income').html("计算中");
								}else{
									$('#income').html('<font color="#e45038">'+income+'</font>元');
								}
							})
							
						} else {
							$('#invest_errorMessage').html(GHutils.errorMessage('投资金额格式不正确'))
							return false;
						}
					}else{
						$('#income').html('<font color="#e45038">0.00</font>元')
					}
					$('#invest_errorMessage').html('&nbsp;')
					investMoney = parseFloat(money == '' ? 0 : money)
				})

			})
			.on('blur', function () {
				$(document).off('keyup')
			})

		//计算收益investMoney 金额   procent收益率    n开n次方
		_this.coculateIncome  = function(investMoney, n) {
			var idx = _this.param.annualInterestSec.indexOf('+')
			var result = ''
			if (idx > -1) { //有奖励收益
				var rewardInterest = _this.param.annualInterestSec.substr(idx + 1).replace("%", "")
				var procent = parseFloat(_this.param.annualInterestSec.substring(0, idx).replace("%", "")) + parseFloat(rewardInterest)
				result = counts(investMoney, procent, n)
			} else { //没有
				var idx1 = _this.param.annualInterestSec.indexOf('-')
				if (idx1 > -1) {
					var min = parseFloat(_this.param.annualInterestSec.substring(0, idx1).replace("%", ""))
					var max = parseFloat(_this.param.annualInterestSec.substr(idx1 + 1).replace("%", ""))
					result = counts(investMoney, min, n) + '元到' + counts(investMoney, max, n)
				} else {
					var procent = parseFloat(_this.param.annualInterestSec.replace("%", ""))
					result = counts(investMoney, procent, n)
				}
			}
			return result
		}

		function counts(investMoney, procent, n) {
			// return GHutils.formatCurrency(GHutils.toFixeds(GHutils.Fmul(investMoney, Math.pow(GHutils.Fadd(1, GHutils.Fdiv(procent, 100)), 1 / n) - 1), 2))
			return GHutils.formatCurrency(GHutils.Fdiv(GHutils.Fmul(investMoney, GHutils.Fmul(procent, GHutils.Fdiv(1, n))), 100))

		}
		//点击减号
		$('#descInvest').on('click', function () {
			var money = $('#invest').val()
			if (money) {
				if (!/^\d+(\.\d+)?$/.test(money)) {
					$('#invest_errorMessage').html(GHutils.errorMessage('投资金额格式不正确'))
					return false;
				} else {
					money = parseFloat(money)
				}
			}
			investMoney = parseFloat(money == '' ? 0 : money)
			investMoney = GHutils.Fsub(investMoney, _this.param.addMoney)
			if (investMoney < _this.param.minMoney) {
				$('#invest').val('')
				investMoney = 0
				$('#income').html('<font color="#e45038">0.00</font>元')
				return false;
			}
			$('#invest').val(investMoney)
			var procent = $('#annualInterestSec').html()
			procent = parseFloat(procent.substring(0, procent.length - 2));
			GHutils.calcIncome(investMoney,_this.param,function(income){
				if(income=="calcing"){
					$('#income').html("计算中");
				}else{
					$('#income').html('<font color="#e45038">'+income+'</font>元');
				}
			});
		})

		//点击加号图标
		$('#adInvest').on('click', function () {
			var money = $('#invest').val()
			if (money) {
				if (!/^\d+(\.\d+)?$/.test(money)) {
					$('#invest_errorMessage').html(GHutils.errorMessage('投资金额格式不正确'))
					return false;
				} else { }
			}
			investMoney = parseFloat(money == '' ? 0 : money)
			if (investMoney == 0 && _this.param.addMoney < _this.param.minMoney) {
				investMoney = GHutils.Fadd(investMoney, _this.param.minMoney)
			} else {
				investMoney = GHutils.Fadd(investMoney, _this.param.addMoney)
			}
			$('#invest').val(investMoney)
			var procent = parseFloat($('#annualInterestSec').html().split('%')[0])
			GHutils.calcIncome(investMoney,_this.param,function(income){
				if(income=="calcing"){
					$('#income').html("计算中");
				}else{
					$('#income').html('<font color="#e45038">'+income+'</font>元');
				}
			});
		})
		//点击立即抢购
		$('#goInvest').on('click', function () {
			if (GHutils.getUserInfo()) {
				var money = $('#invest').val()
				if (money && !/^\d+(\.\d+)?$/.test(money)) {
					$('#invest_errorMessage').html(GHutils.errorMessage('投资金额格式不正确'))
					return false;
				}
				investMoney = parseFloat($('#invest').val())
				if (!investMoney) {
					$('#invest_errorMessage').html(GHutils.errorMessage('投资金额不能为空'))
					return false;
				}
				productInformation();
			} else {
				// $("#showLogin").trigger("click");
				location.href = "/regandlog.html?type=log";
			}
		})

		function getMaxInvestMoney() {
			if (investMoney < _this.param.minMoney) {
				$('#invest_errorMessage').html(GHutils.errorMessage('投资金额不可低于起投金额 ' + GHutils.formatCurrency(_this.param.minMoney) + '元'))
				return false;
			} else if (GHutils.Fdiv(GHutils.Fsub(investMoney, _this.param.minMoney), _this.param.addMoney) % 1 != 0) {
				$('#invest_errorMessage').html(GHutils.errorMessage('投资金额不可低于' + GHutils.formatCurrency(_this.param.minMoney) + '元,且为' + GHutils.formatCurrency(_this.param.addMoney) + '元的整数倍递增。 '))
				return false;
			}
			GHutils.load({
				url: "/assignTrans/order/invest/current/prepose",
				data: {
					productId: _this.param.productOid
				},
				type: "post",
				callback: function (result) {
					if (result.code == 10000) {
						// if(investMoney > GHutils.Fsub(_this.param.maxTotalAmount, result.data.totalInvestAmount)||investMoney>_this.param.maxSaleVolume) {
						//     $('#invest_errorMessage').html(GHutils.errorMessage('金额不可超过最大可投金额'))
						//     return false;
						// }
                        if(result.data.valid) {
                            if (investMoney > result.data.maxInvestAmount) {
                                $('#invest_errorMessage').html(GHutils.errorMessage('金额不可超过最大可投金额'))
                                return false;
                            }
                            window.location.href = 'account-apply.html?moneyVolume=' + investMoney + '&productOid=' + _this.param.productOid + '&pType=t0&pName=' + encodeURI(_this.param.productName) + '&dpDays=' + _this.param.durationPeriodDays + '&income=' + _this.param.incomeCalcBasis;
						} else {
                            $('#invest_errorMessage').html(result.data.validDesc)
                        }
					} else {
						$('#invest_errorMessage').html(GHutils.errorMessage(result.message))
						return false;
					}
				}
			})
		}

		//产品详情
		var productInformation = function () {
			if (GHutils.forEach(_this.param.labelList, function (idx, lable) {
				if (lable.labelNo == '8') {
					$('#invest_errorMessage').html(GHutils.errorMessage('体验金 产品无法购买'))
					return true;
				}
			})) {
				return false;
			}
			getMaxInvestMoney()
		}
	},
	
	createPage: function (pageCount, proOid) {
		$(".tcdPageCode").show()
		if (pageCount <= 1) {
			$(".tcdPageCode").hide()
		}
		var _this = this;
		$(".tcdPageCode").createPage({
			pageCount: pageCount,
			current: 1,
			backFn: function (page) {
				_this.getData(page, false, proOid);
			}
		});
	},
	getData: function (page, isFlag, productOid) {
		var _this = this;
		GHutils.load({
			url: "/actives1/product/getV1InvestRecord",
			data: {
                productType: _this.param.typeCode,
				productOid: productOid,
				pageInfo: {
					pageNo: page,
					pageSize: 10,
				}
			},
			type: "post",
			callback: function (result) {
				if (result.code != 10000) {
					return false;
				}
				if (result.data.pageInfo.totalSize == 0) {
					return false;
				}
				$('#noReCord').addClass('none')
				$('#investRecords').removeClass('none')
				var tds = '<li class="tits col-xs-12"><p class="col-xs-4" style="text-align:left;">投资用户</p><p class="col-xs-4">投资金额</p><p class="col-xs-4" style="text-align:right;">投资时间</p></li>';
				var idx = 0;
				GHutils.forEach(result.data.content, function (idx, record) {
					tds += '<li class="titscon tr_w_h col-xs-12 tr_coor ' + (idx % 2 == 1 ? 'active' : '') + '"><p class="col-xs-4" style="text-align:left;">' + (record.userPhone || '') + '</p><p class="col-xs-4">' + GHutils.formatCurrency(record.orderAmount) + '元</p><p class="col-xs-4" style="text-align:right;">' + GHutils.formatTimestamp({
						time: record.createTime,
						showtime: "false"
					}) + '</p><p></p><p class="f_color_1"></p></li>'
				})
				$('#investRecords').html(tds)
				if (isFlag) {
					_this.createPage(Math.ceil(result.data.pageInfo.totalSize / 10), productOid);
				}
			}
		})
	}
}

$(function () {
	new HUOQI().init();
	$(".boxs").on("click", "li", function () {
		var index = $(this).index();
		var cName = $(this).attr("class");
		if (cName != "active") {
			if (index == 0) {
				$('.top_lines').animate({
					'left': '0'
				}, 300);
			} else if (index == 1) {
				$('.top_lines').animate({
					'left': '400px'
				}, 300);
			} else {
				$('.top_lines').animate({
					'left': '800px'
				}, 300);
			}
		}
	})

})