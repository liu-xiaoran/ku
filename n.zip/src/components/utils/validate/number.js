export default function number(value) {
  return /^\d+$/.test(value);
}
