define([],
function() {
	return {
		name: 'payPwd',
		init: function() {
			var param = {
				bankName: '',
				bankCode: '',
				cardOrderId: ''
			}
			var FUN = (function() {
				return {
					init: function() {
						this.bindEvent();
						this.tips1 = $("#forget_pay_tips");
					},
					bindEvent: function() {
						var _this = FUN;
						//绑定回车键
						GHutils.inputBindKey();
						//打开设置交易密码的弹窗
						$('#setPayPwd').off().on('click', function() {
							_this.clearModle()
							$('#setBankPwd').modal('show');
							GHutils.boxSwitch(".modalBox", "#setPayPwdBox");
						});
						//设置交易密码 步骤一
						$('#setPayPwd1').off().on('click', function() {
                            if(GHutils.getUserInfo()) {
                                if(GHutils.validate("setPayPwdBox")) {
                                    // GHutils.boxSwitch(".modalBox", "#setPayPwdBoxConfrm");
                                    $(this).addClass("btn_loading")
                                    _this.setPayPwd();
                                }
							} else {
                                window.location.href = "index.html"
                            }
						});
						//设置交易密码 步骤二  先判断是否登录
						$('#setPayPwd2').off().on('click', function() {
							if(GHutils.getUserInfo()) {
								if(GHutils.validate("setPayPwdBoxConfrm")) {
									$('#setPayPwd2').addClass("btn_loading")
									_this.setPayPwd();
								}
							} else {
								window.location.href = "index.html"
							}
						});
						//打开修改交易密码弹窗
						$('#modifyPayPassword').off().on('click', function() {
							if(GHutils.getUserInfo()) {
								_this.clearModle();
								$('#modifyPaypwd').modal('show');
								GHutils.boxSwitch(".modalBox", "#changePayPwdBox");
							} else {
								window.location.href = "index.html"
							}
						});
						//确认修改密码
						$('#modify_pay_pwd').off().on('click', function() {
							if(GHutils.validate("changePayPwdBox")) {
								_this.modifyPaypwdMethod(GHutils.trim($('#oldPayPassword').val()), GHutils.trim($('#newPayPassword').val()));
								$('#modify_pay_pwd').addClass("btn_loading")
							}
						});
						//忘记交易密码
						$("#showForgetPwd").off().on("click", function() {
							_this.clearModle()
							GHutils.boxSwitch(".modalBox", "#forgetPaypwdBox");
							var phn = GHutils.userinfo.phone;
							$("#phoneNum_input").val(phn).attr("data-phone", phn);
							$("#fogetPaypwd").modal("show");
						});
						//获取忘记交易密码短信
						$("#vericode_btn").off().on("click", function() {
							_this.tips1.html('');
							if($(this).hasClass("btn_loading")) {
								return
							}
							_this.getPhoneCode();
						});
						//找回密码
						$("#forget_pay_pwd").off().on("click", function() {
							$(_this.tips1).html('');
							if($(this).hasClass("btn_loading")) {
								return
							}
							if(GHutils.validate("forgetPaypwdBox")) {
								$("#forget_pay_pwd").addClass("btn_loading");
								$(_this.tips1).html('');
								_this.setNewPayPwd();
							}
						});
					},
					setPayPwd: function() {
						var _this = FUN;
						var userinfo = GHutils.getUserInfo();
						GHutils.load({
							url: "/payment/account/setPayPwd",
							data: {
								password: GHutils.trim($('#bank_pay_pwd1').val())
							},
							type: "post",
							callback: function(result) {
								if(result.code == 10000) {
									GHutils.boxSwitch(".modalBox", "#setPayPwdSucced");
									GHutils.updateUserInfo({
										isPayPwd: 1
									});
									window.pageFun.callBackFun();
								} else {
									GHutils.boxSwitch(".modalBox", "#setPayPwdFaild");
									if(result.message.indexOf("已设定") >= 0) {
										GHutils.updateUserInfo({
											isPayPwd: 1
										});
									}
								}
								$('#setPayPwd2').removeClass("btn_loading")
							},
							errcallback: function() {
								$("#setPayPwd2").removeClass('btn_loading')
							}
						})
					},
					//修改支付密码
					modifyPaypwdMethod: function(oldPaypwd, newPaypwd) {
						var _this = this;
						GHutils.load({
							url: "/payment/account/modifyPayPwd",
							data: {
								oldPassword: oldPaypwd,
								newPassword: newPaypwd
							},
							type: 'post',
							callback: function(result) {
								if(result.code == 10000) {
									GHutils.boxSwitch(".modalBox", "#changeBankPwdSucced");
								} else {
									$("#modify_pay_tips").html(GHutils.errorMessage(result.message));
								}
								$("#modify_pay_pwd").removeClass('btn_loading')
							},
							errcallback: function() {
								$("#modify_pay_pwd").removeClass('btn_loading')
							}
						})
					},
					getPhoneCode: function() {
						var _this = this;
						$("#vericode_btn").addClass("btn_loading");
						// 获取验证码之前 查看用户锁定状态
						_this.getVerifyCode();
					},
					getVerifyCode: function(val) {
						var _this = this;
						$(_this.tips1).html('');
						var userPhone = val;
						_this.btntimeVerifyCode = null;
						GHutils.load({
							url: "/platform1/Userpub/sendsms",
							data: {
								smsType: "payPwdUpdate"
							},
							type: "post",
							callback: function(result) {
								if(result.code == 10000||result.code == 99995) {
                                    _this.btntimeVerifyCode = GHutils.btnTime($("#vericode_btn"),(result.data.ttl||120));
								}
								if(result.code != 10000) {
									$(_this.tips1).html(GHutils.errorMessage(result.message));
									$("#vericode_btn").removeClass("btn_loading");
									return false;
								}
							},
							errcallback: function() {
								$("#vericode_btn").removeClass("btn_loading");
								if(_this.btntimeVerifyCode) {
									GHutils.clearBtnTime(_this.btntimeVerifyCode, $("#vericode_btn"));
								}
							}
						});
					},
					setNewPayPwd: function() {
						var _this = this;

						GHutils.load({
							url: "/payment/account/resetPayPwd",
							data: {
								securityCode: GHutils.trim($("#verifyCodeNo").val()),
								newPassword: $("#newPayPassWord").val(),
							},
							type: "post",
							callback: function(result) {
								console.log(result)
								if(result.code == 10000) {
									GHutils.updateUserInfo({
										isPayPwd: 1
									});
									GHutils.boxSwitch(".modalBox", "#forgetBankPwdSucced");
									window.pageFun.callBackFun();
								} else {
									GHutils.checkErrorCode(result, _this.tips1)
								}
								$("#forget_pay_pwd").removeClass("btn_loading");
							},
							errcallback: function() {
								$("#forget_pay_pwd").removeClass("btn_loading");
							}
						})
					},
					clearModle: function() {
						var _this = FUN;
						$('.fromModel input').val('');
						$(".form_tips_box").html('');
						GHutils.clearBtnTime(_this.btntime, $("#card_verifyCode"));
						if(_this.btntimeVerifyCode) {
							GHutils.clearBtnTime(_this.btntimeVerifyCode, $("#vericode_btn"));
						}
					}
				};
			})();
			$(function() {
				FUN.init();
			});
		}
	}
})