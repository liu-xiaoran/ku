// if(window["\x6c\x6f\x63\x61\x74\x69\x6f\x6e"]["\x68\x6f\x73\x74"]!='www.zhangyuelicai.com'&&window["\x6c\x6f\x63\x61\x74\x69\x6f\x6e"]["\x68\x6f\x73\x74"] != 'zhangyuelicai.com'&&window["\x6c\x6f\x63\x61\x74\x69\x6f\x6e"]["\x68\x6f\x73\x74"] != '106.14.25.126'&&window["\x6c\x6f\x63\x61\x74\x69\x6f\x6e"]["\x68\x6f\x73\x74"] != '106.14.236.8'&&window["\x6c\x6f\x63\x61\x74\x69\x6f\x6e"]["\x68\x6f\x73\x74"] != '106.14.19.131'){
//   alert('警告！检测到该网站为恶意镜像站点，将立即为您跳转到官方站点！');
//   window["\x6c\x6f\x63\x61\x74\x69\x6f\x6e"]["\x68\x72\x65\x66"] = 'https://'+'www.zhangyuelicai.com/';
// }

var str = location.href;
if(str.indexOf('mei2ti3bao4dao4') >= 0) {
	location.href = '/information/mtbd/';
}
if(str.indexOf('xin1wen2dong4tai4') >= 0) {
	location.href = '/information/xwdt/';
}
if(str.indexOf('li3cai2zhi1shi1') >= 0) {
	location.href = '/information/lczs/';
}
if(str.indexOf('xing2ye4dong4tai4') >= 0) {
	location.href = '/information/hydt/';
}
if(str.indexOf('hu4lian2wang3jin1rong2') >= 0) {
	location.href = '/information/hlwjr/';
}
if(str.indexOf('wang3dai4xing2ye4jie4shao4') >= 0) {
	location.href = '/information/wdhyjs/';
}

var GHutils = {}

var HOST = "";

var contractId_pc = "999920171021100000"
var contractId = "999920171021100000"

//生产环境环境（地址：https://www.zhangyuelicai.com）
var channelOid = "2"
var cid = "1"
var ckey = "PC20170301"
var returnUrl = location.origin
var formKey,timer,request//计算收益相关参数
GHutils.constant = {
	userStatus: "userStatus",
}

GHutils.userinfo = null;

GHutils.errorMessage = function(message) {
	return '<div style="font-size:14px;color:#666;line-height:17px;"><img style="vertical-align:sub;" src="static/images/land_jg.png" /> '+message+'</div>';
}
//ajax请求
GHutils.load = function(op) {
	if(!op || !op.url) {
		return;
	}
	if(op.params) {
		op.url = op.url + "?" + decodeURIComponent($.param(op.params));
	}
	if(op.sp) {
		GHutils.processingShow();
	}
	var data={}
	
	if(typeof ZYLIB != "undefined"){
		data=JSON.stringify(ZYLIB.req({
			contractId: (op.url.indexOf("Userpub/login")>=0?contractId:contractId_pc),
			data: op.data || "",
			extendInfo: op.extendInfo
		}))
	}
	var set = {
		type: op.type || "post",
		url: op.url,
		async: op.async == false ? false : true,
		data: data,
		contentType: op.contentType || "application/json",
		dataType: op.dataType||"json",
		success: function() {
			if(arguments[0].code == 10001) {
				GHutils.setCookie("headerinfo", "")
				GHutils.userinfo = null;
				if((new Date()).getTime() - GHutils.pageLoadedTime <= 1000) {
					if(window.location.pathname.indexOf("account") >= 0 || window.location.pathname.indexOf("product-redeem") >= 0) {
						window.location.href = "index.html"
						return false
					}
				}
			}else if(arguments[0].code == 99999&&op.url!='/actives1/Loger/sendWarningLog'){
				GHutils.writeLoad({
					url:'/actives1/Loger/sendWarningLog',
					data:{
						data:{
							"type": "PC",
							'content':{
								"errorApi": window.origin+op.url,
								"errorMsg":arguments[0]
							}
							
						}
					}
				}) 
			}

			if(op.sp) {
				GHutils.processingHide();
			}
			if(op.callback && typeof(op.callback) == 'function') {
				// if (GHutils.preErrorHandle(arguments[0],op.loginStatus)) {
				op.callback.apply(null, arguments);
				// }
			}
		},
		timeout: 20000,
		error: function(xhr, type, errorThrown) {
			if(op.sp) {
				GHutils.processingHide();
			}
			//window.console && console.log && console.log(type);
			if(op.errcallback) {
				op.errcallback();
			}
		}
	};
	return $.ajax(set);
}

//
GHutils.preErrorHandle = function(resp, loginStatus) {
	var errcode = resp.errorCode
	var isFlag = true
	if(errcode == "40004") {
		window.location.href = "repair.html";
	}
	if(errcode == "E10001") {
		//GHLocalStorage.clear();
		GHutils.loginOut(true);
	}
	if(errcode == "10001") {
		if(loginStatus && typeof(loginStatus) == 'function') {
			loginStatus(resp)
			isFlag = false
		}
	}
	return isFlag;
}

//格式化时间格式
/*param{
 * data:time,
 * type:0,
 * showtime:"true"
 * }
 *
 *
 * */
GHutils.formatTimestamp = function(param) {
	var d = new Date();
	d.setTime(param && param.time || d);
	var datetime = null;
	var x = d.getFullYear() + "-" + (d.getMonth() < 9 ? "0" : "") + (d.getMonth() + 1) + "-" + (d.getDate() < 10 ? "0" : "") + d.getDate();
	var y = (d.getHours() < 10 ? " 0" : " ") + d.getHours() + ":" + (d.getMinutes() < 10 ? "0" : "") + d.getMinutes() + ":" + (d.getSeconds() < 10 ? "0" : "") + d.getSeconds();

	if(param.showtime == "false") {
		datetime = x + y;
	} else {
		datetime = x;
	}

	return datetime;
}

GHutils.addDate = function(date, days) {
	var d = new Date(date);
	d.setDate(d.getDate() + days);
	var month = d.getMonth() + 1;
	var day = d.getDate();
	if(month < 10) {
		month = "0" + month;
	}
	if(day < 10) {
		day = "0" + day;
	}
	var val = d.getFullYear() + "-" + month + "-" + day;
	return val;
}

GHutils.getMinutesTimestamp=function(){
	var d = new Date();
	d.setSeconds(0);
	return d.getTime()
}
//获取验证码按钮倒计时
GHutils.btnTime = function(obj,time) {
	var btntime = null;
	if(obj) {
		var t = time||120;
		btntime = setInterval(function() {
			if(t >= 0) {
				obj.addClass("btn_loading");
				obj.html('重新获取(' + t + ')');
				t--;
			} else {
				obj.removeClass("btn_loading");
				obj.removeAttr("disabled");
				obj.html("获取验证码");
				clearInterval(btntime);
				t = 120;
			}
		}, 1000)
	}
	return btntime
}
//清楚按钮倒计时
GHutils.clearBtnTime = function(btnTime, obj) {
	if(obj) {
		obj.removeClass("btn_loading");
		obj.removeAttr("disabled");
		obj.html("获取验证码");
		clearInterval(btnTime);
	}
}

/**
 * 将数值截取后2位小数,格式化成金额形式
 *
 * @param num 数值(Number或者String)
 * @return 金额格式的字符串,如'1,234,567.45'
 * @type String
 */
GHutils.formatCurrency = function(num) {
	num += ''
	num = num.toString().replace(/\$|\,/g, '');
	if(isNaN(num))
		num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(GHutils.Fmul(num, 100));
	if(isNaN(num))
		num = "0";
	cents = num % 100;
	num = Math.floor(num / 100).toString();
	if(cents < 10)
		cents = "0" + cents;
	for(var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
		num = num.substring(0, num.length - (4 * i + 3)) + ',' +
		num.substring(num.length - (4 * i + 3));
	return(((sign) ? '' : '-') + num + '.' + cents);
}


GHutils.formatCurrencys = function(num) {
	num += ''
	num = num.toString().replace(/\$|\,/g, '');
	if(isNaN(num))
		num = "0";
	sign = (num == (num = Math.abs(num)));
	num = Math.floor(GHutils.Fmul(num, 100));
	if(isNaN(num))
		num = "0";
	cents = num % 100;
	num = Math.floor(num / 100).toString();
	if(cents < 10)
		cents = "0" + cents;
	if(num.length >= 5&&num.length < 9) {
		return(((sign) ? '' : '-') + num*0.0001 + '.' + cents + '万');
	} else if(num.length >= 9) {
		return(((sign) ? '' : '-') + num*0.00000001 + '.' + cents + '亿');
	} else {
		return(((sign) ? '' : '-') + num + '.' + cents);
	}
}


GHutils.formatIntCurrencys = function(num) {
	var nums = num;
	if(num.toString().indexOf('.')>=0) {
        nums = nums.toString().split('.')[0]
	}
	nums = parseInt(nums.toString().replace(/\$|\,/g, '')).toString();
	if(nums.length >= 5&&nums.length < 9) {
		num = num*0.0001 + '<span style="font-size:26px">万</span>'
	} else if(nums.length >= 9) {
		num = num*0.00000001 + '<span style="font-size:26px">亿</span>'
	} else {
        num = num*1
	}
	return num;
}

GHutils.formatIntCurrency = function(num) {
	num = parseInt(num.toString().replace(/\$|\,/g, '')).toString();
	if(isNaN(num))
		num = "0";
	for(var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++)
		num = num.substring(0, num.length - (4 * i + 3)) + ',' +
		num.substring(num.length - (4 * i + 3));
	return num;
}
GHutils.tableToExcel = (function() {
	var uri = 'data:application/vnd.ms-excel;base64,',
		template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{worksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body><table>{table}</table></body></html>',
		base64 = function(s) {
			return window.btoa(unescape(encodeURIComponent(s)))
		},
		format = function(s, c) {
			return s.replace(/{(\w+)}/g, function(m, p) {
				return c[p];
			})
		}
	return function(table, name) {
		if(!table.nodeType) table = document.getElementById(table)
		var ctx = {
			worksheet: name || 'Worksheet',
			table: table.innerHTML
		}
		window.location.href = uri + base64(format(template, ctx))
	}
})();
//修复JS浮点的加减乘除运算 Fadd加 Fsub减 Fmul乘 Fdiv除
GHutils.Fadd = function(a, b) {
	var c, d, e;
	try {
		c = a.toString().split(".")[1].length;
	} catch(f) {
		c = 0;
	}
	try {
		d = b.toString().split(".")[1].length;
	} catch(f) {
		d = 0;
	}
	return e = Math.pow(10, Math.max(c, d)), (GHutils.Fmul(a, e) + GHutils.Fmul(b, e)) / e;
}
GHutils.Fsub = function(a, b) {
	var c, d, e;
	try {
		c = a.toString().split(".")[1].length;
	} catch(f) {
		c = 0;
	}
	try {
		d = b.toString().split(".")[1].length;
	} catch(f) {
		d = 0;
	}
	return e = Math.pow(10, Math.max(c, d)), (GHutils.Fmul(a, e) - GHutils.Fmul(b, e)) / e;
}

GHutils.Fmul = function(a, b) {
	var c = 0,
		d = a.toString(),
		e = b.toString();
	try {
		c += d.split(".")[1].length;
	} catch(f) {}
	try {
		c += e.split(".")[1].length;
	} catch(f) {}
	return Number(d.replace(".", "")) * Number(e.replace(".", "")) / Math.pow(10, c);
}

GHutils.Fdiv = function(a, b) {
	var c, d, e = 0,
		f = 0;
	try {
		e = a.toString().split(".")[1].length;
	} catch(g) {}
	try {
		f = b.toString().split(".")[1].length;
	} catch(g) {}
	return c = Number(a.toString().replace(".", "")), d = Number(b.toString().replace(".", "")), GHutils.Fmul(c / d, Math.pow(10, f - e));
}
//转几位小数点（按位数截取），带后缀（单位）GHutils.toFixed(10000,4,"元") = 10000.0000元
GHutils.toFixeds = function(numb, digital, suffix) {
	var digital = digital ? digital : 0;
	var fixed = 1;
	for(var i = 0; i < digital; i++) {
		fixed = fixed * 10;
	}

	if(numb == undefined || numb.length == 0) {
		return "--";
	} else {
		var numb = GHutils.Fmul(Number(numb), fixed);
		return(parseInt(numb) / fixed).toFixed(digital) + (suffix ? suffix : "");
	}
}
//获取浏览器URL参数
GHutils.parseUrlParam = function(url) {
	var urlParam = {};
	if(url.indexOf("?") < 0) {
		return urlParam;
	}
	var params = url.substring(url.indexOf("?") + 1).split("&");
	for(var i = 0; i < params.length; i++) {
		var k = params[i].substring(0, params[i].indexOf("="));
		var v = params[i].substring(params[i].indexOf("=") + 1);
		if(v.indexOf("#") > 0) {
			v = v.substring(0, v.indexOf("#"));
		}
		urlParam[k] = v;
	}
	return urlParam;
}

//回退
GHutils.goback = function(trace) {
	if(!trace) {
		history.go(-1);
	} else {
		window.location.href = trace;
	}
}

GHutils.checkErrorCode = function(result, tips) {
	var that = this;
	var tips = tips || false;
	var icon = '<span class="app-icon app-icon-clear"></span>';
	//that.log(result);
	if(result.code == 10000) {
		return true;
	} else {
		if(tips) {
			$(tips).html(result.message);

		} else {
			alert(result.message);
		}
		GHutils.processingHide();
		return false;
	}
}

//打印信息
GHutils.log = function(msg) {
	console.log(JSON.stringify(msg));
}
//悬浮提示
GHutils.warn = function(content) {
	$.tips({
		content: content,
		stayTime: 2000,
		type: "warn"
	})
}

GHutils.showError = function(content, tips) {
	if(tips) {
		var icon = '<img style="vertical-align:sub;" src="static/images/land_jg.png" />  '; //<span class="app-icon app-icon-clear"></span>
		$(tips).html('<div style="font-size:14px;color:#666;line-height:17px;">'+icon + content+'</div>');
		return
	}
	if(content) {
		GHutils.warn(content);
	}
}

GHutils.bindClear = function() {
	$(".ui-icon-close").on("click", function(e) {
		$(this).parent().find("input").val("");
	})
}

GHutils.processingShow = function(cnt) {
	var cnt = cnt || 　'处理中...'
	this.loading = $.loading({
		content: cnt,
	})
}

GHutils.processingHide = function() {
	if(this.loading) {
		this.loading.loading("hide");
	}
}
//打开列表链接
GHutils.listlink = function() {
	if($ && $(".ui-arrowlink")) {
		$(".ui-arrowlink").on("tap", function() {
			var href = $(this).attr("target-href");
			if(href) {
				location.href = href;
			}
		})
	}
}

GHutils.bindEvent = function() {
	window.onhashchange = function() {
		var href = location.href;
		if(href.lastIndexOf("#") > 0) {
			var step = href.substring(href.lastIndexOf("#"));
			if(step) {
				$(".steps").forEach(function(e, i) {
					$(e).hide();
				});
				$(step).show();
			}
		}
	}
	//页面连接
	$(".app_nav_links").on("click", function() {
		var _href = $(this).attr("data-href");
		window.location.href = _href;
	});
	//页面内跳转
	$(".app_gostep").on("click", function() {
		var _step = $(this).attr("data-step");
		GHutils.goStep(_step);
	});
}
GHutils.bindKeyDown = function() {
	$("input").on("keyup", function(e) {
		var _val = $(this).val();
		if(e.keyCode == 13) {
			var tid = $(this).attr("triggerId");
			if(tid) {
				$(tid).trigger("click");
			}
		}
	});
}
//单页面内部显示切换
GHutils.goStep = function(step) {
	location.href = "#" + step;
}

GHutils.bindEventBanner = function() {
	$(".app_nav_links").on("click", function() {
		var _href = $(this).attr("data-href");
		window.location.href = _href;
	});
}

//表单输入验证
GHutils.checkInput = function(obj, regnum) {
	var regTel = /^[0-9]{0,11}$/g; //电话号码(0)
	var regPwd = /^([\x21-\x7e]|[a-zA-Z0-9]){0,16}$/g; //密码(1)
	var regNum = /^\d+$/g; //纯数字(2)
	var regNump = /^(([1-9]\d*)|0)(\.\d{0,2})?$/g; //含两位小数数字(3)
	var regNumId = /^\d{0,17}(\d|x|X)$/g; //身份验证(4)
	var regYzm = /^\d{0,6}$/g; //纯数字(5)
	var regMoney = /^((([1-9]{1}\d{0,7}))|(100000000))?$/; //1亿以内整数金额(6)
	//var	regTxt    = /^[\u4E00-\u9FA5]$/g;//汉字(4)

	var value = obj.value;
	if(3 == regnum || 6 == regnum) {
		value = value.replace(",", "");
	}
	var regs = [regTel, regPwd, regNum, regNump, regNumId, regYzm, regMoney];
	var _val = value.match(regs[regnum]);
	var Start = obj.selectionStart;

	//console.log(_val);

	if(_val || value == '') {
		value == '' ? _val = value : _val = _val[0];
		obj.setAttribute("app_backvalue", _val);
	} else {
		_val = obj.getAttribute("app_backvalue");
		//Start = Start - 1;
	}
	obj.value = _val;
	//设置光标位置
	obj.selectionStart = obj.selectionEnd = Start;
}
//表单提交验证
GHutils.validate = function(scope) {
	var result = true;

	$("#" + scope + " input,#" + scope + " select,#" + scope + " textarea").each(function(d, i) {
		var dom = $(i);
		var valid = dom.attr("valid");
		if(valid && result) {
			var ops = JSON.parse(valid);

			var tips = ops.tipsbox || false;

			//console.log(dom)

			if(ops.required || dom.val()) {
				if(!dom.val()) {

					GHutils.showError(ops.msg + '不能为空', tips);
					result = false;
					return;
				}
				var e = ops;
				if(e.minLength) {
					if(dom.val().length < e.minLength) {
						GHutils.showError(e.msg + '不能小于' + e.minLength + '位', tips);
						result = false;
						return;
					}
				}
				if(e.maxLength) {
					if(dom.val().length > e.maxLength) {
						GHutils.showError(e.msg + '不能大于' + e.minLength + '位', tips);
						result = false;
						return;
					}
				}
				if(e.between) {
					if(dom.val().length < e.between[0] || dom.val().length > e.between[1]) {
						GHutils.showError(e.msg + '长度要' + e.minLength + '位和' + e.minLength + '位之间', tips);
						result = false;
						return;
					}
				}
				if(e.finalLength) {
					if(dom.val().length != e.finalLength) {
						GHutils.showError(e.msg + '为' + e.finalLength + '位', tips);
						result = false;
						return;
					}
				}
				if(e.equals) {
					if(dom.val() != $("#" + e.equals).val()) {
						GHutils.showError(e.msg + '和' + e.equalsMsg + '不一致', tips);
						result = false;
						return;
					}
				}

				if(e.mobilePhone) {
					if(!dom.val().length=="11") {
						GHutils.showError(e.msg + '格式不正确', tips);
						result = false;
					}
				} else if(e.identityCard) {
					if(!dom.val().match("^\\d{17}[X|\\d|x]$")) {
						GHutils.showError(e.msg + '格式不正确', tips);
						result = false;
					}
				} else if(e.passWord) {
					if(!dom.val().match("^([\x21-\x7e]|[a-zA-Z0-9]){6,16}$")) {
						GHutils.showError(e.msg + '格式不正确', tips);
						result = false;
					}
				} else if(e.payPassWord) {
					if(!dom.val().match("^[0-9]{6}$")) {
						GHutils.showError(e.msg + '格式不正确', tips);
						result = false;
					}
				} else if(e.debitCard) {
					if(!dom.val().match("^\\d{16,19}$")) {
						GHutils.showError(e.msg + '格式不正确', tips);
						result = false;
					}
				} else if(e.positiveInteger) {
					if(!dom.val().match("^[0-9]+\\d*$")) {
						GHutils.showError(e.msg + '格式不正确', tips);
						result = false;
					}
				} else if(e.positiveNumber) {
					if(!dom.val().match("^[0-9]+\.?[0-9]*$")) {
						GHutils.showError(e.msg + '格式不正确', tips);
						result = false;
					}
				} else if(e.floatNum) {
					if(!dom.val().match("^(([1-9]\\d*)|0)(\.\\d{0,2})?$")) {
						GHutils.showError(e.msg + '格式不正确', tips);
						result = false;
					}
				} else if(e.nickName) {
					if(!dom.val().match("^[\u4E00-\u9FA5A-Za-z0-9_]{2,15}$")) {
						GHutils.showError(e.msg + '格式不正确', tips);
						result = false;
					}
				} else if(e.invitationNum) {
					if(!dom.val().match("^[A-Za-z0-9]{7}$")) {
						GHutils.showError(e.msg + '格式不正确', tips);
						result = false;
					}
				} else if(e.realName) {
					if(!dom.val().match("^[\u4E00-\u9FA5A-Za-z0-9_·]{1,20}$")) {
						GHutils.showError(e.msg + '格式不正确', tips);
						result = false;
					}
				}
			}
		}
	});
	return result;
}

//判断是否登录，未登录跳转登录页面，已登录返回登录信息
/*参数示例
 *op = {
 *	gologin:"true",string类型，默认是"true";
 *	goback:url,string类型，默认是当前地址，用于登录返回
 *	callback:function(){}
 *	errcallback:function(){}
 *}
 */
GHutils.getUserInfo = function() {
	var info = GHutils.getHeaderInfo();
	return info&&info.extendInfo&&info.extendInfo.UserBasicInfo ? info.extendInfo.UserBasicInfo : null;
}
GHutils.refreshUserInfo = function() {
	GHutils.load({
		url: "/platform1/Member/info",
		type: "post",
		async: false,
		callback: function(result) {
			if(result.code = 10000) {
				GHutils.userinfo = result.extendInfo.UserBasicInfo;
				var info = GHutils.getHeaderInfo();
				if(info) {
					info.extendInfo.UserBasicInfo = GHutils.userinfo;
					GHutils.setCookie("headerinfo", JSON.stringify(info))
				}
			}
		}
	});
}
GHutils.getHeaderInfo = function() {
	var info = GHutils.getCookie("headerinfo");
	info = info ? JSON.parse(info) : null;
	GHutils.userinfo = info && info.extendInfo && info.extendInfo.UserBasicInfo ? info.extendInfo.UserBasicInfo : null;
	return info;
}
GHutils.extend = function(des, src) {
	for(var i in src) {
		des[i] = src[i];
	}
	return des;
}
GHutils.updateUserInfo = function(data) {
	var extend = function(des, src) {
		for(var i in src) {
			des[i] = src[i];
		}
		return des;
	}
	GHutils.userinfo = extend(GHutils.userinfo, data);
	var info = GHutils.getHeaderInfo();
	if(info) {
		info.extendInfo.UserBasicInfo = extend(GHutils.userinfo, data);
		GHutils.setCookie("headerinfo", JSON.stringify(info))
	}
}
/**
收益计算器
**/
GHutils.colculate=function(pType,incomeCalcBasis) {
    //点击收益计算器图标
    $('#calculator').click(function() {
        $('#calculate-errorMessaage').html('')
        $('#calculateContainer input').val('')
        incomeCalcBasis = incomeCalcBasis || 365
        $('#countResult').html('到期收益：<br />本息合计 0  元，利息收入共 0 元')
        $('#popup-box-bg').css('display', 'block');
    })

    function chose() {
        if (pType == 't0') {
            $(".pType").siblings().addClass("choose_boxs")
            $(".selectType").siblings().removeClass("choose_boxs")
        } else if (pType == 'tn') {
            $(".selectType").siblings().addClass("choose_boxs")
            $(".pType").siblings().removeClass("choose_boxs")
        }
    }
    chose();
    $(".choses_t0").on("click", function() {
        pType = 't0';
        chose();
    })
    $(".choses_tn").on("click", function() {
        pType = 'tn';
        chose();
    })

    //点击计算按钮
    $('#count').on('click', function() {
        $('#calculate-errorMessaage').html('')
        if (GHutils.validate('calculateContainer')) {
            if (parseFloat($('#preIncome').val()) > 100) {
                $('#calculate-errorMessaage').html(GHutils.errorMessage("预计收益不能大于100%"))
                return
            }
            GHutils.calcIncome($('#money').val(),{durationPeriodDays:parseInt($('#invertMonth').val()),durationPeriodType:"DAY",incomeCalcBasis:incomeCalcBasis,expAror:parseFloat($('#preIncome').val()),rewardInterest:0,pType:pType},function(income){
            	if(income=="calcing"){
					$('#countResult').html("到期收益：<br />计算中");
				}else{
					$('#countResult').html('到期收益：<br />本息合计 ' + GHutils.formatCurrency(GHutils.Fadd(income,formKey)) + ' 元，利息收入共 ' + GHutils.formatCurrency(income) + ' 元');
				}
            });
            // var last = colculateIncome()
            // $('#countResult').html('到期收益：<br />本息合计 ' + GHutils.formatCurrency(last) + ' 元，利息收入共 ' + GHutils.formatCurrency(GHutils.Fsub(last, parseFloat($('#money').val()))) + ' 元')
        }

    })

    // function colculateIncome() {
    //     var money = parseFloat($('#money').val())
    //     var day = parseInt($('#invertMonth').val())
    //     var preIncome = GHutils.Fdiv(parseFloat($('#preIncome').val()), 100)
    //     if (pType == 't0') {
    //         for (var i = 0; i < day; i++) {
    //             var d = GHutils.Fmul(money, GHutils.Fmul(preIncome, GHutils.Fdiv(1, incomeCalcBasis)))
    //             money = GHutils.Fadd(money, d)
    //         }
    //     } else if (pType == 'tn') {
    //         money = GHutils.Fadd(GHutils.Fmul(GHutils.Fmul(money, preIncome), GHutils.Fdiv(day, incomeCalcBasis)), money)
    //     }
    //     return GHutils.formatCurrency(money)
    // }
}
GHutils.calcIncome=function(investMoney,detail,cb){
	if(timer)
    clearTimeout(timer);
	if(request)
	request.abort()

	formKey=""
	if(!investMoney){
		cb('0.00');
		return false
	}
	formKey=investMoney
	cb("calcing");
	
	timer = setTimeout(function() {
		if(detail.pType&&detail.pType=='t0'){
			detail.pType="CURRENT"
			// var money=investMoney;
			// var day = parseInt($('#invertMonth').val())
			// var preIncome = GHutils.Fdiv(parseFloat($('#preIncome').val()), 100)
			// for(var i=0;i<day;i++){
			// 	var d = GHutils.Fmul(money,GHutils.Fmul(preIncome,GHutils.Fdiv(1,detail.incomeCalcBasis)))
			// 	money = GHutils.Fadd(money, GHutils.toFixeds(d,2))
			// }
			// cb(GHutils.Fsub(money,investMoney))
			// return
		}else{
			detail.pType="REGULAR"
		}
	    request=GHutils.load({
	        url: "/assignTrans/order/invest/getIncome",
	        data: {
	            "formKey": formKey,
	            "orderAmount": investMoney,
	            "durationPeriodDays": detail.durationPeriodDays || 1,
	            "durationPeriodType": detail.durationPeriodType,
	            "incomeCalcBasis": detail.incomeCalcBasis,
	            "baseRate": detail.expAror,
	            "rewardRate": detail.rewardInterest,
	            "productType":detail.pType
	        },
	        type: "post",
	        callback: function(res) {
	            if (res.code == 10000) {
	                if (res.data.formKey == formKey) {
	                    cb(res.data.income)
	                } else {
	                    cb("calcing")
	                }
	            }
	        }
	    })
	}, 500);

}
//判断是否为数组
GHutils.isArray = function(obj) {
	if(!obj) {
		return false;
	}
	return Object.prototype.toString.call(obj) == "[object Array]";
}
//返回代理地址
GHutils.filterProxyUrl = function(obj) {
	if(!obj) {
		return obj;
	}
	var index = obj.indexOf("/rcp-war");
	if(-1 == index)
		return obj;

	return obj.substring(index);
}

//获取图形码
GHutils.changeVCode1 = function(obj) {
	$(obj).attr('src', '/app/common/verifyImage.jsp?Rand=' + Math.random() * 10000);
}
GHutils.slider = function(obj, cfg) {
	var _st = 0;

	if(cfg == "show") {
		setTimeout(function() {
			$(obj).addClass("app_show");
		}, 150);
	} else {
		$(obj).removeClass("app_show");
		_st = 500;
	}
	setTimeout(function() {
		$(obj).dialog(cfg);
	}, _st);

}
//获取本地存储数据
var GHLocalStorage = {
	put: function(key, value) {
		if(!key) {
			return;
		}
		if(typeof(value) == "object") {
			localStorage.setItem(key, JSON.stringify(value));
		} else {
			localStorage.setItem(key, value);
		}
	},
	get: function(key) {
		return JSON.parse(localStorage.getItem(key));
	},
	getRaw: function(key) {
		return localStorage.getItem(key) || null;
	},
	remove: function(key) {
		localStorage.removeItem(key);
	},
	clear: function() {
		localStorage.clear();
	}
};

//清除投资卡券相关数据
GHutils.clearCouponLocalStorage = function() {
	GHLocalStorage.put("availableCouponList", {});
	GHLocalStorage.put("notAvailableCouponList", {});
	GHLocalStorage.put("checkedCoupon", {});
	GHLocalStorage.put("checkedCouponBackups", {})
	GHLocalStorage.put("maxProfitOidList", {})
}


GHutils.getProductStatus=function(state){
	if(state == 'RAISED' || state == 'DURATIONING' || state == 'CLEARED') {
		return 1;
	} else if(state == 'RAISING') {
		return 0
	} else if(state == 'NOTSTARTRAISE') {
		return -1
	}
}



//判断产品是否为某种标签产品,labelArr为标签数组,label为标签
GHutils.isLabelProduct = function(labelArr, label) {
	var labelProduct = false
	if(labelArr && labelArr.length > 0) {
		//		labelArr.forEach(function(e, i){
		//			if(e == label){
		//				labelProduct = true
		//			}
		//		})
		GHutils.forEach(labelArr, function(i, e) {
			if(e == label) {
				labelProduct = true
			}
		})
	}
	return labelProduct
}

GHutils.linkPages = function() {
	var $ = Zepto || false;
	if($) {
		$('.app_link_pages').off().on('click', function() {
			var _href = $(this).attr("data-links");
			var _login = $(this).attr("data-checklogin");
			if(_login && _login == "true" && GHutils.checkLogin(_href)) {
				window.location.href = _href;
			} else {
				window.location.href = _href;
			}

		});
	}
}

//格式化时间格式
/*param{
 * data:time,
 * type:0,
 * showtime:"true"
 * }
 * */
GHutils.formatTimestamp = function(param) {
	var d = new Date();
	d.setTime(param && param.time || d);
	var datetime = null;
	var x = d.getFullYear() + "-" + (d.getMonth() < 9 ? "0" : "") + (d.getMonth() + 1) + "-" + (d.getDate() < 10 ? "0" : "") + d.getDate();
	var y = (d.getHours() < 10 ? " 0" : " ") + d.getHours() + ":" + (d.getMinutes() < 10 ? "0" : "") + d.getMinutes() + ":" + (d.getSeconds() < 10 ? "0" : "") + d.getSeconds();

	if(param.showtime == "false") {
		datetime = x + y;
	} else {
		datetime = x;
	}
	return datetime;
}

//绑定回车键
GHutils.inputBindKey = function() {
	$(".inputBindKey").off().on("keyup", function(e) {
		if(e.keyCode == 13) {
			if($(this).val() == '') {
				return
			}
			var trigger = $(this).attr("data-trigger");
			if(trigger) {
				$(trigger).trigger("click");
			}

		}
	})
}

/*
 * set cookie
 * @params : cookie name, value, time
 */
GHutils.setCookie = function(c_name, value, expiredays) {
	var exdate = new Date();
	exdate.setDate(exdate.getDate() + expiredays);
	document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString()) + ';path=/';
}
GHutils.getCookie = function(name) {
	var str = "; " + document.cookie + "; ",
		index = str.indexOf("; " + name + "=");
	if(index != -1) {
		var tempStr = str.substring(index + name.length + 3, str.length),
			target = tempStr.substring(0, tempStr.indexOf("; "));
		var result = null;
		try {
			result = decodeURIComponent(target)
		} catch(e) {
			result = unescape(target);
		}
		return result && result != 'undefined' ? result : null
	}
	return null;
}

//退出登录
GHutils.loginOut = function(reload) {
	GHutils.load({
		url: "/platform1/Userpub/logout",
		data: {
			platform: "pc"
		},
		type: "post",
		callback: function(result) {
			GHutils.setCookie('headerinfo', '');
			GHutils.userinfo = null;
			if(reload) {
				if(window.location.pathname.indexOf("account") >= 0 || window.location.pathname.indexOf("product-redeem") >= 0) {
					window.location.href = "index.html"
				} else {
					window.location.reload();
				}
			}

		}
	})
}
//切换显示
GHutils.boxSwitch = function(hide, show) {

	if(hide) {
		$(hide).hide();
	}
	if(show) {
		$(show).fadeIn(300)
	}

}

GHutils.smipleTab = function() {
	$(document).off().on("click",".tab_nav", function() {
		var idx = $(this).index();
		//判断是否为当前页签
		if($(this).hasClass("active")) {
			return
		}

		$(this).addClass("active").siblings(".tab_nav").removeClass("active");
		$(".tab_content_box").hide().eq(idx).fadeIn(300);
	})
}
GHutils.getHash = function() {
	var hash = '';

	if(location.hash.indexOf('?') >= 0) {
		hash = location.hash.substring(1, location.hash.indexOf('?'))
	} else {
		hash = location.hash.substr(1)
	}
	return hash;
}
GHutils.changeHash = function(controls) {
	location.hash = controls;
}

//str.trim()方法ie8不兼容解决
GHutils.trim = function(str) {
	str == null ? str = '' : str += ''
	if(typeof(str) == 'undefined') str = ''
	return str.replace(/^\s+|\s+$/g, '')
}
//.forEach方法不兼容解决
GHutils.forEach = function(list, func) {
	if(!(list instanceof Array)) return
	if(list.length == 0) return
	//	$.each(list,function(i,element) {
	//		 func(i,element)
	//		 //跳出循环的功能还没加
	//	});
	var rlt = false;
	var len = list.length;
	for(var i = 0; i < len; i++) {
		if(func(i, list[i])) {
			i = len
			rlt = true
		}
	}
	return rlt;

}

//全局alert
GHutils.alert = function(data) {
	if(data.text){
		$('.bs-alert-modal-sm .modal-body').html(data.text);
		if(data.title)$('.bs-alert-modal-sm .modal-title').html(data.title);
		$('.bs-alert-modal-sm').modal('show');
		if(data.hideClose) {
			$('.bs-alert-modal-sm .close').hide();
		}
		$('.bs-alert-modal-sm').on('hidden.bs.modal', function() {
			data.closeCallback && data.closeCallback()
		})
	}
}
GHutils.addProtocols = function(btnHander,orderAmount,oid) {
	//借款协议
	btnHander.on("click", function() {
		btnHander = $(this);
		if(btnHander.hasClass("app_btn_loading")) {
			return
		}
		$("#title").html('')//btnHander.attr('data-title')
		$("#content").html('');
		if(btnHander.attr('data-orderAmount'))orderAmount=btnHander.attr('data-orderAmount');
		btnHander.addClass("app_btn_loading")
		$.get(btnHander.attr('data-url')+(oid||"")+(orderAmount?"&orderAmount="+orderAmount:"")+"&t="+((new Date()).getTime())+"&method=pc", function(templates) {
			var begin = templates.indexOf('<body');
			var end = templates.indexOf('</body>');
			var temp = templates.substr(begin, end);
			$("#content").html(temp);
		});
		$("#content-box").modal("show")
		btnHander.removeClass("app_btn_loading")
	})
}
GHutils.addPreviews=function(btnHander,banners){
	btnHander.on("click", function() {
		btnHander = $(this);
		if(btnHander.hasClass("app_btn_loading")) {
			return
		}
		
		var bannerHtml = "";
		for (var i in banners) {
			if (i == 0) {
				bannerHtml += '<div class="' + i + ' item active"><img src="' + banners[i] + '" ><div class="carousel-caption">' + (parseInt(i) + 1) + "/" + banners.length + '</div></div>'
			} else {
				bannerHtml += '<div class="' + i + ' item"><img src="' + banners[i] + '" ><div class="carousel-caption">' + (parseInt(i) + 1) + "/" + banners.length + '</div></div>'
			}
		}
		$("#carousel-inner").html(bannerHtml)
		$(".apply-c-div").modal("show");
		if(banners.length<=1){
			$('.carousel-control').hide()
		}else{
			$('.carousel-control').show()
		}
		btnHander.removeClass("app_btn_loading")
	})
	
}
contractId =GHutils.parseUrlParam(location.href).contractId || GHutils.getCookie("contractId") || contractId;

GHutils.getUserInfo(); //刷新GHutils.userinfo


//上报日志请求

GHutils.writeLoad = function(op) {
	if(!op) {
		return;
	}
	op.url = op.url || '/actives1/loger/write'
	if(op.params) {
		op.url = op.url + "?" + decodeURIComponent($.param(op.params));
	}
	if(op.sp) {
		GHutils.processingShow();
	}
	var writeOpcount = GHutils.getCookie("opcount")
	var writeInfo = GHutils.userinfo || ""
	var data={
		deviceId: '',
		userId : writeInfo.userId || "",
		isLogined : writeInfo.login || 0,
		opcount: writeOpcount,
		clientType: 1,
		clientVer:2.0,
		contractId: contractId,
		dt: Date.parse(new Date())/1000,
		_scr_: window.screen.width + "*" + window.screen.height + "*" + window.devicePixelRatio,
		_ua_ : navigator.userAgent,
		_url_: window.location.href,
		_refer_: document.referrer
	}

	data=$.extend( false, data, op.data||{} );
	
	if(writeOpcount){
		writeOpcount ++
		GHutils.setCookie('opcount',writeOpcount)
	}else{
		GHutils.setCookie('opcount',1)
	}

	var set = {
		type: op.type || "post",
		url: op.url,
		async: op.async == false ? false : true,
		data: JSON.stringify(data),
		contentType: op.contentType || "application/json",
		dataType: "json",
		success: function() {
			
		},
		timeout: 20000,
		error: function(xhr, type, errorThrown) {
		
		}
	};
	$.ajax(set);
}

//页面跳转日志上报公用函数
GHutils.writePageLoad = function(onpage){
	var onpage = onpage || ""
	GHutils.setCookie('onpage',onpage)
	// 进入页面时
	GHutils.writeLoad(
		{
			data:{
				evt: "in"+onpage+"Page"
			}
		}
	)
	
	// 离开页面时
	window.onbeforeunload = function () {
		var serialize = function (data) {
			var res = '';
			for (var i in data) {
				res += i + '=' + data[i] + '&';
			}
			return res.split('&').slice(0, -1).join('&');
		}
		var loadXHR = function (params) {
			var xhr = new XMLHttpRequest();
			xhr.onload = function () {
				if (this.status === 200) {
					var data = JSON.parse(this.response);
					params.success && params.success(data);
				}
			}
			xhr.onerror = function () {
				params.error && params.error();
			}
			xhr.open(params.type, params.url, true);
			xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
			var data = serialize(params.data);
			xhr.send(data);
		}
		var writesetCookie = function(c_name, value, expiredays) {
			var exdate = new Date();
			exdate.setDate(exdate.getDate() + expiredays);
			document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString()) + ';path=/';
		}
		var writegetCookie = function(name) {
			var str = "; " + document.cookie + "; ",
				index = str.indexOf("; " + name + "=");
			if(index != -1) {
				var tempStr = str.substring(index + name.length + 3, str.length),
					target = tempStr.substring(0, tempStr.indexOf("; "));
				var result = null;
				try {
					result = decodeURIComponent(target)
				} catch(e) {
					result = unescape(target);
				}
				return result && result != 'undefined' ? result : null
			}
			return null;
		}
		
		var writeOpcount = writegetCookie("opcount")
		var writeInfo = JSON.parse(writegetCookie("headerinfo") || '{"extendInfo":{}}').extendInfo.UserBasicInfo || {}
		console.log(0)
		loadXHR({
			url: "/actives1/loger/write",
			type: "post",
			data: {
				deviceId: '',
				userId : writeInfo.userId || "",
				isLogined : writeInfo.login || 0,
				opcount: writeOpcount,
				clientType: 1,
				clientVer:2.0,
				contractId: contractId,
				dt: Date.parse(new Date())/1000,
				_scr_: window.screen.width + "*" + window.screen.height + "*" + window.devicePixelRatio,
				_ua_ : navigator.userAgent,
				_url_: window.location.href,
				_refer_: document.referrer || "",
				evt: "out"+writegetCookie("onpage")+"Page"
			},
			success: function (data) {
	
			}
		})

		if(writeOpcount){
			writeOpcount ++
			writesetCookie('opcount',writeOpcount)
		}else{
			writesetCookie('opcount',1)
		}
	
	}
}

$(function() {
	GHutils.pageLoadedTime = (new Date()).getTime();
})