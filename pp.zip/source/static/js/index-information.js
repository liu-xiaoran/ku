var Mynotice = function() {
	return this;

}

Mynotice.prototype = {
	init: function() {
	},
	pageInit: function() {}
	

	
	
}

$(function() {
	new Mynotice().init();
})