define([],
    function() {
        return {
            name: 'bindCard',
            init: function() {
                var param = {
                    bankName: '',
                    bankCode: '',
                    bankId: '',
                    orderNo: ''
                }
                var FUN = (function() {
                    return {
                        init: function() {
                            this.btntime = null;
                            this.lockData = {};
                            this.pageInit();
                            
                            this.loadProtocol();
                        },
                        pageInit: function() {
                            var _this = FUN;
                            _this.clearModle();
                            // setTimeout(function() {
                            //     if (!GHutils.userinfo.isPayPwd && (location.pathname.indexOf("account-mySetting") == -1)) {
                            //         $('#setBankPwd').modal('show');
                            //         GHutils.boxSwitch(".modalBox", "#setPayPwdBox");
                            //     }
                            // }, 500);
                            //我已阅读并同意  前面那个复选框样式
                            $(".deposit_span2").click(function() {
                                $(".deposit_span3").toggleClass("deposit_span2")
                            })
                            // $('#idCard').on("change",function() {
                            //     if (!_this.isMan($(this).val())) {
                            //         $('#app_tips_bindcard').html(GHutils.errorMessage("18岁"))
                            //     } 
                            // });
                            //点开弹窗
                            $('#getBanklist').off().on('click', function() {
                                GHutils.writeLoad({
                                    data:{
                                        evt:'AddBankCard',
                                        ext:{
                                        },
                                        ret:""
                                    }
                                })

                                _this.clearModle();
                                _this.getBankList();

                                GHutils.load({
                                    url: '/payment/account/bindBankCardPreVerify',
                                    data: {},
                                    type: 'post',
                                    callback: function(result) {
                                        if (result.code != 10000) {

                                            GHutils.writeLoad({
                                                data:{
                                                    evt:'AddBankCard',
                                                    ext:result,
                                                    ret:"fail"
                                                }
                                            })

                                            GHutils.alert({
                                                text: result.message
                                            });
                                            return false
                                        }
                                        if(!result.data.valid&&result.data.validDesc){
                                            GHutils.alert({
                                                text: result.data.validDesc
                                            });
                                            return false
                                        }
                                        $('.warmPrompt').html('温馨提示：' + result.data.warmPrompt)
                                        if (result.data.realName && result.data.certNo) {
                                            $('#realName_bc').val(result.data.realName).attr('disabled', 'disabled').css("background", '#eee')
                                            $('#idCard').val(result.data.certNo).attr('disabled', 'disabled').css("background", '#eee')
                                        }
                                        $('#bindCardModal').modal('show')
                                    }
                                })

                            })
                        },
                        getBankList: function() {
                            var _this = FUN;
                            
                            //获取银行列表，banklist
                            GHutils.load({
                                url: "/payment/agency/bank/list",
                                data: {},
                                type: "post",
                                callback: function(result) {
                                    if (result.code != 10000) {
                                        return false
                                    }
                                    var banks = ''
                                    result.data.bankList.forEach(function(bank) {
                                        banks += '<li class="bank" data-bank=' + bank.bankName + ' data-bankCode=' + bank.bankCode + ' data-bankId=' + bank.bankId + '><img src="' + bank.bankBigLogo + '"/></li>'
                                    })
                                    $('#bankList').html(banks)
                                    _this.bindEvent();
                                }
                            });
                        },
                        isMan: function(sn) {
                            var bstr = sn.substring(6, 14)
                            // var _now = new Date();
                            // var _bir = new Date(bstr.substring(0,4),bstr.substring(4,6),bstr.substring(6,8));
                            // var _agen = _now-_bir;
                            // var _age = Math.round(_agen/(365*24*60*60*1000));
                            var now = new Date();
                            if (GHutils.getHeaderInfo().extendInfo.ServerTime)
                                now = new Date(GHutils.getHeaderInfo().extendInfo.ServerTime)
                            var birthday = new Date(bstr.substring(0, 4), bstr.substring(4, 6), bstr.substring(6, 8));
                            if (now.getFullYear() - birthday.getFullYear() < 18) //如果年份小于18，直接返回false，未成年
                            {
                                return false;
                            } else if (now.getFullYear() - birthday.getFullYear() == 18) //如果年份差等于18，则比较月份
                            {
                                if (now.getMonth() > birthday.getMonth()) //年份等于18时，当前月份小于出生月份，则返回false，未成年
                                {
                                    return false;
                                } else if (now.getMonth() == birthday.getMonth()) //如果月份也相等，则比较日期
                                {
                                    if (now.getDate() > birthday.getDate()) //年份等于18，月份相等时，如果当前日期小于出生日期，则返回false，未成年
                                    {
                                        return false;
                                    }
                                }
                            }
                            return true;
                        },
                        bindEvent: function() {
                            var _this = FUN;

                            $('#bindCardForm input').on("change", function() {
                                var id = $(this).attr('id')
                                if (_this.lockData[id] && (_this.lockData[id] != $(this).val())) {
                                    _this.lockData = {}
                                    param.orderNo = ''
                                    $('#app_tips_bindcard').html(GHutils.errorMessage('修改数据需要重新获取验证码'))
                                    GHutils.clearBtnTime(_this.btntime, $("#card_verifyCode"));
                                    $("#card_verifyCode").removeClass("btn_loading");
                                }
                            });
                            
                            //点击选择银行
                            $('li.bank').off().on('click', function() {
                                param.bankName = $(this).attr('data-bank');
                                param.bankCode = $(this).attr('data-bankCode');
                                param.bankId = $(this).attr('data-bankId');
                                $(this).addClass("active").siblings().removeClass("active");
                                $('#bank_verifyCode').attr('valid', '{"required":true,"tipsbox":"#app_tips_bindcard","msg":"手机验证码","finalLength":6,"positiveInteger":true}')
                                if (_this.lockData.bankCode && (_this.lockData.bankCode != param.bankCode)) {
                                    _this.lockData = {}
                                    param.orderNo = ''
                                    //提示重新发送验证码
                                    $('#app_tips_bindcard').html(GHutils.errorMessage('修改数据需要重新获取验证码'))
                                    GHutils.clearBtnTime(_this.btntime, $("#card_verifyCode"));
                                    $("#card_verifyCode").removeClass("btn_loading");
                                }
                            });
                            //点击绑卡
                            $('#bindCard').off().on('click', function() {
                                if ($("#bindCard").is('.submiting')) {
                                    return false;
                                }
                                if (!$('#agree_t0').is('.deposit_span2')) {
                                    $('#app_tips_bindcard').html(GHutils.errorMessage('请同意快捷支付协议'))
                                    return false
                                }
                                if ($('li.bank.active').length == 0) {
                                    $('#app_tips_bindcard').html(GHutils.errorMessage('请选择银行'))
                                    return false
                                }
                                if (GHutils.validate('bindCardForm')) {

                                    _this.bankadd()
                                }
                            })

                            //点击获取验证码
                            $('#card_verifyCode').off().on('click', function() {

                                // 点击绑卡验证码日志上报
                                GHutils.writeLoad({
                                    data:{
                                        evt:'AddBankGetVeriCodeClick',
                                        ext:{
                                            "name":GHutils.trim($('#realName_bc').val()).substring(GHutils.trim($("#realName_bc").val()).length,-1),
                                            "idcard": GHutils.trim($("#idCard").val()).substring(GHutils.trim($("#idCard").val()).length,-4),
                                            "idcardlength":GHutils.trim($("#idCard").val()).length,
                                            "bankname":param.bankName ,
                                            'bankcardnum': GHutils.trim($("#cardNum").val()).substring(GHutils.trim($("#cardNum").val()).length,-4),
                                            'bankcardlength':GHutils.trim($("#cardNum").val()).length,
                                            "tel":GHutils.trim($("#bankPone").val()).substring(GHutils.trim($("#bankPone").val()).length,-4),
                                            'tellength':GHutils.trim($("#bankPone").val()).length
                                        },
                                        ret:""
                                    }
                                })

                                $('#app_tips_bindcard').html('&nbsp');
                                if ($(this).is('.btn_loading')) {
                                    return false;
                                }
                                if ($('li.bank.active').length == 0) {
                                    $('#app_tips_bindcard').html(GHutils.errorMessage('请选择银行'))
                                    return
                                }
                                $("#bank_verifyCode").removeAttr('valid');
                                if (GHutils.validate('bindCardForm')) {
                                    $("#card_verifyCode").addClass("btn_loading");
                                    _this.checkCardAndBank()
                                }
                            })
                        },
                        checkCardAndBank: function() {
                            var _this = FUN;
                            // 获取卡号的银行信息，以验证银行是否正确
                            GHutils.load({
                                url: "/payment/account/bankCardNoVerify",
                                data: {
                                    "bankCardNo": $('#cardNum').val()
                                },
                                type: "post",
                                callback: function(result) {
                                    if (result.code != 10000) {
                                        $("#card_verifyCode").removeClass("btn_loading");
                                        $('#app_tips_bindcard').html(GHutils.errorMessage(result.message))
                                        return false;
                                    }
                                    if (param.bankId == result.data.bankId) {
                                        param.bankName = result.data.bankName
                                        _this.valid4ele()
                                    } else {
                                        $("#card_verifyCode").removeClass("btn_loading");
                                        $('#app_tips_bindcard').html(GHutils.errorMessage('储蓄卡号与选择的银行不对应 '))
                                    }
                                },
                                errcallback: function() {
                                    $("#card_verifyCode").removeClass("btn_loading");
                                }
                            });

                        },

                        valid4ele: function() {
                            var _this = FUN;
                            // 实名认证与绑卡验证码
                            GHutils.load({
                                url: "/payment/account/authVerify",
                                data: {
                                    "realName": GHutils.trim($('#realName_bc').val()),
                                    "certNo": GHutils.trim($("#idCard").val()),
                                    "bankPhone": GHutils.trim($('#bankPone').val()),
                                    "bankCardNo": GHutils.trim($("#cardNum").val()),
                                    "bankCode": param.bankCode
                                },
                                type: "post",
                                callback: function(result) {
                                    if (result.code != 10000) { //9907错误不抓取
                                        $("#card_verifyCode").removeClass("btn_loading");
                                        $('#app_tips_bindcard').html(GHutils.errorMessage(result.message))
                                        return false;
                                    }
                                    _this.lockData = {
                                        realName_bc: GHutils.trim($('#realName_bc').val()),
                                        idCard: GHutils.trim($("#idCard").val()),
                                        bankPone: GHutils.trim($('#bankPone').val()),
                                        cardNum: GHutils.trim($("#cardNum").val()),
                                        bankCode: param.bankCode
                                    }
                                    param.orderNo = result.data.orderNo
                                    _this.btntime = GHutils.btnTime($("#card_verifyCode"));
                                    $('#bank_verifyCode').attr('valid', '{"required":true,"tipsbox":"#app_tips_bindcard","msg":"手机验证码","finalLength":6,"positiveInteger":true}')
                                },
                                errcallback: function() {
                                    $("#card_verifyCode").removeClass("btn_loading");
                                }
                            });

                        },

                        bankadd: function() {
                            var _this = FUN;
                            if (!param.orderNo) {
                                $('#app_tips_bindcard').html(GHutils.errorMessage('请先获取验证码'))
                                return false;
                            }
                            // 绑卡按钮日志上报
                            GHutils.writeLoad({
                                data:{
                                    evt:'AddBankNextClick',
                                    ext:{
                                        'oid':  param.orderNo.substring(param.orderNo.length - 4),
                                        "vericode" : GHutils.trim($('#bank_verifyCode').val())
                                    },
                                    ret:""
                                }
                            })
                            $("#bindCard").addClass('submiting')
                            // 绑定银行卡 bindBankCard
                            GHutils.load({
                                url: "/payment/account/bindBankCard",
                                data: {
                                    orderNo: param.orderNo,
                                    securityCode: GHutils.trim($('#bank_verifyCode').val()),
                                },
                                type: "post",
                                callback: function(result) {
                                    $("#bindCard").removeClass('submiting')
                                    if (result.code != 10000) {

                                        GHutils.writeLoad({
                                            data:{
                                                evt:'AddBankResult',
                                                ext:result,
                                                ret:"fail"
                                            }
                                        })

                                        $('#app_tips_bindcard').html(GHutils.errorMessage(result.message))
                                        return false;
                                    }
                                    if (_this.btntime) {
                                        GHutils.clearBtnTime(_this.btntime, $("#card_verifyCode"));
                                    }
                                    $('#bindCardModal').modal('hide');
                                    GHutils.updateUserInfo({
                                        isBindCard: 1
                                    });
                                    if(location.search.indexOf("method")>=0)
                                        location.href = location.href + '?method=1';
                                    else
                                        location.reload()
                                },
                                errcallback: function() {
                                    $("#bindCard").removeClass('submiting')
                                }
                            });
                        },
                        clearModle: function() {
                            var _this = FUN;
                            $('#bindCardModal input').val('');
                            $("#app_tips_bindcard").html('');
                            GHutils.clearBtnTime(_this.btntime, $("#card_verifyCode"));
                        },
                        loadProtocol: function() {
                            //相关协议点击事件
                            // $('.protocol').off().on('click', function() {
                            // 	var tile = $(this).html()
                            // 	$.get('/actives1/static/protocolDetail?type=' + $(this).attr('data-typeId'), function(templates) {
                            // 		var begin = templates.indexOf('<body');
                            // 		var end = templates.indexOf('</body>');
                            // 		var temp = templates.substr(begin, end);
                            // 		$('.protocol-content').html(temp)
                            // 		$('.protocol-title').html(tile)
                            // 		$('#protocol-box').modal('show')
                            // 	})
                            // })
                        }
                    };
                })();
                $(function() {
                    FUN.init();
                });
            }
        }
    })