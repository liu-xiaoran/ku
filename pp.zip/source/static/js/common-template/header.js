define([],
    function() {
        return {
            name: 'header',
            init: function() {
                this.pageInit();
                this.bindEvent();
            },
            pageInit: function() {
                var _this = this;
                //服务器维护中禁止后续操作
                var pageName = $("body").attr("id");
                if (pageName == "repair") {
                    return
                }
                window.goHref = function(url) {
                    if (url == '/account.html') {
                        if ($(".account").hasClass("account-active")) {
                            location.href = url
                        } else {
                            // $("#showLogin").trigger("click");
                            location.href = "/regandlog.html?type=log";
                        }
                    } else {
                        location.href = url
                    }
                }
                //保存7天
                var cid_formurl = GHutils.parseUrlParam(location.href)["cid"];
                cid_formurl && GHutils.setCookie("contractId", cid_formurl, 7);
                var onnav = $("#header-box").attr("data-navname");
                if (onnav) {
                    $("." + onnav).addClass("active");
                }
                

                if(GHutils.getCookie("headerinfo")){
                    _this.showLoginStatus( JSON.parse(GHutils.getCookie("headerinfo")).extendInfo.UserBasicInfo)
                    setTimeout(function(){
                        _this.getUserInfo()
                    },1000);
                }else{
                    _this.getUserInfo()
                }
            },
            showLoginStatus: function(info) {
                var _this = this;
                //account部分判断实名绑卡
                if (window.location.pathname.indexOf("account") >= 0) {
                    if (info.isBindCard) {
                        $("#bankCard").attr('src', 'static/images/bank-card2.png');
                        $("#bankCardText").css("display", "inline-block");
                        $("#nobankCardText").hide();
                    } else {
                        $("#bankCard").attr('src', 'static/images/bank-card1.png');
                        $("#bankCardText").hide();
                        $("#nobankCardText").css("display", "inline-block");
                    }
                    if (!info.isBindCard && info.isRealVerifiedName) {
                        $(".bankCardText").show();
                        $(".identityText").css("zIndex", 300)
                    }
                    if (info.isRealVerifiedName) {
                        $("#identityCard").attr('src', 'static/images/identy-card2.png');
                        $("#identityText").css("display", "inline-block");
                        $("#noIdentityText").hide();
                    } else {
                        $("#identityCard").attr('src', 'static/images/identy-card1.png');
                        $("#identityText").hide();
                        $("#noIdentityText").css("display", "inline-block");
                        $(".identityText").show();
                    }
                    if (!info.isBindCard) {
                        $(".account-icons").html('<img src="static/images/user-photos.png" class="user-photos"/>')
                    }else{
                        $(".account-icons").html('<img src="static/images/user-photoss.png" class="user-photos"/>')
                    }
                    if ($(".identityText").is(":hidden")) {
                        $(".identityCard_box").on("mouseenter", function() {
                            $(".identityText").show();
                        }).on("mouseleave", function() {
                            $(".identityText").hide();
                        })
                    }
                    if ($(".bankCardText").is(":hidden")) {
                        $(".bankCard_box").on("mouseenter", function() {
                            $(".bankCardText").show();
                        }).on("mouseleave", function() {
                            $(".bankCardText").hide();
                        })
                    }
                }
                //banner 部分
                $(".banner .annual-login").hide();
                $(".banner .index_icon").html("安装掌悦理财APP，随时随地享收益");
                //点击banner立即加入
                $('#goInvestf').on('click', function() {
                    location.href = '/product-t0.html' //跳转到掌薪宝窗口
                })
                $('#nickName span').html(info.nickname || (info.phone))
                //消息条数还不知道接口
                $('#messaageCtrl').html('消息')
                $('#loginStatus').show()
                $('#notLogin').hide();
                //用户中心部分，左上角的用户详情
                $('#infoName').html('你好，' + info.phone)
                $('#infoAcc').html('账户名：' + info.phone)
                $(".account").addClass("account-active");
            },
            getUserInfo: function() {
                var _this = this;
                GHutils.load({
                    url: "/payment/account/myAsset",
                    data: {}, //data: { extendInfo: ["NewLetter", "MyHome", "MyCouponAmount"] },
                    extendInfo: ["NewLetter", "UserBasicInfo","ServerTime"],
                    type: "post",
                    callback: function(result) {
                        if (result.code != 10000) {
                            GHutils.setCookie("headerinfo", "");
                            GHutils.userinfo = null;
                            $('#notLogin').show();
                            $('#loginStatus').hide();
                            //点击banner立即加入
                            $('#goInvestf').html("立即注册").on('click', function() {
                                //							$("#regBtn").click(); //
                                window.location.href = "/regandlog.html?type=reg"
                            })
                            if (window.location.pathname.indexOf("account") >= 0 || window.location.pathname.indexOf("product-redeem") >= 0) {
                                window.location.href = "index.html"
                                return false
                            }
                        } else {
                            var ck={
                                data:"",
                                extendInfo:result.extendInfo
                            }
                            if(result.extendInfo&&result.extendInfo.UserBasicInfo&&result.extendInfo.UserBasicInfo.login){
                                GHutils.setCookie("headerinfo", JSON.stringify(ck));
                                _this.getInfoResult(result);
                            }else{
                               GHutils.setCookie("headerinfo", "");
                                GHutils.userinfo = null;
                                $('#notLogin').show();
                                $('#loginStatus').hide();
                                //点击banner立即加入
                                $('#goInvestf').html("立即注册").on('click', function() {
                                    //                          $("#regBtn").click(); //
                                    window.location.href = "/regandlog.html?type=reg"
                                })
                                if (window.location.pathname.indexOf("account") >= 0 || window.location.pathname.indexOf("product-redeem") >= 0) {
                                    window.location.href = "index.html"
                                    return false
                                }
                            }
                            
                            
                        }
                    }
                })
            },
            getInfoResult: function(result) {
                var _this = this;
                GHutils.userinfo = result.extendInfo.UserBasicInfo;
                _this.showLoginStatus(result.extendInfo.UserBasicInfo);
                if (result.extendInfo.NewLetter > 0) {
                    $(".messgaeNoRead").html(result.extendInfo.NewLetter).show();
                } else {
                    $(".messgaeNoRead1").html(result.extendInfo.NewLetter).show();
                }
                _this.userAccount(result);
                _this.userAccountMy(result);
            },
            userAccountMy: function(result) {
                var html = [
                    '<div class="row2">',
                    '<div class="col1">可用余额</div>',
                    '<div class="col2">' + GHutils.formatCurrency(result.data.cashBalance) + '元</div>',
                    '</div>',
                    '<div class="row2">',
                    '<div class="col1">可用优惠券</div>',
                    '<div class="col2">' + result.data.availableRedenvelope + '张</div>',
                    '</div>',
                    '<div class="row2">',
                    '<div class="col1">累计收益</div>',
                    '<div class="col2">' + GHutils.formatCurrency(result.data.accumulativeIncome) + '元</div>',
                    '</div>',
                    '<div class="row2">',
                    '<div class="col1">冻结金额</div>',
                    '<div class="col2">' + GHutils.formatCurrency(result.data.frozenBalance) + '元</div>',
                    '</div>',
                    '<div class="row2">',
                    '<div class="col1">总资产</div>',
                    '<div class="col2">' + GHutils.formatCurrency(result.data.totalAsset) + '元</div>',
                    '</div>'
                ].join("");
                $(".pop-account-my").html(html);
            },
            userAccount: function(result) {
                var _this = this;
                //账户总览
                var html = [
                    '<div class="row1">',
                    '<div class="col1"></div>',
                    '<div class="col2" style="width: 190px">',
                    '<p style=" height: 24px; line-height: 24px; margin:3px;">' + result.extendInfo.UserBasicInfo.nickname || "尊敬的用户" + '</p>',
                    '<p style=" height: 24px; line-height: 24px; margin: 0">欢迎来到掌悦理财</p>',
                    '</div>',
                    '<div style="clear: both;"></div>',
                    '</div>',
                    '<div class="row2" onclick=' + 'window.goHref("/account.html")' + '>',
                    '<div class="col1">资产总览</div>',
                    '<div class="col2">' + GHutils.formatCurrency(result.data.totalAsset) + '元</div>',
                    '</div>',
                    '<div class="row2" onclick=' + 'window.goHref("/account-myt0.html")' + '>',
                    '<div class="col1">我的掌薪宝</div>',
                    '<div class="col2">' + GHutils.formatCurrency(result.data.currentAsset) + '元</div>',
                    '</div>',
                    '<div class="row2" onclick=' + 'window.goHref("/account-mytn.html")' + '>',
                    '<div class="col1" >我的定期</div>',
                    '<div class="col2">' + GHutils.formatCurrency(result.data.regularAsset) + '元</div>',
                    '</div>',
                    '<div class="row2" onclick=' + 'window.goHref("/account-message.html")' + '>',
                    '<div class="col1">消息中心</div>',
                    '<div class="col2"><span class="badge messgaeNoRead messgaeNoRead1" style="margin-right: 5px;margin-bottom: 3px;">' + result.extendInfo.NewLetter + '</span>条未读</div>',
                    '</div>',
                    '<div class="row3">',
                    '<div class="recharge-btn" style="cursor: pointer;" onclick=' + 'window.goHref("/account-deposit.html")' + '>账户充值</div>',
                    '</div>'
                ].join("");
                $(".pop-account").html(html);
            },
            bindEvent: function() {
                var _this = this;
                //点击安全退出
                $('#loginOut').on('click', function() {
                    GHutils.loginOut(true);
                    $(".account").removeClass("account-active")
                })
            }
        }
    })