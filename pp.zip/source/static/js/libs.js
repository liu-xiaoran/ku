__inline('public/ZYLIB.req-0.0.1.min.js');
__inline('component.js');
// __inline('common-template/header.js');
__inline('public/require.min.js');
__inline('public/bootstrap.min.js');
__inline('loadTemplates.js');
__inline('public/jquery.page.js');
__inline('public/qrcode.min.js');
jQuery(function($){
	$('.footer-img').html('<dl><dt><img src="/static/images/gzh.png?__inline"/></dt><dd>关注掌悦微信</dd><img class="logo-mini"src="/static/images/logo-mini.png"/></dl><dl><dt id="build-qrcode"></dt><dd>下载APP</dd><img class="logo-mini"src="/static/images/logo-mini.png"/></dl>');
	$('#notLogin .headerAppCodeShow').html('<div id="build-qrcode0"></div><img class="logo-mini"src="/static/images/logo-mini.png"/><p style="text-align: center;margin:0">指尖轻触坐享收益</p>');
	$('#loginStatus .headerAppCodeShow').html('<div id="build-qrcode01"></div><img class="logo-mini"src="/static/images/logo-mini.png"/><p style="text-align: center;margin:0">指尖轻触坐享收益</p>');
	if(document.getElementById("build-qrcode")){
		new QRCode(document.getElementById("build-qrcode"), {
			text:location.origin+"/h5/dl/?contractId="+contractId,
			width : 173,
			height : 173
		});
	}
	setTimeout(function(){
		if(document.getElementById("build-qrcode0")){
            new QRCode(document.getElementById("build-qrcode0"), {
                text:location.origin+"/h5/dl/?contractId="+contractId,
                width : 150,
                height : 150
            });
		}
		if(document.getElementById("build-qrcode01")){
            new QRCode(document.getElementById("build-qrcode01"), {
                text:location.origin+"/h5/dl/?contractId="+contractId,
                width : 150,
                height : 150
            });
		}
	},500);
	

	
});

//统计代码
var _hmt = _hmt || [];
(function() {
	var hm = document.createElement("script");
	hm.src = "https://hm.baidu.com/hm.js?d361836c2f08b7ed0f588fd60827a759";
	var s = document.getElementsByTagName("script")[0];
	s.parentNode.insertBefore(hm, s);
})();