var accountMessage = function() {
	return this;

}

accountMessage.prototype = {
	init: function() {
		this.bindEvent();
		this.getData(1, true);
	},
	mailAllread: function() {
		var _this = this;
		GHutils.load({
			url: "/platform1/letter/readall",
			data: {},
			type: "post",
			callback: function(result) {
			}
		})
	},

	getMailDetail: function(mailOid) {
		var _this = this;
		GHutils.load({
			url: "/platform1/letter/view",
			data: {
				id: mailOid
			},
			type: "post",
			// loginStatus: function(resp) {
			// 	GHutils.loginOut(true)
			// },
			callback: function(result) {
			}
		})
	},

	//分页数据
	getData: function(page, isFlag) {
		var _this = this;
		GHutils.load({
			url: "/platform1/letter/list",
			data: {
				pageInfo: {
					pageNo: page,
					pageSize: 5
				},
				extendInfo: ["NewLetter"]
			},
			type: "post",
			callback: function(result) {
				var tds = ' ';
				if(result.data) {
					if(!result.data.list || (result.data.list && result.data.list.length == 0)) {
                        $(".mynoticetable").html('<img src="static/images/app-nodata1.png" class="dataTipsImg"/>');
						return
					}
				}
				//兼容ie8 forEach循环；
				if(!Array.prototype.forEach) {
					Array.prototype.forEach = function forEach(callback, thisArg) {
						var T, k;
						if(this == null) {
							throw new TypeError("this is null or not defined");
						}
						var O = Object(this);
						var len = O.length >>> 0;
						if(typeof callback !== "function") {
							throw new TypeError(callback + " is not a function");
						}
						if(arguments.length > 1) {
							T = thisArg;
						}
						k = 0;
						while(k < len) {
							var kValue;
							if(k in O) {

								kValue = O[k];
								callback.call(T, kValue, k, O);
							}
							k++;
						}
					};
				}
				//结束
				result.data.list.forEach(function(message) {
					var icon = '';
					if(message.isRead == "no") {
						icon = "messageCircle1";
					}
					tds += '<li class=" " data-title="' +
						message.msgTitle + '" data-content="' +
						encodeURIComponent(message.msgContent) + '" data-oid="' +
						message.id + '" ><table><tr><td class="tcell_1"><span class="messageCircle ' + icon + '"></span></td><td class="tcell_2 pop_title">' +
						mailTypes(message.mailType) + message.msgTitle + '</td><td class="tcell_3 pop_content">' +
						GHutils.formatTimestamp({
							time: message.createTime,
							showtime: "false"
						}) + '</td></tr></table><p class="msgContent">'+message.msgContent+'</p></li>'
				});
				$(".mynoticetable").html(tds);
				$("#messgaeTotle").html(result.data.pageInfo.totalSize);
				$("#messgaeNoRead").html(result.extendInfo.NewLetter); //未读数量
				_this.bindEvent();
				if(isFlag) {
					_this.createPage(Math.ceil(result.data.pageInfo.totalSize / 5));
				}
			}
		})
		function mailTypes(mailType) {
			var classes = ''
			if(mailType == 'all') {
				classes = 'mailType1';
				mailType = '全站'
			} else if(mailType == 'person') {
				classes = 'mailType'
				mailType = '个人'
			}
			return '<span class="' + classes + '">' + (classes == '' ? '' : mailType) + '</span>'
		}
	},

	bindEvent: function() {
		//tab切换
		var _this = this;
		$(".mynoticetable").find("li").off().on("click", function() {
			var html = $(this).attr("data-content");
			var title = $(this).attr("data-title");
			$("#content_box").modal("show");
			$("#modal_title").html(title);
			$("#modal_content").html(decodeURIComponent(html));
			$(this).find("span").removeClass("messageCircle1");
			var mailOid = $(this).attr("data-oid")
			_this.getMailDetail(mailOid);
		});
		$("#messageMark").off().on("click", function() {
			$(".mynoticetable").find("span").removeClass("messageCircle1");
			$("#messgaeNoRead").html(0);
			_this.mailAllread();
		});
	},

	createPage: function(pageCount) {
        var _this = this;
        $(".tcdPageCode").show()
        if(pageCount <= 1) {
            $(".tcdPageCode").hide()
        }
		$(".tcdPageCode").createPage({
			pageCount: pageCount,
			current: 1,
			backFn: function(page) {
				_this.getData(page);
			}
		});
	}
}

$(function() {
	new accountMessage().init();
})