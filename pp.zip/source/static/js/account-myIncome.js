var AccountMyIncome = function() {
	return this;
}

AccountMyIncome.prototype = {
	init: function() {
		this.getData(1, true)
	},
	getData: function(page, isFlag) {
		var _this = this;
		GHutils.load({
			url: "/zybusiness/user/myIncome/pc",
			data: {
				pageInfo: {
					pageNo: page,
					pageSize: 8
				}
			},
			type: "post",
			loginStatus: function(resp) {
				GHutils.loginOut(true)
			},
			callback: function(result) {
				if(result.code != 10000) {
					return false;
				}
				$('#confirmDate').html('收益确认日:' + GHutils.formatTimestamp({
					time: result.data.now,
					showtime: "true"
				}))
				$('#totalIncome').html(GHutils.formatCurrency(result.data.totalIncome || 0)) //累计收益(元)
				$('#yesterDayIncome').html(GHutils.formatCurrency(result.data.yesterdayIncome || 0)) //昨日收益(元)
				if(result.data.list) {
                    $('#noReCord').hide()
                    $('#hasReCord').show()
				} else {
                    $('#noReCord').show()
                    $('#hasReCord').hide()
				}
				var tds = '<tr class="tr_1 tr_w_h rowsCords" style="height:44px;background:#fff2ef;"><td class="col-xs-4" style="padding-left:42px">金额</td><td class="col-xs-4" style="text-align: center">时间</td><td class="col-xs-4" style="padding-right:42px;text-align:right;">收益类型</td></tr>'
				GHutils.forEach(result.data.list, function(idx, income) {
					tds += '<tr class="rowsCord ' + (idx % 2 == 0 ? 'active' : '') + 'tr_w tr_coor"><td class="col-xs-4" style="padding-left:42px">' + GHutils.formatCurrency(income.income) + ' 元</td><td class="col-xs-4" style="text-align: center">' + GHutils.formatTimestamp({
						time: income.incomeDate,
						showtime: "true"
					}) + '</td><td class="col-xs-4" style="padding-right:42px;text-align:right;">' + income.productInfo.productName + '</td></tr>'
				})
				$('#incomeTable').html(tds)
				if(isFlag) {
					_this.createPage(Math.ceil(result.data.pageInfo.totalSize / 8));
				}
			}
		})
	},
	createPage: function(pageCount) {
		$(".tcdPageCode").show()
		if(pageCount <= 1) {
			$(".tcdPageCode").hide()
		}
		var _this = this;
		$(".tcdPageCode").createPage({
			pageCount: pageCount,
			current: 1,
			backFn: function(page) {
				_this.getData(page, false);
			}
		});
	}
}

$(function() {
	new AccountMyIncome().init();
})