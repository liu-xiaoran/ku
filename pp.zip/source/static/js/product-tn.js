var HUOQI = function() {
	return this;
}

HUOQI.prototype = {
	init: function() {
		this.pageInit();
		this.bindEvent();
		this.param = {}
		this.timer="";
		this.formKey=""
	},
	getDetail:function(oid){
		$.get("/actives1/product/getRegularIntro?productOid="+oid+"&typeCode=pc&r="+GHutils.getMinutesTimestamp(), function(templates) {
			if(typeof templates !="string"){
				templates=""
			}
			var begin = templates.indexOf('<body');
			var end = templates.indexOf('</body>');
			var temp = templates.substring(begin, end);
			$(".cents").html(temp);
			// 借款协议
			var btns=$('.box .goWebView');
			for (var i = btns.length - 1; i >= 0; i--) {
				var imgs=$(btns[i]).attr("data-imgs")
				if(imgs){
					//
					GHutils.addPreviews($(btns[i]),JSON.parse(imgs));//JSON.parse(imgs)
				}else{
					GHutils.addProtocols($(btns[i]));
				}
				
			}
			
		});
		$.get("/actives1/product/getRegularIncome?productOid="+oid+"&r="+GHutils.getMinutesTimestamp(), function(templates) {
			if(typeof templates !="string"){
				templates=""
			}
			var begin = templates.indexOf('<body');
			var end = templates.indexOf('</body>');
			var temp = templates.substring(begin, end);
			$(".cent3s").html(temp);
		});
	},
	pageInit: function() {
		var _this = this;
		var content = {
			serviceFilesContent: '',
			investFilesContent: ''
		}
		var uraParam = GHutils.parseUrlParam(window.location.href)
		if(uraParam.productOid) {
			_this.getDetail(uraParam.productOid);
			productInfo(uraParam.productOid)
			return false;
		} else {
			window.location.href = "product-tn-list.html"
		}
		//产品详情
		function productInfo(oid) {
			GHutils.load({
				url: "/actives1/product/getRegularDetail",
				data: {
					"productOid": oid
				},
				type: "post",
				callback: function(result) {
					if(result.code != 10000) {
						if(result.code == 10005) {
							GHutils.alert({
								text: "项目已售罄，项目详情仅对本项目投资人公开",
								closeCallback: function() {
									history.go(-1)
								}
							})
						}
						$('#invest_errorMessage').html(GHutils.errorMessage(result.message))
						return false;
					}
					// 获取资产表格
					var htmls = '<tr><td style="width:30%;">资产类型</td><td style="width:30%">占比</td><td>资金用途</td></tr>',
						htmltype = "",
						asset = result.data.content;
					if(!asset) {
						asset = {
							chainFinanceRate: 0,
							billRate: 0
						};
					} else {
						htmltype = [
							'<tr >',
							'<td style="width:30%">项目类型</td>',
							'<td colspan="2">' + asset.assetCateName + '</td>',
							'</tr>',
							'<tr>',
							'<td rowspan="2">融资方</td>',
							'<td style="width:30%">企业名称</td>',

							'<td>' + asset.financer + '</td>',
							'</tr>',
							'<tr>',
							'<td>注册资本</td>',
							'<td>' + asset.financerCapital + '</td>',
							'</tr>',
							'<tr>',
							'<td >资金用途</td>',
							'<td colspan="2">' + asset.usages + '</td>',
							'</tr>',
							'<tr>',
							'<td >还款来源</td>',
							'<td colspan="2">' + asset.repaySource + '</td>',
							'</tr>',
							'<tr>',
							'<td >风控措施</td>',
							'<td colspan="2">' + asset.risk + '</td>',
							'</tr>',
							'<tr>',
							'<td >担保方</td>',
							'<td >企业名称</td>',
							'<td colspan="2">' + asset.warrantor + '</td>',
							'</tr>'

						].join("")
					}
					for(var i in asset.AssetAllCate) {
						htmls += [
							'<tr>',
							'<td>' + asset.AssetAllCate[i].CateName + '</td>',
							'<td>' + asset.AssetAllCate[i].CapitalRate + '</td>',
							'<td>' + asset.AssetAllCate[i].usages + '</td>',
							'</tr>'
						].join("");
					}
					$(".taba tbody").html(htmls);
					$(".tabb tbody").html(htmltype);
					// 获取资产配置
					var result = result.data.content;
					_this.param = result
					_this.param.minMoney = (result.investMin == null ? 0 : result.investMin)
					_this.param.addMoney = GHutils.Fmul(result.investAdditional, result.netUnitShare)
					_this.param.investMax = (result.investMax == null ? 0 : result.investMax)
					_this.param.incomeCalcBasis = parseInt(result.incomeCalcBasis)
					_this.param.productOid = result.oid
                    _this.param.typeCode = result.typeCode
					GHutils.colculate("tn",_this.param.incomeCalcBasis);
					if(GHutils.getProductStatus(_this.param.state)==1){
						$('#goInvest').css({
							'background': '#dcdcdc',
							'color': '#656565'
						}).html('已售罄').off() //立即抢购按钮置灰
					}else if(GHutils.getProductStatus(_this.param.state)==-1){
						$('#goInvest').html('预售').off() //
					}
					var interest = GHutils.toFixeds(result.expAror, 2);
					interest += '<span style="font-size:26px">%</span>';
					if(result.rewardInterest&&(result.rewardInterest-0)) {
						interest += '<span><span style="font-size:26px">+</span>' + GHutils.toFixeds(result.rewardInterest, 2) + '<span style="font-size:26px">%</span></span>'
					}
					//各种数据填充
					$('#productName').html(result.productName)
					$('#annualInterestSec').html(interest).css({
						"font-size": "44px"
					})
					var labels = "";
					//循环标签
					for(var i in result.labelList) {
						if(result.labelList[i].labelType == "extend") {
							//循环图标
							if(result.labelList[i].labelName == '一锤定音') {
								labels += '<span class="quick_banner_yu_tui" style="border:none;padding:0"><img title="一锤定音:此项目满标者可获惊喜红包" src="static/images/chuizi.png" height="20"/></span>'
							} else if(result.labelList[i].labelName == '一鸣惊人') {
								labels += '<span class="quick_banner_yu_tui" style="border:none;padding:0"><img title="一鸣惊人:此项目单笔投资最高者可获惊喜红包" src="static/images/famous.png" height="20"/></span>'
							} else if(result.labelList[i].labelNo == 'A5') {
								labels += '<span class="quick_banner_yu_tui" style="border:none;padding:0"><img title="投资惊喜:此产品成功投资有机会获得惊喜礼包" src="static/images/touzijinxi.png" height="20"/></span>'
							}

							//循环标签
							if(result.labelList[i].labelName != '一锤定音'&&result.labelList[i].labelName != '一鸣惊人'&&result.labelList[i].labelNo != 'A5') {
								labels += '<span class="quick_banner_yu_tui">' + result.labelList[i].labelName + '</span>';
							}
						}
					}

                    var times = '';
                    if(result.durationPeriodType == 'DAY') {
                        times = '天';
                    } else if(result.durationPeriodType == 'MONTH') {
                        times = '月';
                    }
					$('#paybackName').html(result.paybackName)
					$('#label').html(labels)
					$('#lockPeriodDays').html(result.durationPeriodDays + '<span style="font-size:26px">'+times+'<span>')
					$('#lockPeriodDays_1').html(result.durationPeriodDays)
					
					$('#investMin').html(GHutils.formatIntCurrencys(_this.param.minMoney) + '<span style="font-size:26px">元<span>')
					$("#introduce-purchasingAmount").html(_this.param.minMoney)
					$("#introduce-increaseAmount").html(_this.param.addMoney)
					$('.introduce-productName').html(result.productName)
					$('#introduce-investDay').html( $('#goInvest').html()=='已售罄'? '已售罄' : result.investTime.substr(0, 10) )
					$('#introduce-interestsStartDate').html(result.durationBegTime.substr(0, 10))
					$('#introduce-repayDate').html(result.payBackDate.substr(0, 10))
					$('#invest').attr('placeholder', (GHutils.formatCurrencys(_this.param.minMoney) + '元起投，' + GHutils.formatCurrency(_this.param.addMoney) + '元递增'))
					$('#progressbar').css('width', Math.min(100, result.percent) + '%')
					$('#nums').html(Math.min(100, result.percent) + "%")
					$('#tnProcess').html('<li class="col-xs-6" style="color:#999;font-size:16px;">募集总额:<span>' + formatAmount(result.raisedTotalNumber) + '</span></li><li class="col-xs-6 yimj" style="color:#999;font-size:16px;">已募集:<span>' + formatAmount(result.collectedVolume) + '</span></li>')
					_this.getData(1, true, oid)
				}
			});
		}
		function formatAmount(amount) {
			if(amount > 10000) {
				amount = GHutils.formatCurrency(amount / 10000) + " 万";
			} else {
				amount = GHutils.formatCurrency(amount);
			}
			return amount;
		}
	},
	
	bindEvent: function() {
		var _this = this;

		// 添加收益 历史年化提示
		$(".recordsincome").on("mouseover", function() {
			var widthint = parseInt($("#income").css("width"))-56
			widthint = 36-widthint/2
			$(".incomehint").css("left",widthint+"px")
			$(".incomehint").show()
		})
		$(".recordsincome").on("mouseout", function() {
			$(".incomehint").hide()
		})



		var investMoney = 0
		showTab();
		//显示初始化tab
		function showTab() {
			$('#tablist a').click(function(e) {
				e.preventDefault()
				$(this).tab('show')
			})
			$('#tablist a:first').tab('show') // Select first tab
		}
		//监听投资借文本框change事件
		$('#invest')
			.on('focus', function() {
				$('#invest').on('keyup', function(e) {
					var money = $(this).val()
					if(money) {
						if(money.match(/^(([1-9]\d*)|0)(\.\d{0,2})?$/g) || money.match(/^[1-9]\d*?$/g) || ('' + money).indexOf('.') == (money.length - 1)) {
							money = parseFloat(money)
							investMoney = money
							GHutils.calcIncome(investMoney,_this.param,function(income){
								if(income=="calcing"){
									$('#income').html("计算中");
								}else{
									$('#income').html('<font color="#e45038">'+income+'</font>元');
								}
							})
						} else {
							$('#invest_errorMessage').html(GHutils.errorMessage('金额格式不正确'))
							return false;
						}
					}else{
						$('#income').html('<font color="#e45038">0.00</font>元')
					}
					$('#invest_errorMessage').html('&nbsp;')
					investMoney = parseFloat(money == '' ? 0 : money)
				}.bind(this))
			})
			.on('blur', function() {
				$(document).off('keyup')
			})
		function coculateIncome(investMoney, procent, n, incomeCalcBasis) {
			var a = GHutils.Fmul(investMoney, GHutils.Fdiv(procent, 100))
			var b = GHutils.Fdiv(n, incomeCalcBasis)
			return GHutils.Fmul(a, b)
		}
		function countIncome(investMoney) {
			var procent = null;
			var income = ''
			var rewardInterest = parseFloat(_this.param.rewardInterest + 0)
			procent = parseFloat(_this.param.expAror) + parseFloat(rewardInterest)
			if(_this.param.durationPeriodType=="DAY"){
				income = GHutils.formatCurrency(coculateIncome(investMoney, procent, _this.param.durationPeriodDays, _this.param.incomeCalcBasis))
			}else if(_this.param.durationPeriodType=="MONTH"){
				income = GHutils.formatCurrency(coculateIncome(investMoney, procent, _this.param.durationPeriodDays, 12))				
			}
			return income
		}
		//点击减号
		$('#descInvest').on('click', function() {
			var money = $('#invest').val()
			if(money) {
				if(!/^\d+(\.\d+)?$/.test(money)) {
					$('#invest_errorMessage').html(GHutils.errorMessage('金额格式不正确'))
					return false;
				}
			}
			investMoney = parseFloat(money == '' ? 0 : money)
			investMoney = GHutils.Fsub(investMoney, _this.param.addMoney)
			if(investMoney < _this.param.minMoney) {
				$('#invest').val('')
				investMoney = 0
				$('#income').html('<font color="#e45038">0.00</font>元')
				return false;
			}
			$('#invest').val(investMoney)
			GHutils.calcIncome(investMoney,_this.param,function(income){
				if(income=="calcing"){
					$('#income').html("计算中");
				}else{
					$('#income').html('<font color="#e45038">'+income+'</font>元');
				}
			});
		})

		//点击加号图标
		$('#adInvest').on('click', function() {
			var money = $('#invest').val()
			if(money) {
				if(!/^\d+(\.\d+)?$/.test(money)) {
					$('#invest_errorMessage').html(GHutils.errorMessage('金额格式不正确'))
					return false;
				}
			}
			investMoney = parseFloat(money == '' ? 0 : money)
			if(investMoney == 0 && _this.param.addMoney < _this.param.minMoney) {
				investMoney = GHutils.Fadd(investMoney, _this.param.minMoney)
			} else {
				investMoney = GHutils.Fadd(investMoney, _this.param.addMoney)
			}
			$('#invest').val(investMoney)
			GHutils.calcIncome(investMoney,_this.param,function(income){
				if(income=="calcing"){
					$('#income').html("计算中");
				}else{
					$('#income').html('<font color="#e45038">'+income+'</font>元');
				}
			});

		})
		//点击立即抢购
		$('#goInvest').on('click', function() {
            if(GHutils.userinfo) {
				GHutils.load({
					url: "/zybusiness/order/invest/prepose",
					data: {
						productId: _this.param.productOid
					},
					type: "post",
					callback: function(result) {
						if(result.code != 10000) {
							$('#invest_errorMessage').html(GHutils.errorMessage(result.message))
							return false;
						}
						if(result.data.valid) {
                            var money = $('#invest').val()
                            if(money && !/^\d+(\.\d+)?$/.test(money)) {
                                $('#invest_errorMessage').html(GHutils.errorMessage('金额格式不正确'))
                                return false;
                            }
                            investMoney = parseFloat(money == '' ? 0 : money)
                            if(!investMoney) {
                                $('#invest_errorMessage').html(GHutils.errorMessage('起投金额不能为空'))
                                return false;
                            }
                            if(investMoney > result.data.maxInvestAmount) {
                                $('#invest_errorMessage').html(GHutils.errorMessage('金额不可超过最大可投金额'))
                                return false;
                            }
                            getMaxInvestMoney();
						} else {
                            $('#invest_errorMessage').html(result.data.validDesc)
						}
					}
				})
            } else {
                // $("#showLogin").trigger("click");
                location.href = "/regandlog.html?type=log";
            }
		})

		function getMaxInvestMoney() {
			if(!_this.param) {
				$('#invest_errorMessage').html(GHutils.errorMessage('产品不存在!'))
				return false;
			}
			var isFresh = false
			var lables = _this.param.labelList
			if(GHutils.getProductStatus(_this.param.state)==1){
				$('#invest_errorMessage').html(GHutils.errorMessage('该产品募集结束'))
				return
			}else if(GHutils.getProductStatus(_this.param.state)==-1){
				$('#invest_errorMessage').html(GHutils.errorMessage('该产品还未开始'))
				return
			}
			// for(var i = 0; i < lables.length; i++) {
			// 	if(lables[i].labelNo == '1') {
			// 		i = lables.length
			// 		isFresh = true
			// 	}
			// }
            checkInvestMoney();
		}

		var checkInvestMoney = function() {
			if(investMoney < _this.param.minMoney) {
				$('#invest_errorMessage').html(GHutils.errorMessage('金额不能小于起投金额 ' + GHutils.formatCurrency(_this.param.minMoney) + '元'))
				return false;
			} else if(GHutils.Fdiv(GHutils.Fsub(investMoney, _this.param.minMoney), _this.param.addMoney) % 1 != 0) {
				$('#invest_errorMessage').html(GHutils.errorMessage('金额必须为起投金额' + GHutils.formatCurrency(_this.param.minMoney) + '元+递增金额' + GHutils.formatCurrency(_this.param.addMoney) + '元整数倍 '))
				return false;
			}
			// var maxInvestMoney = _this.param.raisedTotalNumber - _this.param.collectedVolume //产品剩余可投金额
			// if(_this.param.investMax) { //investMax有限制
			// 	var singleInvestMax = GHutils.Fmul(_this.param.investMax, _this.param.netUnitShare)
			// 	if(maxInvestMoney > singleInvestMax) {
			// 		maxInvestMoney = singleInvestMax
			// 	}
			// } else { //investMax 0或null表示无限额
            //
			// }
            //
			// if(investMoney > maxInvestMoney) {
			// 	$('#invest_errorMessage').html(GHutils.errorMessage('金额不可超过最大可投金额'))
			// 	return false;
			// }
			window.location.href = 'account-apply.html?moneyVolume=' + investMoney + '&productOid=' + _this.param.productOid + '&pType=tn&pName=' + encodeURI(_this.param.productName) + '&dpDays=' + _this.param.durationPeriodDays + '&income=' + _this.param.incomeCalcBasis + '&duration=' + _this.param.durationPeriodType + '&expAror=' + _this.param.expAror + '&reward=' + _this.param.rewardInterest;
		}

		
	},
	

	createPage: function(pageCount, proOid) {
		$(".tcdPageCode").show()
		if(pageCount <= 1) {
			$(".tcdPageCode").hide()
		}
		var _this = this;
		$(".tcdPageCode").createPage({
			pageCount: pageCount,
			current: 1,
			backFn: function(page) {
				_this.getData(page, false, proOid);
			}
		});
	},
	getData: function(page, isFlag, productOid) {
		var _this = this;
		GHutils.load({
			url: "/actives1/product/getV1InvestRecord",
			data: {
                productType: _this.param.typeCode,
				productOid: productOid,
				pageInfo: {
					pageNo: page,
					pageSize: 10
				}
			},
			type: "post",
			callback: function(result) {
				if(result.code != 10000) {
					return false;
				}
				if(result.data.pageInfo.totalSize == 0) {
					return false;
				}
				$('#noReCord').addClass('none')
				$('#investRecords').removeClass('none')
				if(result.data.documents.title&&result.data.documents.content){
					var tds = '<li class="chuizicont col-xs-12"><p class="col-xs-4" style="text-align:left;">'+result.data.documents.title+'</p><p class="col-xs-8">'+result.data.documents.content+'</p></li>';
					tds += '<li class="chuizitits col-xs-12"><p class="col-xs-4" style="text-align:left;">投资用户</p><p class="col-xs-4">投资金额</p><p class="col-xs-4" style="text-align:right;">投资时间</p></li>';
				}else{
					var tds = '<li class="tits col-xs-12"><p class="col-xs-4" style="text-align:left;">投资用户</p><p class="col-xs-4">投资金额</p><p class="col-xs-4" style="text-align:right;">投资时间</p></li>';
				}
				
				GHutils.forEach(result.data.content, function(idx, record) {
					//添加奖励的图标
					function addActivityTypes() {
						var activityTypesItem = ""
						if(!record.activityTypes) {
							return ""
						}
						if(record.activityTypes.indexOf("hammer") != -1) {
							activityTypesItem += '<img src="static/images/chuizi.png" title="一锤定音:此项目满标者可获惊喜红包" style="display: inline-block;height: 26px;vertical-align: middle;margin-left: 13px;" />'
						}
						if(record.activityTypes.indexOf("famous") != -1) {
							activityTypesItem += '<img src="static/images/famous.png" title="一鸣惊人:此项目单笔投资最高者可获惊喜红包" style="display: inline-block;height: 26px;vertical-align: middle;margin-left: 13px;" />'
						}
						return activityTypesItem
					}
					tds += '<li class="titscon col-xs-12 tr_w_h tr_coor ' + (idx % 2 == 1 ? 'active' : '') + '"><p class="col-xs-4" style="text-align:left;">' + record.userPhone + addActivityTypes() + '</p><p class="col-xs-4">' + GHutils.formatCurrency(record.orderAmount) + '元</p><p class="col-xs-4" style="text-align:right;">' + GHutils.formatTimestamp({
						time: record.createTime,
						showtime: "false"
					}) + '</p><p></p></li>'
				})
				$('#investRecords').html(tds)
				if(isFlag) {
					_this.createPage(Math.ceil(result.data.pageInfo.totalSize / 10), productOid);
				}
			}
		})
	}
}

$(function() {
	new HUOQI().init();
	$(".boxs").on("click", "li", function() {
		var index = $(this).index();
		var cName = $(this).attr("class");
		if(cName != "active") {
			if(index == 0) {
				$('.top_lines').animate({
					'left': '0'
				}, 300);
			} else if(index == 1) {
				$('.top_lines').animate({
					'left': '400px'
				}, 300);
			} else {
				$('.top_lines').animate({
					'left': '800px'
				}, 300);
			}
		}
	})
})