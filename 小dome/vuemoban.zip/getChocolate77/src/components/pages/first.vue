<template>
  <div class="first">
    <input type="number" class="inp" oninput="if(value.length>11)value=value.slice(0,11)" v-model="phone" placeholder="输入手机号领取巧克力">
    <div class="msg">
      <input type="number" class="vri" v-model="identify" oninput="if(value.length>6)value=value.slice(0,6)" placeholder="输入验证码">
      <div class="msgbutton" @click="getidentify" :style="{background : msgback }"> <div class="spin"><Spinner :size="size" bgcolor="#ffffff" forecolor="transparent" v-show="spin" /></div> <span> {{downtime}}</span></div>
    </div>
    <div class="prompt" v-show="show">
      {{prompt}}
    </div>
    <img src='../../assets/open.png' class="bg" @click="entrys" />
    <img src="../../assets/goapp.png" class="goapp" @click="goapp" />

    <div class="tishi" v-show="showtishi">
      <div class="shade" @click="closeshade">
        <img class="jiantou" src="../../assets/arrow.png" />
        <ul class="dianji">
          <li>1.点击右上角的按钮</li>
          <li>2.选择在浏览器中打开</li>
          <li>3.下载掌悦理财APP</li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import router from '../../router'
import { Spinner } from '../Spinner'
export default {
  name: 'first',
  data() {
    return {
      prompt: "",
      show: false,
      phone: "",
      identify: "",
      downtime: "获取验证码",
      time: 120,
      channelid: '999920170828234606',
      showtishi: false,
      size: lib.flexible.dpr * 15,
      spin: false,
      logins: false,
      getmsg:false,
      msgback:"#ff8d07"
    }
  },
  components: {
    Spinner
  },
  methods: {
    goapp() {
      location.href = "static/downLoad.html?cid="+this.channelid;
      return
      //判断设备类型和浏览器环境
      // function ue() {
      //   var e = navigator.userAgent.toLowerCase();
      //   return {
      //     iphone: /iphone/.test(e),
      //     android: /android/.test(e),
      //     winphone: /windows phone/.test(e),
      //     weixin: /micromessenger/.test(e),
      //     qqnews: /qqnews/.test(e),
      //     mqqbrowser: /mqqbrowser/.test(e),
      //     qq: /\sqq/.test(e)
      //   }
      // }
      // //下载app
      // if (ue().weixin == true) {
      //   this.showtishi = true;
      //   document.getElementById("html").className = 'ovfHiden'
      // } else {
      //   if (ue().iphone == true) {
      //     location.href = 'https://itunes.apple.com/app/id1203692435';
      //   } else if (ue().android == true) {
      //     var _url = this.channelid.substr(0, 12) + "4" + this.channelid.substring(13);
      //     location.href = '/app/' + _url + '.apk';
      //   }
      // }
    },
    closeshade() {
      var timers = null;
      document.getElementById("html").className = ''
      this.showtishi = false;
    },
    getidentify() {
      this.spin = true;
      if (!this.test_phone(this.phone)) {
        this.promptshow("请输入正确的手机号")
        return false
      }
      if (this.time < 120) {
        this.promptshow("验证码已发送")
        return false
      }

      this.$http.post('/jzucapp/sendvc', JSON.stringify({ phone: this.phone, smsType: "regist", values: ["", "2"] })).then((response) => {

        // 已经注册用户将注册改为登陆
        if (response.body.errorCode == 30002) {
          this.logins = true;
          this.$http.post('/jzucapp/sendvc', JSON.stringify({ phone: this.phone, smsType: "login", values: ["", "2"] })).then((response) => {
            if (response.body.errorCode == 0) {
              this.getmsg = true;
              window.timer = setInterval(this.countDown, 1000);
              this.msgback = "#999"
              this.promptshow("验证码发送成功")
            } else {
              this.getmsg = false;
              this.msgback = "#ff8d07"
              clearInterval(window.timer)
              this.promptshow(response.body.errorMessage)
            }
          })

        } else {
          this.logins = false;
          if (response.body.errorCode == 0) {
            this.getmsg = true;
            window.timer = setInterval(this.countDown, 1000);
            this.msgback = "#999"
            this.promptshow("验证码发送成功")
          }
          else {
            this.getmsg = false;
            this.msgback = "#ff8d07"
            clearInterval(window.timer)
            this.promptshow(response.body.errorMessage)
          }
        }

      }, (response) => {
        this.getmsg = false;
        clearInterval(window.timer)
        this.promptshow(response.body.errorMessage)
      });
    },
    entrys() {
      if (!this.test_phone(this.phone)) {
        this.promptshow("请输入正确的手机号")
        return false
      }
      if (!this.getmsg) {
        this.promptshow("请先获取验证码")
        return false
      }
      if (this.logins) {
        // 登陆
        this.$http.post('/jzucapp/login', JSON.stringify({ userAcc: this.phone, vericode: this.identify, platform: "app"})).then((response) => {
          if (response.body.errorCode == 0) {
            router.push({ name: 'Activite', params: { data: "{}" } })
          } else {
            this.promptshow(response.body.errorMessage)
          }
        }, (response) => {
          this.promptshow(response.body.errorMessage)
        });
      } else {
        // 注册
        this.$http.post('/jzucapp/register', JSON.stringify({ userAcc: this.phone, vericode: this.identify, platform: "app", channelid: this.channelid,sceneId:global.inviteCode})).then((response) => {
          if (response.body.errorCode == 0) {
            router.push({ name: 'Activite', params: { data: "{}" } })
          } else {
            this.promptshow(response.body.errorMessage)
          }
        }, (response) => {
          this.promptshow(response.body.errorMessage)
        });

      }
    },
    countDown() {
      this.time -= 1;
      this.downtime = '重新获取' + this.time;
      if (this.time == 0) {
        this.time = 120;
        this.msgback = "#ff8d07";
        clearInterval(window.timer);
        this.downtime = "获取验证码";
      }
    },
    isMobile(str) {
      var reg = /^(1[3|4|5|7|8])[\d]{9}$/;
      if (reg.test(str)) {
        return true;
      } else {
        return false;
      }
    },
    test_phone(str) {
      if (!this.isEmpty(str)) {
        if (str.length == 11) {
          if (this.isMobile(str)) {
            return true;
          } else {
            return false;
          }
        } else {
          return false;
        }
      } else {
        return false;
      }
    },
    isEmpty(str) {
      if ((str.length == 0) || (str == null)) {
        return true;
      } else {
        return false;
      }
    },
    promptshow(str) {
      this.spin = false;
      clearTimeout(t);
      this.prompt = str
      var _this = this;
      this.show = true;
      var t = setTimeout(function () {
        _this.show = false;
      }, 2000)
    }
  },
  created(){
    function getQueryString(name) {
				var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
				var r = window.location.search.substr(1).match(reg);
				if(r != null) return unescape(r[2]);
				return null;
      }
      try {
        global.inviteCode = getQueryString("inviteCode").split('/')[0]
      } catch (error) {
        if(getQueryString("code")!=90999){
            this.promptshow("该盒子链接无效！")
         }
      }

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='scss'>
@import "../../style/utils.scss";
input::-webkit-input-placeholder,
textarea::-webkit-input-placeholder {
  color: #baa4d6;
}

input:-moz-placeholder,
textarea:-moz-placeholder {
  color: #baa4d6;
}

input::-moz-placeholder,
textarea::-moz-placeholder {
  color: #baa4d6;
}

input:-ms-input-placeholder,
textarea:-ms-input-placeholder {
  color: #baa4d6;
}

.first {
  position: relative;
  text-align: center;
}

.first .bg {
  width: 7.1333rem;
  margin: 0 auto;
  padding-bottom: 0.4133rem;
}

.first .goapp {
  width: 7.1333rem;
  margin: 0 auto;
}

.inp {
  width: 6.48rem;
  height: 1.2267rem;
  border-radius: 0.1867rem;
  margin-top: 0.6667rem;
  padding-left: 0.64rem;
  background: #ffffff;
  @include font-dpr(14px);
}

.msg {
  width: 7.12rem;
  height: 1.2267rem;
  margin: 0 auto;
  padding-top: 0.2933rem;
  padding-bottom: 0.6667rem;
  position: relative;
}

.msg .vri {
  background: #ffffff;
  border-radius: 0.1867rem;
  height: 100%;
  width: 6.48rem;
  padding-left: 0.64rem;
  @include font-dpr(14px);
}

.msg .msgbutton {
  border-radius: 0.1333rem;
  position: absolute;
  top: 0.45rem;
  right: 0.1333rem;
  height: 0.88rem;
  padding: 0.04rem 0.2133rem 0;
  color: #ffffff;
  line-height: 0.90rem;
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  @include font-dpr(14px);
}
.msg .msgbutton span{
  display: inline-block;
  height: 0.88rem;
  width: 2.7rem;
}

.tishi {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 100;
}

.shade {
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, .7);
}

.jiantou {
  width: 4.9rem;
  height: 4.84rem;
  position: absolute;
  top: .4rem;
  right: .41rem;
}

.dianji {
  // padding: 5.66rem 0 0 2.25rem;
  padding-top: 5.66rem;
  margin: 0 auto;
}

.dianji li {
  color: #fff;
  @include font-dpr(20px);
  margin-bottom: 2.05rem;
}

.prompt {
  position: absolute;
  text-align: center;
  background: rgba(0, 0, 0, .5);
  color: #FFFFFF;
  width: 60%;
  height: 1.2rem;
  line-height: 1.2rem;
  top: 40%;
  left: 20%;
  @include font-dpr(14px);
}
.spin{
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right: .05rem;
}
</style>
