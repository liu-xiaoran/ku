(function() {
	var TEMP = (function() {
		return {
			init: function() {
				require.config({
					baseUrl: '/',
					waitSeconds: 0
				});
				var _this = this;
				_this.loadTemplates($('body'));
				$.get("/common-template/user-center.html",function(data){
					$('body').append(data);
					$('html,body').off().on('click',".protocol", function() {
						
						var tile = $(this).html(),type=$(this).attr('data-typeId');
						$.get('/actives1/static/protocolDetail?type=' + type+"&r="+GHutils.getMinutesTimestamp(), function(templates) {
							var begin = templates.indexOf('<body');
							var end = templates.indexOf('</body>');
							var temp = begin>=0?templates.substr(begin, end):templates;
							$('.protocol-content').html(temp)
							$('.protocol-title').html(tile)
							$('#protocol-box').modal('show');
							$('#protocol-box').on('hidden.bs.modal', function() {
								if(type=='fast'){
									setTimeout(function(){
										$('body').addClass("modal-open")
									},500)
									
								}
							})
							
						});
						
					})
					//临时升级提示
         //            GHutils.load({
         //                url: '/notice1/pc/index_top.json',
         //                type: "get",
         //                async: false,
         //                callback: function(result) {
         //                    if(result.errorCode != 0) {
         //                        return;
         //                    } else {
         //                        for(var i = 0;i < result.rows.length;i++) {
         //                            // if(result.rows[i].title == "10月21日延迟1小时开服公告") {
                                    	
         //                            // }
         //                            $(".bs-alert-modal-sm .modal-dialog").css({width: '65%',marginTop: '3%'});
         //                        	if(result.rows[i].linkHtml) {
         //                                GHutils.alert({
         //                                	title:"10月21日延迟3小时开服公告",
         //                                    text: result.rows[i].linkHtml,
         //                                    close: false
         //                                })
									// } else {
         //                                GHutils.alert({
         //                                	title:"10月21日延迟3小时开服公告",
         //                                    text: '<p class="p1">    尊敬的掌悦理财用户：</p><p class="p2"><br/></p><p class="p1">    您好！</p><p class="p2"><br/></p><p class="p1">    为了进一步提高平台系统的稳定性，优化系统功能，改善用户体验，平台原定于10月20日23:50-21日15:00停服更新，预计将推迟3小时（18:00）开服。</p><p class="p2"><br/></p><p class="p1">    届时将暂停所有服务，您将无法访问掌悦理财的网站及APP。</p><p class="p2"><br/></p><p class="p1">    停服期间，所有在投产品正常计算收益，回款正常到账。</p><p class="p2"><br/></p><p class="p1">    若您在停服期间遇到任何问题，可通过以下方式联系我们，客服人员将在第一时间解答您的疑问：（人工服务时间：09:00~18:00）</p><p class="p2"><br/></p><p class="p1">    1. 拨打客服热线400-611-8088</p><p class="p1">    2. 关注掌悦理财微信公众号咨询</p><p class="p2"><br/></p><p class="p1">    掌悦理财运营团队</p><p class="p1">    2017年10月21日</p><p><br/></p>',
         //                                    close: false
         //                                })
									// }
         //                        }
         //                    }
         //                }
         //            });
				})
				requirejs(['static/js/common-template/header','static/js/common-template/footer'], function() {
					for(var key in arguments) {
						if(arguments[key] != undefined && arguments[key].name != undefined) {
							arguments[key].init();
						}
					}
					
				})
			},
			loadTemplates: function(dom) {
				
				var doms = dom.find('[template-href]');
				doms.each(function(index, item) {
					var templateHref = $(item).attr('template-href');
					$(item).load('/common-template/' + templateHref + '.html', function(e) {
						this.innerHTML = e;
						var fnlist = ['static/js/common-template/' + templateHref];
						requirejs(fnlist, function() {
							for(var key in arguments) {
								if(arguments[key] != undefined && arguments[key].name != undefined) {
									arguments[key].init();
								}
							}
							if(index == doms.length - 1) {
								$(function() {
									new QRCode(document.getElementById("build-qrcode1"), {
										text:location.origin+"/h5/dl/?contractId="+contractId,
										width : 150,
										height : 150
									});
									$("img").lazyload({
										effect: "fadeIn"
									});
								});
							}
						})
					})
				})
			}
		}
	})

	$(function() {
		new TEMP().init();
	});
})();