<template>
  <div class="foot">
    <img src="../../assets/foot.png">
  </div>
</template>

<script>
export default {
  name: 'foot'
 
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
