<template>
  <div class="lists">
    <img src="../../assets/lists.png" v-show="showimg" class="listsimg">
    <ul class="list">
      <li v-for="item in listpros">
        <div class="pic"><img :src="item.headimgurl" v-if="item.headimgurl"></div>
        <div class="text">
          <p class="phone">{{item.phone}}</p>
          <p class="time">{{item.leadTime | timeformat}}</p>
        </div>
        <div class="money">
          <span class="award">{{item.amount}}</span>元</div>
      </li>
    </ul>
    <div class="prompt" v-show="show">
      {{prompt}}
    </div>
  </div>
</template>

<script>
export default {
  name: 'lists',
  data() {
    return {
      prompt: "",
      show: false,
      headimg: "",
      listpros: [],
      showimg:false
    }
  },
  filters:{
    timeformat: function(time){
      var newDate = new Date(time)
      // return newDate.format('yyyy-MM-dd h:m:s').substr(0,16)
      return newDate.format('yyyy-MM-dd hh:mm')
      
    }
  },
  methods:{
    promptshow(str) {
      clearTimeout(t);
      this.prompt = str
      var _this = this;
      this.show = true;
      var t = setTimeout(function () {
        _this.show = false;
      }, 2000)
    }
  },
  created() {
    // 格式化时间
    Date.prototype.format = function (format) {
      var date = {
        "M+": this.getMonth() + 1,
        "d+": this.getDate(),
        "h+": this.getHours(),
        "m+": this.getMinutes(),
        "s+": this.getSeconds(),
        "q+": Math.floor((this.getMonth() + 3) / 3),
        "S+": this.getMilliseconds()
      };
      if (/(y+)/i.test(format)) {
        format = format.replace(RegExp.$1, (this.getFullYear() + '').substr(4 - RegExp.$1.length));
      }
      for (var k in date) {
        if (new RegExp("(" + k + ")").test(format)) {
          format = format.replace(RegExp.$1, RegExp.$1.length == 1
            ? date[k] : ("00" + date[k]).substr(("" + date[k]).length));
        }
      }
      return format;
    }
    function getQueryString(name) {
      var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
      var r = window.location.search.substr(1).match(reg);
      if (r != null) return unescape(r[2]);
      return null;
    }
    try {
        global.boxOid = getQueryString("boxOid").split('/')[0]
      } catch (error) {
        if(getQueryString("code")!=90999){
            this.promptshow("请重新获取分享！！！")
         }
      }
    if(getQueryString("code")!=90999){
    this.$http.post("/actives/activity/chocolateBoxList", { "data": { 'boxOid': global.boxOid } }).then((response) => {
        if(response.body.code==10000){
            if(response.body.data.list.length==0){
            }else{
                this.showimg = true
                this.listpros = response.body.data.list
            }
        }else{
            this.promptshow(response.body.message)
        }
    })
  }

  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='scss'>
@import "../../style/utils.scss";
.list {
  background: #460f77;
  padding-bottom: 0.8533rem;
}

.list li {
  height: 1.1333rem;
  border-top: 3px solid #531b99;
  overflow: hidden;
  padding: 0.2133rem 0 0.24rem 0;
  margin: 0 0.76rem 0 0.6267rem;
}

.list li:first-child {
  border: none;
}

.list .pic {
  width: 1.1333rem;
  height: 1.1333rem;
  border-radius: 0.0667rem;
  background: url('../../assets/headicon.png') no-repeat center;
  background-size: 100% auto;
  float: left;
  overflow: hidden;
}
.list .pic img{
  display: inline-block;
  width: 100%;
  height: 100%;
}
.text {
  float: left;
  padding-left: 0.2133rem;
}

.text p {
  line-height: 0.56rem;
  @include font-dpr(12px);
  color: #e6c6ff;
}

.money {
  float: right;
  line-height: 1.1333rem;
  @include font-dpr(22px);
  color: #fee9b7;
}
.money span{
  margin-right: 0.04rem;
}
.prompt {
  position: absolute;
  text-align: center;
  background: rgba(0, 0, 0, .5);
  color: #FFFFFF;
  width: 60%;
  height: 1.2rem;
  line-height: 1.2rem;
  top: 40%;
  left: 20%;
  @include font-dpr(14px);
}
.listsimg{
  margin-top: 0.4667rem;
}
</style>
