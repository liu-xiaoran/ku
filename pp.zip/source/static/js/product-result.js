var T0Success = function() {
	return this;
}

T0Success.prototype = {
	init: function() {
		this.pageInit();
		this.bindEvent();
	},
	pageInit: function() {
		var _this = this
		$('#redeemSuccess').hide()
		$('#investSuccess').hide()
		var uraParam = GHutils.parseUrlParam(window.location.href)
		//产品转让
		if(uraParam.type && uraParam.type == "redeem") {
			$("#redeemMoney").html(uraParam.money)
            $("#redeemHand").html(GHutils.formatCurrency(uraParam.fee))
			$("#redeemTime").html(GHutils.formatTimestamp({
				showtime: "false"
			}))
			// $("#redeemArriveDay").html(GHutils.formatTimestamp({}))
			$("#redeemSuccess").show()
			return
		}
		var times = 0;
		
		//产品申购
		if(uraParam.productName && uraParam.moneyVolume && uraParam.pType) {
			$('#investSuccess2').removeClass('none')
			$('#failed').addClass('none')
			$('#investSuccess').show()
			$('#waiting').show()
			$('#waiting').addClass('none')
			$('#tobuy').click(function () {
                window.history.go(-1)
            })
			$('#failedMessaage').html(decodeURI(uraParam.mes)+',您可以<span><a id="tobuy" href="javascript:;">重新支付</a></span>')
			$('#success-title').html('恭喜您，成功投资掌悦《' + decodeURI(uraParam.productName) + '》<span class="em">' + GHutils.formatCurrency(uraParam.moneyVolume) + '</span> <i>元</i>')
			$('#success-item').html('<div>投资掌悦《' + decodeURI(uraParam.productName) + '》</div><div class="font">' + uraParam.moneyVolume + '元</div>')
			if(uraParam.pType == 'tn') {
				$('#interestArrivedDate').parent().parent().hide();
				$('#beginInterestDate').parent().parent().hide();
				$('.line_two').hide();
				$('.line').hide();
				$('#toInvest').attr('href', 'product-tn-list.html')
                //投资后奖励
                if(uraParam.orderId) {
                    GHutils.load({
                        url: "/platform1/Member/rewardStatusForInvest",
                        data: {
                            orderId: uraParam.orderId
                        },
                        type: "post",
                        callback: function(result) {
							if(result.code == 10000) {
                            	for(var i = 0; i < result.data.length; i++) {
                            		if(result.data[i].orderId == uraParam.orderId) {
                            			if(result.data[i].status == 0) {
                            				$(".no_lq").show();
                            				$("#noOpen").on("click",function () {
                                                GHutils.load({
                                                    url: "/platform1/Member/receiveRewardForInvest",
                                                    data: {
                                                        orderId: uraParam.orderId
                                                    },
                                                    type: "post",
                                                    callback: function(res) {
                                                    	if(res.code == 10000) {
                                                            if(res.data.rewardType == "voucher") {
                                                                $("#nextTitle").html('<span>'+res.data.rewardAmount+'</span>元'+res.data.rewardName);
                                                            	$("#toCoupon").show();
															} else if(res.data.rewardType == "redpacket"||res.data.rewardType == "scratchcard") {
                                                                $("#nextTitle").html(res.data.rewardName);
                                                                if(res.data.rewardType == "redpacket") {
                                                                    $("#isRed").attr("src","static/images/is-reds.png");
																}
															}
                                                            $(".no_lq").hide();
                                                            $(".next_lq").show();
														}
													}
                                                })
                                            })
										} else if(result.data[i].status == 1) {
                                            $(".is_lq").show();
										}
									}
								}
							}
                        }
                    })
                }
			} else {
				$('#interestArrivedDate').html(GHutils.formatTimestamp({
					time: uraParam.expectViewIncomeDate,
					showtime: "true"
				}).replace(/-/g, '/'))
				$('#beginInterestDate').html(GHutils.formatTimestamp({
					time: uraParam.expectInterestDate,
					showtime: "true"
				}).replace(/-/g, '/'))
			}
			return false;
		}
		//提现成功
		if(uraParam.action && uraParam.action == 'withdraw') {
			$('#withdraw').show()
			$('.withdraw-money').html(GHutils.formatCurrency(uraParam.moneyVolume))
			$('.withdraw-time').html(GHutils.formatTimestamp({
				"showtime": true
			}))
			if(uraParam.actualMoney){
				$(".actualMoneys").show()
				$('.actualMoney').html(GHutils.formatCurrency(uraParam.actualMoney))
			}else{
				$(".actualMoneys").hide()
			}
			if(uraParam.withdrawfee){
				$(".withdrawfees").show()
				$('.withdrawfee').html(GHutils.formatCurrency(uraParam.withdrawfee))
			}else{
				$(".withdrawfees").hide()
			}
			return false;
		}
		//充值成功
		if(uraParam.action && uraParam.action.indexOf('deposit') > -1) {
			if(uraParam.ResultDesc&&uraParam.Result&&uraParam.Result==0){
				var keyMap={
					"01":"支付成功", 
					"0000":"支付失败", 
					"0001":"系统错误", 
					"0002":"订单超时", 
					"0011":"系统维护", 
					"0012":"无效商户", 
					"0013":"余额不足", 
					"0014":"超过支付限额", 
					"0015":"卡号和卡密错误", 
					"0016":"不合法的IP地址", 
					"0017":"重复订单金额不符", 
					"0018":"卡密已被使用", 
					"0019":"订单金额错误", 
					"0020":"支付的类型错误", 
					"0021":"卡类型有误", 
					"0022":"卡信息不完整", 
					"0023":"卡号、卡密、金额不正确", 
					"0024":"不能用此卡继续做交易", 
					"0025":"订单无效"
				}
				$('#deposit_fail h3').html(keyMap[uraParam.ResultDesc]+'，您可以<span>&nbsp;<a href="account-deposit.html" style="font-size: 18px;color: #ec9437;">重新支付</a>&nbsp;</span>')
				$('#deposit_fail').show()
				return false;
			}else{
				$('#deposit').show()
				$('.deposit-money').html(GHutils.formatCurrency(uraParam.action.substr(8)))
				return false;
			}
			
		}
		window.location.href = '/index.html';
	},
	bindEvent: function() {
		var _this = this
		var checkLogin = function() {
			window.location.href = '/account-depositRecord.html'
		}
		$('#toRecord').on('click', function() {
			checkLogin();
		})
	}
}

$(function() {
	new T0Success().init();
})