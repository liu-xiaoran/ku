<template>
  <div class="header">
    <img src="../../assets/header.png">
  </div>
</template>

<script>
export default {
  name: 'header'
  
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
    .header img{
      display: block;
      height: 9.9733rem;
    }
</style>
