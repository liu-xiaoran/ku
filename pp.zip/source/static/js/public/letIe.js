
$(function(){
  $('#highScript').remove();
})
