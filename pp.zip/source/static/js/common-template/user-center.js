define([],
function() {
	return {
		name: 'user-center',
		init: function() {
			this.bindEvent();
			this.phoneLoginBindEvent(); //手机号登陆绑定事件
			this.userAccLoginBindEvent(); //账号登陆绑定事件
			this.registerEvent();
			this.loadProtocol();
		},
		pageInit: function() {
			GHutils.load({
				url: "/platform1/Member/info",
				data: {},
				type: "post",
				callback: function(result) {
					if(result.errorCode != 0 || !result.islogin) {
						$('#notLogin').show();
						$('#loginStatus').hide();
						return false;
					}
					$('#nickName').html('欢迎您，' + result.userAcc.substring(0, 3) + '***' + result.userAcc.substring(8, 11))
					//消息条数还不知道接口
					$('#messaageCtrl').html('消息')
					$('#loginStatus').show()
					$('#notLogin').hide();
					//用户中心部分，左上角的用户详情
					$('#infoName').html('你好，' + result.userAcc.substring(0, 3) + '***' + result.userAcc.substring(8, 11))
					$('#infoAcc').html('账户名：' + result.userAcc.substring(0, 3) + '***' + result.userAcc.substring(8, 11))
				}
			})
		},
		bindEvent: function() {
			var _this = this;
			$(".inputBindKey").off().keyup(function(e) {
				if(e.keyCode == 13) {
					if($(this).val() == '') {
						return
					}
					var trigger = $(this).attr("data-trigger");
					if(trigger) {
						$(trigger).trigger("click");
					}
				}
			})
			//点击登陆
			$(".showUserCentent").off().on("click", function() {
				var item = $(this).attr("data-id");
				// $('#userCentent').modal('show');
				// _this.clearModle(item);
				location.href=(item=="userLoginBox"?"/regandlog.html?type=log":"/regandlog.html?type=reg")
			});
			$(".showUserCententBox").off().on("click", function() {
				var item = $(this).attr("data-id");
				_this.clearModle(item);
			});
			//点击账号密码登陆
			$("#login-account").click(function() {
				//当前被点击的div改变背景色
				$(this).addClass("active");
				$("#login-phone").removeClass("active");
				$("#login-in-account").fadeIn(300);
				$("#login-in-phone").hide();
				$("#login-in-account input").val('')
				$("#account-errorMessage").html("");
			});
			//点击手机快捷登陆
			$("#login-phone").click(function() {
				$(this).addClass("active");
				$("#login-account").removeClass("active");
				$("#login-in-phone").fadeIn(300);
				$("#login-in-account").hide();
				$("#login-in-phone input").val('')
				$("#phone-errorMessage").html("");
			});
		},
		clearModle: function(item) {
			$('#userCentent input').val('');
			$(".tipstxt").html();
			$(".userCententBox").hide();
			$("." + item).fadeIn(300);
			$('#account-errorMessage').html('')
			$('#phone-errorMessage').html('')
			$('#register_errorMessage').html('')
			$('#getVerifyCode').removeClass('sending')
			$('#register_getVerifyCode').removeClass('sending')
		},
		phoneLoginBindEvent: function() { //手机验证码登录点击事件
			var _this = this;
			$("#userPhoneLogin").click(function() {
				if(GHutils.validate('login-in-phone')) {
					if($(this).is('.submiting')) {
						return false;
					}
					$(this).addClass('submiting')
					_this.cancelSubmiting()
					_this.phoneLogin();
				}
			});
			//获取验证码
			$("#getVerifyCode").click(function() {
				var errorMessage = document.getElementById("phone-errorMessage");
				errorMessage.innerHTML = ' ';
				if($(this).hasClass('sending')) { //正在进行倒计时
					return;
				}
				var userPhone = GHutils.trim($("#userPhone").val());
				if(userPhone == "") {
					errorMessage.innerHTML = "提示： 手机号不能为空";
					return;
				}
				// if(!(/^1(3|4|5|7|8)\d{9}$/.test(userPhone))) {
				// 	errorMessage.innerHTML = "提示： 手机号格式不正确";
				// 	return;
				// }
				GHutils.load({
					url: "/platform1/Userpub/sendsms",
					data: {
						phone: userPhone,
						smsType: "login"
					},
					type: "post",
					callback: function(result) {
						if(result.code != 10000) {
							errorMessage.innerHTML = '提示： ' + result.message;
							return false;
						}
						$('#getVerifyCode').addClass('sending')
						countdown()
					},
					errcallback: function() {}
				});
			})
			//倒计时
			var time = 120
			var countdown = function() {
				if(time > 1 && $('#getVerifyCode').is('.sending')) {
					time -= 1
					$('#getVerifyCode').html("重新获取(" + time + ")")
					setTimeout(countdown, 1000)
				} else {
					$('#getVerifyCode').html('获取验证码')
					$('#getVerifyCode').removeClass('sending')
				}
			}
			//电话号码监听
			$('#userPhone')
				.on('focus', function() {
					$(document).keyup(function(e) {
						if(e.keyCode === 13) {
							var value = GHutils.trim($('#userPhone').val())
							if(!value) {
								return false
							// } else if(!(/^1(3|4|5|7|8)\d{9}$/.test(value))) {
							// 	$('#phone-errorMessage').html('提示： 手机号格式不正确')
							} else if(!GHutils.trim($('#verifyCode').val())) {
								$('#verifyCode').focus()
							}
						}
					})
				})
				.on('blur', function() {
					$(document).off('keyup')
				})
				.on('change', function() {
					$('#getVerifyCode').removeClass('sending')
				})

			// '密码'的 focus 和 blur 事件
			$('#verifyCode')
				.on('focus', function() {
					$(document).keyup(function(e) {
						if(e.keyCode === 13) {
							if(GHutils.validate('login-in-phone')) {
								if($("#userPhoneLogin").is('.submiting')) {
									return false;
								}
								$("#userPhoneLogin").addClass('submiting')
								_this.cancelSubmiting()
								_this.phoneLogin();
							}
						}
					})
				})
				.on('blur', function() {
					$(document).off('keyup')
				})
		},
		phoneLogin: function() { //电话号码登陆
			var _this = this;
			var param = {
				phone: GHutils.trim($("#userPhone").val()),
				veriCode: GHutils.trim($("#verifyCode").val()),
				platform: "pc",
				contractId: contractId
			}
			var errorMessage = document.getElementById("phone-errorMessage");
			_this.doLogin(param, errorMessage);

		},
		userAccLoginBindEvent: function() { //账号密码登录点击事件
			var _this = this;
			$("#userAccountLogin").on('click', function() {
				if(GHutils.validate('login-in-account')) {
					if($("#userAccountLogin").is('.submiting')) {
						return false;
					}
					$("#userAccountLogin").addClass('submiting')
					_this.cancelSubmiting()
					_this.userAccLogin();
				}

			});

			// '账户名'的 focus 和 blur 事件
			$('#userAccount')
				.on('focus', function() {
					$(document).keyup(function(e) {
						if(e.keyCode === 13) {
							var value = GHutils.trim($('#userAccount').val())

							if(!value) {
								return false
							// } else if(!(/^1(3|4|5|7|8)\d{9}$/.test(value))) {
							// 	$('#account-errorMessage').html('提示： 手机号格式不正确')
							} else if(!GHutils.trim($('#userPassword').val())) {
								$('#userPassword').focus()
							}
						}
					})
				})
				.on('blur', function() {
					$(document).off('keyup')
				})

			// '密码'的 focus 和 blur 事件
			$('#userPassword')
				.on('focus', function() {
					$(document).keyup(function(e) {
						if(e.keyCode === 13) {
							if(GHutils.validate('login-in-phone')) {
								if($("#userAccountLogin").is('.submiting')) {
									return false;
								}
								$("#userAccountLogin").addClass('submiting')
								_this.cancelSubmiting()
								_this.userAccLogin();
							}
						}
					})
				})
				.on('blur', function() {
					$(document).off('keyup')
				})
		},
		userAccLogin: function() { //账号密码登陆
			var _this = this;
			var param = {
				phone: GHutils.trim($("#userAccount").val()),
				userPwd: GHutils.trim($("#userPassword").val()),
				platform: "pc"
			}
			var errorMessage = document.getElementById("account-errorMessage");
			_this.doLogin(param, errorMessage);
		},
		doLogin: function(param, errorMessage) { //登陆方法
			var _this = this;
			var usrLogin = function(statu) {
				GHutils.load({
					url: "/platform1/Userpub/login",
					data: param,
					type: "post",
					callback: function(result) {
						$('#userPhoneLogin').removeClass('submiting')
						$("#userAccountLogin").removeClass('submiting')
						if(result.code == 10000) {
							$("#userLogin").css("display", "none");
							_this.pageInit()
							$('#userCentent').modal('hide')
							//刷新页面
							if(location.href.indexOf("sjzc_landingpage") >= 0 || location.href.indexOf("rrdp_landingpage") >= 0) {
								location.href = "/";
							} else {
								window.location.reload();
							}
						} else {
							errorMessage.innerHTML = '提示： ' + result.message;
						}
					}
				});
			}()
		},
		registerEvent: function() { //注册绑定事件
			var _this = this;
			var errorMessage = document.getElementById("register_errorMessage");
			//注册用户点击事件
			$("#registerSubmit").click(function() {
				if(GHutils.validate('registerForm')) {
					if(!$('#protocolCheck').is(':checked')) {
						$('#register_errorMessage').html('提示： 请同意《平台服务协议》')
						return false;
					}
					if($("#registerSubmit").is('.submiting')) {
						return false;
					}
					$("#registerSubmit").addClass('submiting')
					_this.cancelSubmiting()
					_this.doRegister();
				}
			});
			$("#register_userPhone").on('change', function() {
				$('#register_getVerifyCode').removeClass('sending')
			})
			//获取验证码
			$("#register_getVerifyCode").click(function() {
				var errorMessage = document.getElementById("register_errorMessage");
				errorMessage.innerHTML = ' ';
				if($(this).hasClass('sending')) {
					return;
				}
				var userPhone = GHutils.trim($("#register_userPhone").val());
				if(userPhone == "") {
					errorMessage.innerHTML = "提示： 手机号不能为空";
					return false;
				}
				// if(!(/^1(3|4|5|7|8)\d{9}$/.test(userPhone))) {
				// 	errorMessage.innerHTML = "提示： 手机号格式不正确";
				// 	return false;
				// }
				GHutils.load({
					url: "/platform1/Userpub/sendsms",
					data: {
						phone: userPhone,
						smsType: "regist"
					},
					type: "post",
					callback: function(result) {
						if(result.code != 10000) {
							errorMessage.innerHTML = '提示： ' + result.message;
							return false;
						}
						$('#register_getVerifyCode').addClass('sending')
						time = 120
						countdown()
					},
					errcallback: function() {}
				});
			})
			//倒计时
			var time = 120
			var countdown = function() {
				if(time > 1 && $('#register_getVerifyCode').is('.sending')) {
					time -= 1
					$('#register_getVerifyCode').html("重新获取(" + time + ")")
					setTimeout(countdown, 1000)
				} else {
					$('#register_getVerifyCode').html('获取验证码')
					$('#register_getVerifyCode').removeClass('sending')
				}
			}
		},
		doRegister: function() { //注册
			var _this = this
			var param = {
				phone: GHutils.trim($("#register_userPhone").val()),
				veriCode: GHutils.trim($("#register_verifyCode").val()),
				inviteCode: "",
				platform: "pc",
				contractId: contractId,
				otherArgs: encodeURIComponent(location.search.substring(1))
			}
			var register = function(statu) {
				GHutils.load({
					url: "/platform1/Userpub/login",
					data: param,
					type: "post",
					callback: function(result) {
						$("#registerSubmit").removeClass('submiting')
						if(result.code != 10000) {
							$('#register_errorMessage').html('提示： ' + result.message)
							return false;
						} else {
							_this.pageInit()
							$('#userCentent').modal('hide');
							$('#registerSuccess').modal('show');
							if(location.href.indexOf("sjzc_landingpage") >= 0) {
								location.href = "result_landpage.html";
							} else if(location.href.indexOf("rrdp_landingpage") >= 0) {
								location.href = "/"
							}
						}
					}
				});
			}()
		},
		cancelSubmiting: function() {
			var time = 10
			var countdown = function() {
				if($('.submiting').length > 0) {
					time -= 1
					setTimeout(countdown, 1000)
				} else {
					$('.submiting').removeClass('submiting')
				}
			}
			countdown()
		},
		loadProtocol: function() {
			//相关协议点击事件

			$('.protocol').off().on('click', function() {
				var tile = $(this).html()
				$.get('/actives1/static/protocolDetail?type=' + $(this).attr('data-typeId')+"&r="+GHutils.getMinutesTimestamp(), function(templates) {
					var begin = templates.indexOf('<body');
					var end = templates.indexOf('</body>');
					var temp = templates.substr(begin, end);
					$('.protocol-content').html(temp)
					$('.protocol-title').html(tile)
					$('#protocol-box').modal('show')
				});
				
			})
		}
	}
})