var times = 0
//获取验证码
$("#login_getVerifyCodes").click(function() {
	if($(this).hasClass('sending')) { //正在进行倒计时
		return;
	}
	var userPhone = GHutils.trim($("#login_phonecon").val());
	if(userPhone == "") {
		$("#fast_login_errorMessagecon").html("提示： 手机号不能为空");
		$(".promit_box1").show();
		return;
	}
	// if(!(/^1(3|4|5|7|8)\d{9}$/.test(userPhone))) {
	// 	$("#fast_login_errorMessagecon").html("提示： 手机号格式不正确");
	// 	$(".promit_box1").show();
	// 	return;
	// } else {
		GHutils.load({
			url: "/platform1/Userpub/sendsms",
			data: {
				phone: userPhone,
				smsType: "appLogin"
			},
			type: "post",
			callback: function(result) {
				if(result.data&&result.data.ttl) {
                    times = result.data.ttl
				} else {
                    times = 120
				}
				if(result.code==10000||result.code==99995) {
                    $('#login_getVerifyCodes').addClass('sending')
                    countdowns()
				}
				if(result.code != 10000) {
					$("#fast_login_errorMessagecon").html('提示： ' + result.message);
					$(".promit_box1").show();
					return false;
				}
				$(".promit_box1").hide();
			},
			errcallback: function() {}
		});
	// }
})

//倒计时
var countdowns = function() {
	if(times > 1 && $('#login_getVerifyCodes').is('.sending')) {
		times -= 1
		$('#login_getVerifyCodes').html("重新获取(" + times + ")")
		setTimeout(countdowns, 1000)
	} else {
		$('#login_getVerifyCodes').html('获取验证码')
        $('#login_getVerifyCodes').removeClass('sending')
	}
}


var doLogin = function(param, type) { //登陆方法
	var _this = this;
	GHutils.load({
		url: "/platform1/Userpub/login",
		data: param,
		type: "post",
		callback: function(result) {
			$('#userPhoneLogin').removeClass('submiting')
			$("#userAccountLogin").removeClass('submiting')
			if(result.code == 10000) {
				if(result.data.isRegister){
					GHutils.writeLoad({
						data:{
							evt:'appLoginRegister',
							ext:{
								'tellength':param.phone.length,
								"tel" : param.phone.substring(param.phone.length - 4),
								'veriCode': param.veriCode
							},
							ret:"ok"
						}
					})
				}
				$(".promit_box1").hide();
				$(".promit_box2").hide();
				if(document.referrer&&document.referrer.indexOf("regandlog")<0&&document.referrer.indexOf("find-pwd")<0&&document.referrer.indexOf("/landing/")<0) {
					location.href = document.referrer;
				} else {
					location.href = "/";
				}
			} else {
				if(type == "pwdLog") {
					$("#pwd_login_errorMessagecon").html('提示： ' + result.message);
					$(".promit_box2").show();
				} else if(type == "fastLog") {
					$("#fast_login_errorMessagecon").html('提示： ' + result.message);
					$(".promit_box1").show();
				}
				return false;
			}
		}
	});
}

var phoneLogin = function(type) { //电话号码登陆
	var _this = this;
	var param = {
		phone: GHutils.trim($("#login_phonecon").val()),
		veriCode: GHutils.trim($("#login_verifyCodes").val()),
		platform: "pc",
		contractId: contractId
	}
	doLogin(param, type);
}
$("#fastLogSubmits").click(function() {
	if(GHutils.trim($("#login_phonecon").val()) == "") {
		$("#fast_login_errorMessagecon").html("提示： 手机号不能为空");
		$(".promit_box1").show();
		return false;
	// } else if(!(/^1(3|4|5|7|8)\d{9}$/.test(GHutils.trim($("#login_phonecon").val())))) {
	// 	$("#fast_login_errorMessagecon").html("提示： 手机号格式不正确");
	// 	$(".promit_box1").show();
	// 	return false;
	} else if(GHutils.trim($("#login_verifyCodes").val()) == "") {
		$("#fast_login_errorMessagecon").html("提示： 验证码不能为空");
		$(".promit_box1").show();
		return false;
	} else if(!(/^\d{6}$/.test(GHutils.trim($("#login_verifyCodes").val())))) {
		$("#fast_login_errorMessagecon").html("提示： 验证码格式不正确");
		$(".promit_box1").show();
		return false;
	} else {
		phoneLogin("fastLog");
	}
})

var userAccLogin = function(type) { //账号密码登陆
	var _this = this;
	var param = {
		phone: GHutils.trim($("#login_phonecon").val()),
		userPwd: GHutils.trim($("#log_pwds").val()),
		platform: "pc"
	}
	doLogin(param, type);
}

$("#pwdLogSubmits").click(function() {
	if(GHutils.trim($("#login_phonecon").val()) == "") {
		$("#pwd_login_errorMessagecon").html("提示： 手机号不能为空");
		$(".promit_box2").show();
		return false;
	// } else if(!(/^1(3|4|5|7|8)\d{9}$/.test(GHutils.trim($("#login_phonecon").val())))) {
	// 	$("#pwd_login_errorMessagecon").html("提示： 手机号格式不正确");
	// 	$(".promit_box2").show();
	// 	return false;
	} else if(GHutils.trim($("#log_pwds").val()) == "") {
		$("#pwd_login_errorMessagecon").html("提示： 密码不能为空");
		$(".promit_box2").show();
		return false;
	} else if(GHutils.trim($("#log_pwds").val()).length<6||GHutils.trim($("#log_pwds").val()).length>16) {
		$("#pwd_login_errorMessagecon").html("提示： 密码格式不正确");
		$(".promit_box2").show();
		return false;
	} else {
		userAccLogin("pwdLog");
	}
});

$(document).keyup(function (e) {
	if($(".reglog_logins").css("display")=="block") {
        if (e.keyCode === 13) {
            if($(".pwd_logins").css("display")=="none") {
                $("#fastLogSubmits").click()
            } else if($(".fast_logins").css("display")=="none") {
                $("#pwdLogSubmits").click()
            }
        }
	}
})
