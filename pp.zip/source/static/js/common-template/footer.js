define([],
function() {
	return {
		name: 'footer',
		init: function() {
			this.pageInit();
			this.bindEvent();
		},
		pageInit: function() {
			var aqImg = $("#anquanBox").find("img")
		},
		bindEvent: function() {
            $("#showDate").on("click", function () {
                $(".apply-c-divs").modal("show");
            });
		},
	}
})