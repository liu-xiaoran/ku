(function (doc, win) {
	var docEl = doc.documentElement,dpr,
		resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize',
		recalc = function () {
			var clientWidth = docEl.clientWidth;//页面宽度
			if (!clientWidth) return;
			if (clientWidth >= 1080) {
				docEl.style.fontSize = '100px';
			} else {
				docEl.style.fontSize = 100 * (clientWidth / 1080) + 'px';
			}
		};
	if (!doc.addEventListener) return;
	win.addEventListener(resizeEvt, recalc, false);
	recalc()
	dpr = window.devicePixelRatio || 1;
	docEl.setAttribute('data-dpr', dpr);
	doc.addEventListener('DOMContentLoaded', recalc, false);
})(document, window);