var AccountWithdraw = function() {
	this.tips = $("#withdraw-errorMessage");
	this.fee = 0;
	this.isBindCard = 0; //已绑卡
	this.preData = {};
	return this;
}

AccountWithdraw.prototype = {
	init: function() {
		this.pageInit();
		this.bindEvent();

	},
	cons: function() {
		console.log(this.isBindCard);
	},
	pageInit: function() {
		var _this = this
		GHutils.load({ //前置验证
			url: "payment/trade/withdrawPreVerify",
			data: {},
			type: "post",
			callback: function(result) {
				_this.preData = result.data;
				if(result.code == 10000) { //已绑卡
					_this.isBindCard = 0;
					$('#hasCard').show()
					$('#noCard').hide()
					$(".mt16").show()
					$('#weihao').html(result.data.bankCardNo.substring(result.data.bankCardNo.length-4))
					$('#bankName').attr("src", result.data.bankBigLogo);
					$('#bank-limit').html(_this.limit(result.data.payDayLimit) + '每日/' + _this.limit(result.data.payMoonLimit) + '每月/' + _this.limit(result.data.payOneLimit) + '单笔');
					$('#withdraw-balance').html(GHutils.formatCurrency(result.data.cashBalance) + '元');
					$('.withdrawnum').html(result.data.monthlyFreeTimes);
					$('.tradeDateFee').html(result.data.withdrawFee); 
					if(result.data.feeType=="OLD"){
						if(result.data.maintainInfo) {
							$('.maintainInfo').html("温馨提示：" + result.data.maintainInfo);
						}
						$('.monthWithdrawCount').html(result.data.alreadyWithdrawTimes);
						if(result.data.alreadyWithdrawTimes - result.data.monthlyFreeTimes >= 0) {
							_this.fee = result.data.withdrawFee
						} else {
							_this.fee = 0
						}
						$('.withdrawnumfees').html(_this.fee)
					}else{
						$('.old-fee').hide();
						if(result.data.warmPrompts){
							$('.maintainInfo').html(result.data.warmPrompts);
						}
					}
					
					
					if(!result.data.valid&&result.data.validDesc) {
						GHutils.alert({
							text: result.data.validDesc,
							closeCallback: function() {
								history.go(-1)
							}
						});
						return false
					}
				} else {
					_this.isBindCard = 1;
					$('#hasCard').hide()
					$('#noCard').show()
					$(".mt16").hide()
				}
			}
		})
	},
	limit: function(num) {
		if(num == "0") {
			return '无限额'
		}
		return GHutils.formatCurrency(num) + '元'
	},
	bindEvent: function() {
		var _this = this
		$(".deposit_span2").click(function() {
			$(".deposit_span3").toggleClass("deposit_span2")
		})
		//点击全部提现
		$('#withdrawAll').on('click', function() {
			if(_this.isBindCard) { //没有绑卡
				$(_this.tips).html(GHutils.errorMessage('请绑定银行卡，再进行提现操作'))
				return false;
			}
			$('#withdraw-Money').val(_this.preData.cashBalance)
			$('#withdraw-Money').trigger("input")
			$('.rest').html(GHutils.formatCurrency(GHutils.Fsub(_this.preData.cashBalance, _this.fee)))
		})

		$('#withdraw-Money').on('focus', function() {
				$(document).on('keyup', function(e) {
					$('.rest').html('0.00')
					var money = $(this).val()
					if(money) {
						//正则表达式??????????????????????????????????//////
						if(money.match(/^(([1-9]\d*)|0)(\.\d{0,2})?$/g) || money.match(/^[1-9]\d*?$/g) || ('' + money).indexOf('.') == (money.length - 1)) {
							money = parseFloat(money)
						} else {
							$(_this.tips).html(GHutils.errorMessage('提现金额格式不正确'))
							return false;
						}
					}
					if(money > _this.fee) {
						$('.rest').html(GHutils.formatCurrency(GHutils.Fsub(money, _this.fee)))
					}
				}.bind(this))
			})
			.on('blur', function() {
				$(document).off('keyup')
			})
		$('#withdraw-Money').on('blur', function() {
			if(($('#withdraw-Money').val() - _this.preData.withdrawMinNew)<0) {
				$(_this.tips).html(GHutils.errorMessage('单笔提现金额最低' + (_this.preData.withdrawMinNew - 0).toFixed(2) + "元"))
				return false;
			}
		})
		$('#withdraw-Money').on('input', function() {
			console.log("进入",_this.timer);
			if(_this.timer)
	    		clearTimeout(_this.timer);
	    	if(_this.request)
	    		_this.request.abort()
			$('.withdrawnumfee').html("")
			$(_this.tips).html('')
			if($('#withdraw-Money').val()==""||$('#withdraw-Money').val()==0){
				return
			}
			console.log($('#withdraw-Money').val());
			if(parseFloat($('#withdraw-Money').val()) > _this.preData.withdrawMaxLimit) {
				$(_this.tips).html(GHutils.errorMessage('单笔提现金额不应大于' + (_this.preData.withdrawMaxLimit - 0).toFixed(2) + "元"))

				return false;
			}
			if(_this.isBindCard) { //没有绑卡
				$(_this.tips).html(GHutils.errorMessage('请绑定银行卡，再进行提现操作'))
				return false;
			}
			var data={
	            withdrawAmount:$('#withdraw-Money').val()
	        };
			if(_this.preData.feeType!="OLD"){
				$(".withdrawnumfee").html('<img src="static/images/xing.png">本次提现手续费<span class="withdrawnumfees">计算中</span>');
				
		    	_this.timer=setTimeout(function(){
		    		console.log("开始请求",_this.timer);
		    		_this.request=GHutils.load({
				        url: "/payment/trade/withdrawFee",
				        data: data,
				        type: "post",
				        callback: function(res) {
				            if (res.code == 10000&&data.withdrawAmount==$('#withdraw-Money').val()) {
				                $(".withdrawnumfee").html('<img src="static/images/xing.png">本次提现手续费<span class="withdrawnumfees">'+res.data.withdrawFee+'</span>元');
				            }else{
				            	$('.withdrawnumfee').html('<img src="static/images/xing.png">本次提现手续费<span class="withdrawnumfees">计算中</span>')
				            }
				        }
				    })
		    	},500);
		    	console.log("改变",_this.timer);
			}
		})
		//点击确认提现
		$('#gowithdraw').on('click', function() {

			if($(this).is('.submitting')) {
				return false;
			}
			$(_this.tips).html('')
			if(GHutils.validate('withdraw-box')) {

				if(parseFloat($('#withdraw-Money').val()) <= 0) {
					$(_this.tips).html(GHutils.errorMessage('提现金额应大于0元'))
					return false;
				}
				if(($('#withdraw-Money').val()-_this.preData.withdrawMinNew)<0) {
					$(_this.tips).html(GHutils.errorMessage('单笔提现金额最低' + (_this.preData.withdrawMinNew - 0).toFixed(2) + "元"))
					return false;
				}
				if(parseFloat($('#withdraw-Money').val()) > _this.preData.withdrawMaxLimit) {
					$(_this.tips).html(GHutils.errorMessage('单笔提现金额不应大于' + (_this.preData.withdrawMaxLimit - 0).toFixed(2) + "元"))
					return false;
				}
				if(_this.isBindCard) { //没有绑卡
					$(_this.tips).html(GHutils.errorMessage('请绑定银行卡，再进行提现操作'))
					return false;
				}
				

				if(!GHutils.userinfo.isPayPwd) {
					$('#setBankPwd').modal('show');
					GHutils.boxSwitch(".modalBox", "#setPayPwdBox");
				} else {
					// $('#gowithdraw').addClass('submitting')
					$('#modaldeywithdraw').modal('show')
					$('#deywithdrawMoney').html(GHutils.formatCurrency($('#withdraw-Money').val()))
					$("#deywithdrawFee").html(GHutils.formatCurrency(_this.fee))
					$("#deywithdrawFees").html(GHutils.formatCurrency(GHutils.Fsub($('#withdraw-Money').val(),_this.fee)))
				}
			}
		})

		$("#deybtn").on('click',function(){
			withdraw();
			$('#modaldeywithdraw').modal('hide')
		})
		$("#deybtns").on('click',function(){
			window.location.href = 'product-t0.html?withdrawMoney='+$('#withdraw-Money').val()
			$('#modaldeywithdraw').modal('hide')
		})
		function withdraw() {
			if(_this.preData.cashBalance < parseFloat($('#withdraw-Money').val())) {
				$('#gowithdraw').removeClass('submitting')
				$(_this.tips).html(GHutils.errorMessage('账户余额不足'))
				return false;
			}
			withd();
		}
		var withd = function(statu) {
			GHutils.load({
				url: "/payment/trade/withdraw",
				data: {
					withdrawAmount: $('#withdraw-Money').val(),
					fee: _this.fee,
					password: $('#payPwd').val()
				},
				type: "post",
				callback: function(result) {
					$('#gowithdraw').removeClass('submitting')
					if(result.code != 10000) {
						$(_this.tips).html(GHutils.errorMessage(result.message))
						return false;
					}
					var actualMoney = $('#withdraw-Money').val()-_this.fee ;
					window.location.href = 'result.html?action=withdraw&moneyVolume=' + $('#withdraw-Money').val()+"&actualMoney="+actualMoney+'&withdrawfee='+_this.fee
				},
				errcallback: function() {
					$('#gowithdraw').removeClass('submitting')
				}
			});
		}
	},
	callBackFun: function() {
		var _this = this
		_this.pageInit();
	}
}

$(function() {
	new AccountWithdraw().init();
	window.pageFun = new AccountWithdraw();
})