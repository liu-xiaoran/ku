var AccountDeposit = function () {
    this.tips = $("#deposit-errorMessages");
    this.btntime = null;
    this.orderNo = null;
    this.isBindCard = 0;
    this.data = null;
    this.lockData = {};
    this.realName = 0;
    return this;
}

AccountDeposit.prototype = {
    init: function () {
        this.pageInit();
        //将重置移动到接口返回数据之后
        this.bindEvent();
    },
    pageInit: function () {
        var _this = this

        GHutils.load({ //前置验证
            url: "/payment/trade/rechargePreVerify",
            data: {},
            type: "post",
            callback: function (result) {
                if (result.code == 10000) { //已绑卡
                    _this.isBindCard = 0;
                    _this.data = result.data;
                    $('#deposit-Moneys,#deposit-Money').attr('placeholder','单笔充值最低'+_this.data.rechargeMin+'元')
                    $('#hasCard').show()
                    $('#noCard').hide()
                    $('#weihao').html(result.data.bankCardNo.substring(result.data.bankCardNo.length - 4))
                    $('#bankName').attr("src", result.data.bankBigLogo);
                    $('#bank-limit').html(_this.limit(result.data.payOneLimit)+"/笔，"+_this.limit(result.data.payDayLimit)+"/日，"+_this.limit(result.data.payMoonLimit)+"/月");
                    if (!result.data.valid&&result.data.validDesc) {
                        GHutils.alert({
                            text: result.data.validDesc,
                            closeCallback: function () {
                                history.go(-1)
                            }
                        });
                        return false
                    }
                    if (result.data.maintainInfo) {
                        $('.maintainInfo').html("温馨提示：" + result.data.maintainInfo);
                    }
                } else {
                    _this.isBindCard = 1;
                    //判断有没实名
                    GHutils.load({
                        url: '/payment/account/bindBankCardPreVerify',
                        data: {},
                        type: 'post',
                        callback: function (result) {
                            if (result && result.data && result.data.realName && result.data.certNo) {
                                _this.realName = 1;
                            }
                        }
                    })
                    $('#hasCard').hide()
                    $('#noCard').show()
                }
                if (GHutils.parseUrlParam(location.href).method) {
                    $('#webpayOrderForm').trigger("click");
                }
            }
        })

    },
    limit: function (num) {
        if (num == "0") {
            return '无限额'
        }
        return GHutils.formatCurrency(num)
    },

    bindEvent: function () {
        var _this = this
        $('#deposit-Moneys').on("input", function () {
            if (_this.lockData.rechargeAmount && (_this.lockData.rechargeAmount != $(this).val())) {
                _this.lockData = {}
                _this.orderNo = ''
                //提示重新发送验证码
                $(_this.tips).html(GHutils.errorMessage('修改数据需要重新获取验证码'))
                $("#deposit_verifycode").removeClass("btn_loading");
                $("#verifycode").attr('valid', '{"required":true,"tipsbox":"#deposit-errorMessages","msg":"手机验证码","finalLength":6,"positiveInteger":true}');
                $("#payPwd").attr('valid', '{"required":true,"tipsbox":"#deposit-errorMessages","msg":"交易密码","payPassWord":true}');
                GHutils.clearBtnTime(_this.btntime, $("#deposit_verifycode"));
            }
        });

        //我已阅读并同意  前面那个复选框样式  
        $(".deposit_span2").click(function () {
            $(".deposit_span3").toggleClass("deposit_span2")
        })
        $('#deposit_verifycode').on('click', function () {
            if ($(this).is('.btn_loading')) {
                return false;
            }
            $('#verifycode').removeAttr('valid');
            $('#payPwd').removeAttr('valid');
            $(_this.tips).html('')

            if (_this.isBindCard) { //没有绑卡
                $(_this.tips).html(GHutils.errorMessage('请绑定银行卡，再进行充值操作'))
                return false;
            }
            if (_this.data.payOneLimit < parseFloat($('#deposit-Moneys').val())) {
                $(_this.tips).html(GHutils.errorMessage('金额不可超过银行卡单笔限额'))
                return false;
            }
            if ($('#deposit-Moneys').val() - _this.data.rechargeMin < 0) {
                $(_this.tips).html(GHutils.errorMessage('单笔充值最低2元'))
                return false;
            }
            $("#deposit_verifycode").addClass("btn_loading");
            // 充值页面获取验证码日志上报
            GHutils.writeLoad({
                data: {
                    evt: 'RechargeGetVeriCodeClick',
                    ext: {
                        "amount": $('#deposit-Moneys').val()
                    },
                    ret: ""
                }
            })
            // 充值发送验证码
            GHutils.load({
                url: "/payment/trade/validRecharge",
                data: {
                    "rechargeAmount": $('#deposit-Moneys').val()
                },
                type: "post",
                callback: function (result) {
                    if (result.code != 10000) {
                        $(_this.tips).html(GHutils.errorMessage(result.message))
                        return false;
                    }
                    _this.orderNo = result.data.orderNo
                    _this.btntime = GHutils.btnTime($("#deposit_verifycode"));
                    _this.lockData = {
                        rechargeAmount: $('#deposit-Moneys').val()
                    };
                },
                errcallback: function () {
                    $("#deposit_verifycode").removeClass("btn_loading");
                    $("#verifycode").attr('valid', '{"required":true,"tipsbox":"#deposit-errorMessages","msg":"手机验证码","finalLength":6,"positiveInteger":true}');
                    $("#payPwd").attr('valid', '{"required":true,"tipsbox":"#deposit-errorMessages","msg":"交易密码","payPassWord":true}');
                    if (_this.btntime) {
                        GHutils.clearBtnTime(_this.btntime, $("#deposit_verifycode"));
                    }
                }
            });
        })
        $('#goPayFast').on('click', function () {
            if ($(this).is('.btn_loading')) {
                return false;
            }
            $(_this.tips).html('')
            $("#verifycode").attr('valid', '{"required":true,"tipsbox":"#deposit-errorMessages","msg":"手机验证码","finalLength":6,"positiveInteger":true}');
            $("#payPwd").attr('valid', '{"required":true,"tipsbox":"#deposit-errorMessages","msg":"交易密码","payPassWord":true}');
            if (_this.isBindCard) { //没有绑卡
                $(_this.tips).html(GHutils.errorMessage('请绑定银行卡，再进行充值操作'))
                return false;
            }
            if (_this.data.payOneLimit < parseFloat($('#deposit-Moneys').val())) {
                $(_this.tips).html(GHutils.errorMessage('金额不可超过银行卡单笔限额'))
                return false;
            }
            if (!_this.orderNo) {
                $(_this.tips).html(GHutils.errorMessage('请先获取验证码，再进行充值操作'))
                return false;
            }
            if (!$('#payPwd').val()) {
                $(_this.tips).html(GHutils.errorMessage('请填写交易密码'))
                return false;
            }
            if (!GHutils.userinfo.isPayPwd) {
                $('#setBankPwd').modal('show');
                GHutils.boxSwitch(".modalBox", "#setPayPwdBox");
                return false;
            }
            $(this).addClass("btn_loading");
            // 点击充值日志上报
            GHutils.writeLoad({
                data: {
                    evt: 'RechargeConfirmClick',
                    ext: {
                        "oid": _this.orderNo,
                        'vericode': $('#verifycode').val()
                    },
                    ret: ""
                }
            })

            depositFast($(this));
        })

        //充值
        function depositFast(btnHander) {
            GHutils.load({
                url: "/payment/trade/recharge",
                data: {
                    orderNo: _this.orderNo,
                    securityCode: $('#verifycode').val(),
                    password: $('#payPwd').val()
                },
                type: "post",
                callback: function (result) {
                    btnHander.removeClass("btn_loading");
                    if (result.code != 10000) {
                        $(_this.tips).html(GHutils.errorMessage(result.message))
                        return false;
                    } else {
                        $("#depositFastModle").show();
                        $("#deposit-box").hide();
                        if (result.data.orderStatus == 'INIT' || result.data.orderStatus == 'PROCESSING') {
                            _this.ti = 5
                            _this.timerFast = setInterval(doneFast, 1000);
                        } else if (result.data.orderStatus == 'SUCCESS') {
                            $("#FastModleNow").html('<img style="display:inline-block;margin-bottom:36px;" src="static/images/czcgImg.png" />')
                            $("#FastModleEnd").html('<li class="f_cf60">您已充值成功<span style="font-size:22px;color:#ec9437;">' + GHutils.formatCurrency($('#deposit-Moneys').val()) + ' 元</span></li><li>您可以  <a href="account-deposit.html" class="f_cf60" style="font-size:18px;color:#ec9437;">继续充值</a> 或查看 <a href="/account-depositRecord.html" class="f_cf60" style="font-size:18px;color:#ec9437;">资金记录</a></li>')
                        } else if (result.data.orderStatus == 'FAILED') {
                            // 充值结果上报
                            GHutils.writeLoad({
                                data: {
                                    evt: 'RechargeResult',
                                    ext:result,
                                    ret: "fail"
                                }
                            })

                            $("#FastModleNow").html('<img style="display:inline-block;margin-bottom:36px;" src="static/images/chuo-img.png" />')
                            $("#FastModleEnd").html('<li>' + result.data.orderDesc + '，您可以 <a href="account-deposit.html" class="f_cf60" style="font-size:22px;color:#ec9437;">重新支付</a></li>')
                        }
                    }
                }
            });
        }
        // 2 解开注释
        //
        function doneFast() {
            _this.ti--;
            if (_this.ti <= 0) {
                clearInterval(_this.timerFast);
                $("#FastModleNow").html('充值正在处理')
                $("#FastModleEnd").html('<li class="f_cf60">充值成功将有短信提示</li><li>您可以 <a href="/account-depositRecord.html" style="font-size:18px;color:#ec9437;">查看资金记录</a></li>')
            }
            $("#FastModledw").html(_this.ti);
            GHutils.load({
                url: '/payment/trade/queryBankOrderByOrderNo',
                data: {
                    orderNo: _this.orderNo
                },
                type: "post",
                callback: function (result) {
                    if (result.code == 10000) {
                        if (result.data.orderStatus == 'INIT' || result.data.orderStatus == 'PROCESSING') { } else if (result.data.orderStatus == 'SUCCESS') {
                            clearInterval(_this.timerFast);
                            $("#FastModleNow").html('<img style="display:inline-block;margin-bottom:36px;" src="static/images/czcgImg.png" />')
                            $("#FastModleEnd").html('<li class="f_cf60">您已充值成功<span style="font-size:22px;color:#ec9437;">' + GHutils.formatCurrency($('#deposit-Moneys').val()) + ' 元</span></li><li>您可以  <a href="account-deposit.html" class="f_cf60" style="font-size:18px;color:#ec9437;">继续充值</a> 或查看 <a href="/account-depositRecord.html" class="f_cf60" style="font-size:18px;color:#ec9437;">资金记录</a></li>')
                        } else if (result.data.orderStatus == 'FAILED') {
                            clearInterval(_this.timerFast);
                            // 充值结果上报
                            GHutils.writeLoad({
                                data: {
                                    evt: 'RechargeResult',
                                    ext:result,
                                    ret: "fail"
                                }
                            })
                            $("#FastModleNow").html('充值失败')
                            $("#FastModleEnd").html('<li>支付失败？您可以 <a href="account-deposit.html" class="f_cf60" style="font-size:22px;color:#ec9437;">重新支付</a></li><li>失败原因？您可以 <a href="/account-depositRecord.html" class="f_cf60" style="font-size:22px;color:#ec9437;">查看资金记录</a></li>')
                        }
                    } else { //wait
                        // 充值结果上报
                        GHutils.writeLoad({
                            data: {
                                evt: 'RechargeResult',
                                ext: result,
                                ret: "fail"
                            }
                        })
                        clearInterval(_this.timerFast);
                        $("#FastModleNow").html('充值失败')
                        $("#FastModleEnd").html('<li>支付失败？您可以 <a href="account-deposit.html" class="f_cf60" style="font-size:22px;color:#ec9437;">重新支付</a></li><li>失败原因？您可以 <a href="/account-depositRecord.html" class="f_cf60" style="font-size:22px;color:#ec9437;">查看资金记录</a></li>')
                    }
                }
            })
        }

        //绑定点击选择支付方式
        $('.row00 .options2').on('click',function(){
            $(this).removeClass('row02').addClass('row02-active')
            $('.row00 .options3').removeClass('row03-active')

            $("#payShortcutForm").hide()
            $("#payOrderForm,.net-hander").show()
            $('#deposit-errorMessage').html('')
            $('.row01 .col2').html('网上银行支付')
            // if (_this.isBindCard && !_this.realName) {//没绑卡且没实名
            //     $('#getBanklist').trigger("click")
            //     return false
            // }
            //网银列表
            $(".blackcons").css("display", "inline-block");
            $(".blackcon").hide();
            $(".huizong_box").show();
        });
        $('.row00 .options3').on('click',function(){
            $(this).removeClass('row03').addClass('row03-active').addClass('row03')
            $('.row00 .options2').removeClass('row02-active').addClass('row02')
            $('.row01 .col2').html('银行卡快捷支付')
             $("#payOrderForm,.net-hander").hide()
            $("#payShortcutForm").show()
            $('#deposit-errorMessages').html('')

            //网银列表
            $(".blackcon").css("display", "inline-block");
            $(".blackcons").hide();
            $(".huizong_box").hide();
        });
        // $("#webpayOrderForm").on("click", function () {

        //     $(this).addClass("deposit_li3").find(".deposit_span").addClass("deposit_active").end().siblings().removeClass("deposit_li3").find(".deposit_span").removeClass("deposit_active")
        //     $("#payShortcutForm").hide()
        //     $("#payOrderForm").show()
        //     $('#deposit-errorMessage').html('')

        //     if (_this.isBindCard && !_this.realName) {//没绑卡且没实名
        //         $('#getBanklist').trigger("click")
        //         return false
        //     }
        // })
        // $("#payShortcut").on("click", function () {
        //     $(this).addClass("deposit_li3").find(".deposit_span").addClass("deposit_active").end().siblings().removeClass("deposit_li3").find(".deposit_span").removeClass("deposit_active")
        //     $("#payOrderForm").hide()
        //     $("#payShortcutForm").show()
        //     $('#deposit-errorMessages').html('')
        // })
        _this.gateWayBankList()
        $('#allBank').on('click', function () {
            if ($(".blackcon").css("display") == "none") {
                $(".blackcon").css("display", "inline-block");
                $(".blackcons").hide();
                $(".huizong_box").hide();
            } else {
                
                $(".blackcons").css("display", "inline-block");
                $(".blackcon").hide();
                $(".huizong_box").show();
            }
        })

        $('#goPay').on('click', function () {
            if (_this.isBindCard && !_this.realName) {
                $('#getBanklist').trigger("click")
                return false
            }
            if ($(this).is('.submitting')) {
                return false;
            }


            $('#deposit-errorMessage').html('')
            if (GHutils.validate('payOrderForm')) {
                if ($('#deposit-Money').val() && parseFloat($('#deposit-Money').val()) < 1) {
                    $('#deposit-errorMessage').html(GHutils.errorMessage('充值金额最少1元'))
                    return false;
                }
                // 网银充值上报
                GHutils.writeLoad({
                    data: {
                        evt: 'OnlineBankingRecharge',
                        ext: {
                            'amount': $('#deposit-Money').val()
                        },
                        ret: ""
                    }
                })

                _this.deposit('enable');
            }
        })

        $('#submit_get').on('click', function () {
            if ($(this).is('.submitting')) {
                $('#deposit-errorMessage').html(GHutils.errorMessage('请不要重复提交'))
                return false;
            }
            $(this).addClass('submitting')
            if (GHutils.validate('payOrderForm')) {
                if ($('#deposit-Money').val() && parseFloat($('#deposit-Money').val()) < 1) {
                    $('#deposit-errorMessage').html(GHutils.errorMessage('充值金额最少1元'))
                    $('#submit_get').removeClass('submitting')
                    return false;
                }
                $('#submit_get').removeClass('submitting')
                $("#depositModle").modal("show");
                var urls = returnUrl + '/result.html?action=deposit@' + parseFloat($('#deposit-Money').val())
                var uraParam = GHutils.parseUrlParam(window.location.href)
                $('#submit_get').attr('href', '/payment/onlineRecharge/onlineRechargeBaofoo?amount=' + parseFloat($('#deposit-Money').val()) + '&prodDetailUrl=' + urls + '&orderDesc=orderDesc&prodInfo=prodInfo&t=' + (new Date()).getTime())
                setTimeout(function () {
                    $('#submit_get').attr('href', 'javascript:;');
                }, 1000)
                // return false;
            } else {
                $('#submit_get').removeClass('submitting')
                return false;
            }
        })
    },

    deposit: function (statu) {
        if (statu == 'enable') {

            $('#payOrderForm').attr('action', "/payment/trade/onlineRecharge")
            $('#payOrderForm').append('<input name="returnUrl" value="' + returnUrl + 'product-result?action=deposit&moneyVolume=' + parseFloat($('#deposit-Moneys').val()) + '" type="hidden"/>')

            $('input[name=returnUrl]').remove()
            $('#deposit-errorMessages').removeClass('submitting')
        } else {
            $('#deposit-errorMessages').html(GHutils.errorMessage('您的账户不能执行充值操作'))
        }
    },

    callBackFun: function () {
        var _this = this
        _this.init()
    },
    gateWayBankList: function () {
        var _this = this
        GHutils.load({
            url: "/payment/agency/bank/gateWayBankList",
            data: {},
            type: "post",
            callback: function (result) {
                var htmls = '<tr><th>序号</th><th>支持银行</th><th>网关单笔最大限额(元)</th><th>网关单日最大限额(元)</th></tr>';
                for (var i in result.data.bankList) {
                    htmls += '<tr><td>' + (i - 0 + 1) + '</td><td>' + result.data.bankList[i].bankName + '</td><td>' + _this.limit(result.data.bankList[i].payOneLimit) + '</td><td>' + _this.limit(result.data.bankList[i].payDayLimit) + '</td></tr>'
                }
                $(".huizong_content").html(htmls);
            }
        });
    }
}

$(function () {
    new AccountDeposit().init();
    window.pageFun = new AccountDeposit();
})