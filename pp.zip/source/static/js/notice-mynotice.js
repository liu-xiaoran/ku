var Mynotice = function() {
	return this;
}

Mynotice.prototype = {
	init: function() {
		
	},
	
}

$(function() {
	new Mynotice().init();
})