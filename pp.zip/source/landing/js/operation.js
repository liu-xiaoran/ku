$(function() {
    function histogram(param) {
        var key = [];
        var value = [];
        if(param) {
            for(var i in param) {
                key.push(i);
                value.push(param[i]);
            }
        }
        var myChartOfPie = echarts.init(document.getElementById('columns'));
        option = {
            color: ['#3398DB'],
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                },
                formatter: '{b}：{c}%'
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'category',
                    data : key,
                    axisLabel: {
                        show: true,
                        textStyle: {
                            color: '#404040',
                            fontSize: '14'
                        }
                    },
                    axisLine: {
                        show: true,
                        lineStyle:{
                            color:'#dfe8fe'
                        }
                    },
                    axisTick: {
                        alignWithLabel: true
                    }
                }
            ],
            yAxis : [
                {
                    // type : 'category',
                    // data : ['10','20','30','40'],
                    axisTick: {
                        alignWithLabel: true
                    },
                    axisLine: {
                        show: true,
                        lineStyle:{
                            color:'#dfe8fe'
                        }
                    },
                    splitLine: {
                        show: true,
                        lineStyle: {
                            color: '#dfe8fe'
                        }
                    },
                    axisLabel: {
                        show: true,
                        interval: 'auto',
                        formatter: '{value} %',
                        textStyle: {
                            color: '#404040',
                            fontSize: '14'
                        }
                    },
                }
            ],
            series : [
                {
                    name:'直接访问',
                    type:'bar',
                    barWidth: '40%',
                    data: value
                }
            ],
            label: {
                normal: {
                    show: true,
                    position: 'top',
                    formatter: '{c}%'
                }
            },
            itemStyle: {
                normal: {
                    color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                        offset: 0,
                        color: 'rgba(255, 150,24, 1)'
                    }, {
                        offset: 1,
                        color: 'rgba(255, 192,118, 1)'
                    }]),
                    shadowColor: 'rgba(0, 0, 0, 0.1)',
                    shadowBlur: 10
                }
            }
        };
        myChartOfPie.setOption(option);
    }

    function pieChart(param) {
        var key = [];
        var value = [];
        if(param) {
            for (var i in param) {
                key.push(i);
                value.push({value: param[i], name: i});
            }
        }
        var myChartOfPies = echarts.init(document.getElementById('pieChart'));
        option = {
            backgroundColor: '#fff',
            tooltip: {
                trigger: 'item',
                formatter: "{b}：{d}%",
            },
            legend: {
                orient: 'vertical',
                x: 'right',
                y: '89',
                itemWidth: 15,
                itemHeight: 15,
                align: 'left',
                data: key,
                itemGap: 30,
                padding: [
                    20,  // 上
                    10, // 右
                    0,  // 下
                    10, // 左
                ],
                textStyle: {
                    color: '#404040',
                    fontSize: '18'
                }
            },
            series: [
                {
                    name:'访问来源',
                    type:'pie',
                    radius: ['45%', '71%'],
                    color: ['#2998ff', '#ff9315', '#00d692', '#a345f1'],
                    label: {
                        normal: {
                            formatter: '{d}%',
                            textStyle: {
                                fontSize: '22',
                                fontWeight: '600'
                            }
                        }
                    },
                    data: value
                }
            ]
        };
        myChartOfPies.setOption(option);
    }

    function map(param) {
        var html = '<ul class="chartTitle">' +
                    '<li>排名</li>' +
                    '<li>省份</li>' +
                    '<li>比例</li>' +
                    '</ul>';
        var key = 0
        if(param) {
            for (var i in param) {
                if(key < 10) {
                    key += 1;
                    html += '<ul class="chartCon">' +
                        '<li>' + key + '</li>' +
                        '<li>' + i + '</li>' +
                        '<li>' + param[i] + '%</li>' +
                        '</ul>';
                }
            }
            $("#cityList").html(html);
        }
        var myChart = echarts.init(document.getElementById('chart-panel'));

        var datas = [
            {name: '广东',value: 0 },
            {name: '北京',value: 0 },
            {name: '天津',value: 0 },
            {name: '上海',value: 0 },
            {name: '重庆',value: 0 },
            {name: '河北',value: 0 },
            {name: '河南',value: 0 },
            {name: '云南',value: 0 },
            {name: '辽宁',value: 0 },
            {name: '黑龙江',value: 0 },
            {name: '湖南',value: 0 },
            {name: '安徽',value: 0 },
            {name: '山东',value: 0 },
            {name: '新疆',value: 0 },
            {name: '江苏',value: 0 },
            {name: '浙江',value: 0 },
            {name: '江西',value: 0 },
            {name: '湖北',value: 0 },
            {name: '广西',value: 0 },
            {name: '甘肃',value: 0 },
            {name: '山西',value: 0 },
            {name: '内蒙古',value: 0 },
            {name: '陕西',value: 0 },
            {name: '吉林',value: 0 },
            {name: '福建',value: 0 },
            {name: '贵州',value: 0 },
            {name: '青海',value: 0 },
            {name: '西藏',value: 0 },
            {name: '四川',value: 0 },
            {name: '宁夏',value: 0 },
            {name: '海南',value: 0 },
            {name: '台湾',value: 0 },
            {name: '香港',value: 0 },
            {name: '澳门',value: 0 },
            {name: '南海诸岛',value: 0 }
        ];
        for(var i=0;i<datas.length;i++) {
            for(var j in param) {
                if(datas[i].name== j) {
                    datas[i].value = GHutils.Fmul(param[j],35)
                }
            }
        }
        // function randomData() {
        //     return Math.round(Math.random()*2500);
        // }
        option = {
            tooltip: {
                trigger: 'item',
                formatter: function(params) {
                    return params.name+'：'+ GHutils.Fdiv(params.value,35) +'%';
                }
            },
            visualMap: {
                seriesIndex: 0,
                min: 0,
                max: 2500,
                left: 'left',
                top: 'bottom',
                text: ['高','低'],           // 文本，默认为数值文本
                calculable: false,
                show: false,
                inRange: {
                    color: ['#bce1fa', '#2690e1'],
                }
            },
            grid: {
                height: 200,
                width: 8,
                right: 80,
                bottom: 10
            },
            xAxis: {
                type: 'category',
                data: [],
                splitNumber: 1,
                show: false
            },
            yAxis: {
                position: 'right',
                min: 0,
                max: 20,
                splitNumber: 20,
                inverse: true,
                axisLabel: {
                    show: true
                },
                axisLine: {
                    show: false
                },
                splitLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                data: []
            },
            series: [
                {
                    layoutCenter: ['50%', '50%'],
                    layoutSize: 650,
                    zlevel: 1,
                    name: '中国',
                    type: 'map',
                    mapType: 'china',
                    roam: false,
                    left: 0,
                    right: '15%',
                    label: {
                        normal: {
                            show: true,
                            color: '#004273'
                        },
                        emphasis: {
                            show: true,
                            color: '#004273'
                        }
                    },
                    itemStyle: {
                        normal: {
                            borderWidth: .5,//区域边框宽度
                            borderColor: '#fff',//区域边框颜色
                        },
                        emphasis: {
                            borderWidth: .5,
                            borderColor: '#fff',
                            areaColor:"#ffdead"
                        }
                    },
                    data: datas
                }
                // ,{
                //     zlevel: 2,
                //     name: '地图指示',
                //     type: 'bar',
                //     barWidth: 5,
                //     itemStyle: {
                //         normal: {
                //             color: undefined,
                //             shadowColor: 'rgba(0, 0, 0, 0.1)',
                //             shadowBlur: 10
                //         }
                //     },
                //     data: [20]
                // }
            ]
        };
        myChart.setOption(option)

        /**
         * 根据值获取线性渐变颜色
         * @param  {String} start 起始颜色
         * @param  {String} end   结束颜色
         * @param  {Number} max   最多分成多少分
         * @param  {Number} val   渐变取值
         * @return {String}       颜色
         */
        function getGradientColor (start, end, max, val) {
            var rgb = /#((?:[0-9]|[a-fA-F]){2})((?:[0-9]|[a-fA-F]){2})((?:[0-9]|[a-fA-F]){2})/;
            var sM = start.match(rgb);
            var eM = end.match(rgb);
            var err = '';
            max = max || 1
            val = val || 0
            if (sM === null) {
                err = 'start';
            }
            if (eM === null) {
                err = 'end';
            }
            if (err.length > 0) {
                throw new Error('Invalid ' + err + ' color format, required hex color');
            }
            var sR = parseInt(sM[1], 16),
                sG = parseInt(sM[2], 16),
                sB = parseInt(sM[3], 16);
            var eR = parseInt(eM[1], 16),
                eG = parseInt(eM[2], 16),
                eB = parseInt(eM[3], 16);
            var p = val / max;
            var gR = Math.round(sR + (eR - sR) * p).toString(16),
                gG = Math.round(sG + (eG - sG) * p).toString(16),
                gB = Math.round(sB + (eB - sB) * p).toString(16);
            return '#' + gR + gG + gB;
        }

        // setTimeout(function() {
        //     var TOPN = 25
        //
        //     var option = myChart.getOption()
        //     // 修改top
        //     option.grid[0].height = TOPN * 20
        //     option.yAxis[0].max = TOPN
        //     option.yAxis[0].splitNumber = TOPN
        //     option.series[1].data[0] = TOPN
        //     // 排序
        //     var data = option.series[0].data.sort(function(a, b) {
        //         return b.value - a.value
        //     })
        //
        //     var maxValue = data[0].value,
        //         minValue = data.length > TOPN ? data[TOPN - 1].value : data[data.length - 1].value
        //     var s = option.visualMap[0].controller.inRange.color[0],
        //         e = option.visualMap[0].controller.inRange.color.slice(-1)[0]
        //     var sColor = getGradientColor(s, e, maxValue, minValue)
        //     var eColor = getGradientColor(s, e, maxValue, maxValue)
        //
        //     option.series[1].itemStyle.normal.color = new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
        //         offset: 1,
        //         color: sColor
        //     }, {
        //         offset: 0,
        //         color: eColor
        //     }])
        //
        //     // yAxis
        //     var newYAxisArr = []
        //     echarts.util.each(data, function(item, i) {
        //         if (i >= TOPN) {
        //             return false
        //         }
        //         var c = getGradientColor(sColor, eColor, maxValue, item.value)
        //         newYAxisArr.push({
        //             value: item.name,
        //             textStyle: {
        //                 color: c
        //             }
        //         })
        //     })
        //     option.yAxis[0].data = newYAxisArr
        //     option.yAxis[0].axisLabel.formatter = (function(data) {
        //         return function(value, i) {
        //             if (!value) return ''
        //             return value + ' ' + data[i].value
        //         }
        //     })(data)
        //     myChart.setOption(option)
        // }, 0);
    }

    function constellation(param) {
        var pathSymbols = {
            xz1: 'image://images/xzImg1.png',
            xz2: 'image://images/xzImg2.png',
            xz3: 'image://images/xzImg3.png',
            xz4: 'image://images/xzImg4.png',
            xz5: 'image://images/xzImg5.png',
            xz6: 'image://images/xzImg6.png',
            xz7: 'image://images/xzImg7.png',
            xz8: 'image://images/xzImg8.png',
            xz9: 'image://images/xzImg9.png',
            xz10: 'image://images/xzImg10.png',
            xz11: 'image://images/xzImg11.png',
            xz12: 'image://images/xzImg12.png'
        };
        var dataList = ['白羊座', '金牛座', '双子座', '狮子座', '巨蟹座', '处女座', '天秤座', '天蝎座', '射手座', '魔羯座','水瓶座', '双鱼座'];
        var datas = [];
        var dataLists = [{
            value: 0.0000001,
            symbol: pathSymbols.xz1,
            symbolSize: [64, 60]
        }, {
            value: 0.0000001,
            symbol: pathSymbols.xz2,
            symbolSize: [62, 62]
        }, {
            value: 0.0000001,
            symbol: pathSymbols.xz3,
            symbolSize: [73, 51]
        }, {
            value: 0.0000001,
            symbol: pathSymbols.xz4,
            symbolSize: [66, 62]
        }, {
            value: 0.0000001,
            symbol: pathSymbols.xz5,
            symbolSize: [72, 64]
        }, {
            value: 0.0000001,
            symbol: pathSymbols.xz6,
            symbolSize: [55, 62]
        }, {
            value: 0.0000001,
            symbol: pathSymbols.xz7,
            symbolSize: [55, 64]
        }, {
            value: 0.0000001,
            symbol: pathSymbols.xz8,
            symbolSize: [68, 64]
        }, {
            value: 0.0000001,
            symbol: pathSymbols.xz9,
            symbolSize: [76, 59]
        }, {
            value: 0.0000001,
            symbol: pathSymbols.xz10,
            symbolSize: [74, 66]
        }, {
            value: 0.0000001,
            symbol: pathSymbols.xz11,
            symbolSize: [64, 65]
        }, {
            value: 0.0000001,
            symbol: pathSymbols.xz12,
            symbolSize: [100, 55]
        }];
        var dataed = [];
        var _min,_max,d;
        if(param) {
            for(var j = 0; j<dataList.length;j++) {
                var arr = [];
                for(var z in param) {
                    arr.push(param[z])
                }
                for(var i in param) {
                    if (dataList[j] == i) {
                        dataed.push(param[i]);//折线
                        datas.push(param[i]);//柱状
                        if(param[i] == 0) {
                            dataLists[j].value = 0.0000001
                        } else {
                            dataLists[j].value = param[i] || 0.0000001;//图片
                        }
                    }
                }
            }
            _min=Math.min.apply(null, dataed)
            _max=Math.max.apply(null, dataed)
            d = GHutils.Fsub(Math.max.apply(null, dataed),Math.min.apply(null, dataed))/12;

            for(var t=0,len=dataed.length;t<len;t++) {
                dataed[t] = d==0?GHutils.Fadd(parseFloat(dataed[t]),GHutils.Fmul(GHutils.Fdiv(_min,12),8)):GHutils.Fadd(parseFloat(dataed[t]),GHutils.Fmul(d,8))
            }
            // if(Math.max.apply(null, datas) > 50) {
            //     $("#constellation").css("height","400px");
            //     num = 55;
            // }
            // for(var j = 0; j<dataList.length;j++) {
            //     for(var i in param) {
            //         if(dataList[j] == i) {
            //             console.log(param[i],num,GHutils.Fmul(param[i],num))
            //
            //         }
            //     }
            // }
        }
        var myChart = echarts.init(document.getElementById('constellation'));
        option = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'none'
                },
                formatter: function (params) {
                    return params[0].name + '：' + params[0].value + '%';
                }
            },
            xAxis: {
                data: dataList,
                axisTick: {show: false},
                axisLine: {
                    show: true,
                    color: '#595959'
                },
                axisLabel: {
                    textStyle: {
                        color: '#404040'
                    }
                }
            },
            yAxis: {
                min: d==0?GHutils.Fdiv(_min,2):GHutils.Fsub(_min,d),
                max: d==0?GHutils.Fmul(_max,2):GHutils.Fadd(_max,GHutils.Fmul(d,7.9)),
                splitLine: {show: false},
                axisTick: {show: false},
                axisLine: {show: false},
                axisLabel: {show: false}
            },
            color: ['#e54035'],
            series: [{
                name: 'hill',
                type: 'pictorialBar',
                barCategoryGap: '-130%',
                symbol: 'image://images/line.png',
                symbolSize: [2,'100%'],
                itemStyle: {
                    normal: {
                        opacity: 0.5
                    },
                    emphasis: {
                        opacity: 1
                    }
                },
                data: datas,
                z: 10
            }, {
                name: 'glyph',
                type: 'pictorialBar',
                barGap: '-100%',
                symbolPosition: 'end',
                symbolSize: 50,
                symbolOffset: [0, '-120%'],
                data:dataLists
            }, {
                name: 'values',
                type: 'line',
                label: {
                    normal: {
                        show: true,
                        position: 'top',
                        formatter: function(params) {
                            return d==0?GHutils.Fsub(params.value,GHutils.Fmul(GHutils.Fdiv(_min,12),8)).toFixed(2) + '%':GHutils.Fsub(params.value,GHutils.Fmul(d,8)).toFixed(2) + '%';
                        },
                        textStyle: {
                            color: '#404040',
                            fontSize: '20'
                        }
                    }
                },
                lineStyle: {
                    normal: {
                        width: 1,
                        color: '#0d80ea'
                    }
                },
                itemStyle: {
                    normal: {
                        borderWidth: 3,
                        borderColor: '#ffdeb8',
                        color: '#ff9315'
                    },
                    emphasis: {
                        borderWidth: 3,
                        borderColor: '#ffdeb8',
                        color: '#ff9315'
                    }
                },
                data: dataed
            }]
        };
        myChart.setOption(option)
    }
    function pieList(param) {
        var value = [];
        if(param) {
            for (var i in param) {
                value.push({"name": i, "value": param[i]});
            }
        }
        var myChart = echarts.init(document.getElementById('pieList'));
        var colorData=['#54adff','#ff9415','#00d692','#99cd0b','#b253f5'];
        var colorDatas=['#a9d6ff','#ffc98a','#7feac8','#cce685','#d8a9fa'];
        var data = value;
        var create=function(data){
            var result = [];
            for(var i=0;i<data.length;i++){
                result.push({
                    name:'',
                    center: [(i * 20 + 10+ '%'),'35%'],
                    radius: ['40%','60%'],
                    type: 'pie',
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    markPoint: {
                        data: [{
                            symbol: 'triangle',
                            symbolSize: 15,
                            symbolRotate: 0,
                            itemStyle: {
                                normal: {
                                    color: 'transparent'
                                }
                            },
                            name: '',
                            tooltip: {
                                show: false
                            },
                            value: data[i].name,
                            x: myChart.getWidth() * (i + 0.5) / 5 - 12,
                            y: '80%',
                            label: {
                                normal: {
                                    show: true,
                                    position: 'center',
                                    formatter: function(params) {
                                        return params.value;
                                    },
                                    textStyle: {
                                        color: '#404040',
                                        fontSize: '24',
                                        fontWeight: 'normal'
                                    }
                                }
                            },
                        }]
                    },
                    data: [{
                        value: data[i].value,
                        name: data[i].name,
                        itemStyle: {
                            normal: {
                                color: colorData[i]
                            },
                            emphasis: {
                                color: colorData[i]
                            }
                        },
                        label: {
                            normal: {
                                formatter: '{d}%',
                                position: 'center',
                                show: true,
                                textStyle: {
                                    fontSize: '22',
                                    fontWeight: '600',
                                    color:colorData[i]
                                }
                            }
                        }
                    }, {
                        value: (100-data[i].value),
                        name: '',
                        tooltip: {
                            show: false
                        },
                        itemStyle: {
                            normal: {
                                color: colorDatas[i]
                            },
                            emphasis: {
                                color: colorDatas[i]
                            }
                        },
                        hoverAnimation: false
                    }]
                });
            }
            return result;
        };
        option = {
            tooltip: {
                trigger: 'item',
                formatter: "{b}：{d}%"
            },
            grid: {
                bottom: 100,
                top:150
            },
            xAxis: [{
                show: false
            }],
            yAxis: [{
                show: false
            }],
            series:create(data)
        };
        myChart.setOption(option)
    }
    function sexPieList(param) {
        var value = [];
        if(param) {
            for (var i in param) {
                if (i == '男') {
                    value.push({"icon": "image://images/sexImg1.png", "value": param[i]});
                } else if (i == '女') {
                    value.push({"icon": "image://images/sexImg2.png", "value": param[i]});
                }
            }
        }
        var myChart = echarts.init(document.getElementById('sexPieList'));
        var colorData=['#54adff','#ffa944'];
        var colorDatas=['#a9d6ff','#ffd4a1'];
        var data = value;
        var create=function(data){
            var result = [];
            for(var i=0;i<data.length;i++){
                result.push({
                    name:'',
                    center: [(i * 50 + 25+ '%'),'50%'],
                    radius: ['50%','76.5%'],
                    type: 'pie',
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    markPoint: {
                        data: [{
                            symbol: data[i].icon,
                            symbolSize: i==0?[35,33]:[31,29],
                            itemStyle: {
                                normal: {
                                    color: 'transparent'
                                }
                            },
                            tooltip: {
                                show: false
                            },
                            name: '',
                            value: '',
                            x: myChart.getWidth() * (i + 0.5) / 2,
                            y: '40%',
                            label: {
                                normal: {
                                    show: false
                                },
                                emphasis: {
                                    show: false
                                }
                            },
                        }]
                    },
                    data: [{
                        value: data[i].value,
                        name: '',
                        itemStyle: {
                            normal: {
                                color: colorData[i]
                            },
                            emphasis: {
                                color: colorData[i]
                            }
                        },
                        label: {
                            normal: {
                                formatter: '\n{d}%',
                                position: 'center',
                                show: true,
                                textStyle: {
                                    fontSize: '26',
                                    fontWeight: '600',
                                    color:colorData[i]
                                }
                            }
                        }
                    }, {
                        value: (100-data[i].value),
                        name: '',
                        tooltip: {
                            show: false
                        },
                        itemStyle: {
                            normal: {
                                color: colorDatas[i]
                            },
                            emphasis: {
                                color: colorDatas[i]
                            }
                        },
                        hoverAnimation: false
                    }]
                });
            }
            return result;
        };
        option = {
            tooltip: {
                trigger: 'item',
                formatter: function (params) {
                    if(params.color == '#54adff') {
                        return '男性：'+params.value+'%'
                    } else {
                        return '女性：'+params.value+'%'
                    }
                }
            },
            grid: {
                bottom: 100,
                top:150
            },
            xAxis: [{
                show: false
            }],
            yAxis: [{
                show: false
            }],
            series:create(data)
        };
        myChart.setOption(option)
    }
    document.title = '掌悦理财官网-运营报告-'+ GHutils.parseUrlParam(window.location.href).y + '年' + GHutils.parseUrlParam(window.location.href).m + '月';
    $('.years').html(GHutils.parseUrlParam(window.location.href).y);
    if(GHutils.parseUrlParam(window.location.href).m) {
        if(GHutils.parseUrlParam(window.location.href).m.toString().length == 1) {
            $('.monthscon').html('0'+GHutils.parseUrlParam(window.location.href).m);
        } else {
            $('.monthscon').html(GHutils.parseUrlParam(window.location.href).m);
        }
    }
    $('.months').html(parseInt(GHutils.parseUrlParam(window.location.href).m));
    var datas = {};
    if(GHutils.parseUrlParam(window.location.href).method&&GHutils.parseUrlParam(window.location.href).method=='pre') {
        datas = {
            ym: GHutils.parseUrlParam(window.location.href).y+GHutils.parseUrlParam(window.location.href).m,
            method: GHutils.parseUrlParam(window.location.href).method
        }
    } else {
        datas = {
            ym: GHutils.parseUrlParam(window.location.href).y+GHutils.parseUrlParam(window.location.href).m
        }
    }
    GHutils.load({
        url: "/actives1/Public/getOperationReport",
        data: datas,
        type: "post",
        callback: function(result) {
            if(result.code == 10000) {
                $("#regNum").html(GHutils.formatIntCurrency(result.data.regNum||0));
                $("#investNum").html(GHutils.formatIntCurrency(result.data.investNum||0));
                $("#investCount").html(GHutils.formatIntCurrency(result.data.investCount||0));
                $("#investMoney").html(GHutils.formatCurrency(GHutils.Fdiv(result.data.investMoney||0,10000)));
                // $("#currentRate").html(GHutils.formatCurrency(result.data.currentRate||0)+'%');
                // $("#regularRate").html(GHutils.formatCurrency(result.data.regularRate||0)+'%');
                var htmls = '<div class="circles"></div>';
                if(result.data.affair&&result.data.affair.length>0) {
                    for(var i = 0;i < result.data.affair.length;i++) {
                        htmls+= '<div class="line-incon"></div>' +
                            '<div class="circlecon">' +
                            '<div class="'+(i%2==0?"right-box":"left-box")+'">' +
                            '<p class="box-txt">'+result.data.affair[i].date.toString().split(".")[0]+'.<span>'+result.data.affair[i].date.toString().split(".")[1]+'</span></p>' +
                            '</div>' +
                            (i%2==0?'<div class="right-text">'+result.data.affair[i].content+'</div>':'<div class="left-text"><p>'+result.data.affair[i].content+'</p></div>') +
                            '</div>';
                    }
                    htmls += '<div class="line-incon line-incons"></div><div class="circles"></div>';
                    $("#lineIn").html(htmls);
                } else {
                    $("#ptdsj").hide();
                }
                var actImgLists = '';
                if(result.data.activity&&result.data.activity.length>0) {
                    for(var i = 0;i < result.data.activity.length;i++) {
                        actImgLists += '<li><img src="'+result.data.activity[i].img+'" /><div>'+result.data.activity[i].title+'</div></li>'
                    }
                    $("#actImgList").html(actImgLists);
                } else {
                    $("#yyhd").hide();
                }
                if(result.data.title) {
                    for(var i in result.data.title) {
                        document.getElementById(i).innerHTML = result.data.title[i].content
                    }
                }
                histogram(result.data.labels);
                pieChart(result.data.moneyProportion);
                map(result.data.provinceProportion);
                // result.data.constellationProportion = {
                //     "魔羯座": "0",
                //     "水瓶座": "11",
                //     "双鱼座": "12",
                //     "白羊座": "12",
                //     "金牛座": "12",
                //     "双子座": "12",
                //     "巨蟹座": "12",
                //     "狮子座": "12",
                //     "处女座": "12",
                //     "天秤座": "12",
                //     "天蝎座": "12",
                //     "射手座": "12"
                // }
                constellation(result.data.constellationProportion);
                pieList(result.data.ageProportion);
                sexPieList(result.data.genderProportion);
            } else if(result.code == 99998) {
                location.href = './operation-report.html';
            }
        }
    })
})