/**
 * author liu yanyun
 * 忘记密码
 */

var FindPwd = function() {
	this.tips1 = $("#find_pwd_tips1");
	this.tips2 = $("#find_pwd_tips2");
	return this;
}

FindPwd.prototype = {
	init: function() {
		this.bindEvent();
	},
	bindEvent: function() {
		var _this = this;
		//获取验证码
		$("#vericode_btn").click(function() {
			$(_this.tips1).html('&nbsp;');
			var userPhone = GHutils.trim($("#userPhoneNo").val());

			if($(this).hasClass("btn_loading")) {
				return
			}
			if(GHutils.validate("mobilePhone_div")) {
				_this.getPhoneCode(userPhone);
			}
			if($("#find_pwd_tips1").html() != "&nbsp;") {
				$(".find_pwd_tips1").show()
			} else {
				$(".find_pwd_tips1").hide()
			}
		});

		//第一步
		$('#findpwd_step1').on('click', function() {
			$(_this.tips1).html('&nbsp;');
			if(GHutils.validate("phoneCode_div")) {
                GHutils.load({
                    url: "/platform1/Userpub/checksms",
                    data: {
                        phone: GHutils.trim($("#userPhoneNo").val()),
                        smsType: "forgetlogin",
                        veriCode: GHutils.trim($("#verifyCodeNo").val())
                    },
                    type: "post",
                    callback: function(result) {
                        if(result.code == 10000) {
                            $("#step1").css("display", "none");
                            $("#step2").css("display", "block");
						} else {
                            $(_this.tips1).html(GHutils.errorMessage(result.message));
                            $(".find_pwd_tips1").show();
						}
                    }
                })
			}
			if($("#find_pwd_tips1").html() != "&nbsp;") {
				$(".find_pwd_tips1").show()
			} else {
				$(".find_pwd_tips1").hide()
			}
		});
		//第二步
		$('#findpwd_step2').on('click', function() {
			$(_this.tips2).html('&nbsp;');
			var pwd1 = GHutils.trim($('#password1').val());
			var pwd2 = GHutils.trim($('#password2').val());
			if(GHutils.validate("newPwd_box")) {
				_this.setNewPwd(pwd1, pwd2);
			}
			if($("#find_pwd_tips2").html() != "&nbsp;") {
				$(".find_pwd_tips2").show()
			} else {
				$(".find_pwd_tips2").hide()
			}
		})
		$('#find_pwd_succes').on('click', function() {
			GHutils.load({
				url: "/platform1/Userpub/logout",
                data: {
                    platform: "pc"
                },
				type: "post",
				callback: function(result) {
                    GHutils.setCookie('headerinfo', '');
                    GHutils.userinfo = null;
					// $('#loginStatus').hide();
					// $('#notLogin').show()
                    window.location.href = "regandlog.html?type=log";
				}
			})
		})
	},
	getPhoneCode: function(userPhone) {
		var _this = this;
		_this.getVerifyCode(userPhone);
	},
	
	getVerifyCode: function(val) {
		var _this = this;
		$(_this.tips1).html('&nbsp;');
		var userPhone = val;
		var btntime = null;
		$("#vericode_btn").addClass("btn_loading");
		GHutils.load({
			url: "/platform1/Userpub/sendsms",
			data: {
				phone: userPhone,
				smsType: "forgetlogin"
			},
			type: "post",
			callback: function(result) {
				if(result.code == 10000||result.code == 99995) {
                    btntime = GHutils.btnTime($("#vericode_btn"),(result.data.ttl||120));
				}
				if(result.code != 10000) {
					$(_this.tips1).html(GHutils.errorMessage(result.message));
					$("#vericode_btn").removeClass("btn_loading");
					$(".find_pwd_tips1").show()
					return false;
				}
				$(".find_pwd_tips1").hide()
			},
			errcallback: function() {
				$("#vericode_btn").removeClass("btn_loading");
				if(btntime) {
					GHutils.clearBtnTime(btntime, $("#vericode_btn"));
				}
			}
		});
	},
	setNewPwd: function(pwd1, pwd2) {
		var _this = this;
		$("#findpwd_step2").addClass("btn_loading");
		GHutils.load({
			url: "/platform1/userpub/forgetpwd",
			data: {
				phone: GHutils.trim($("#userPhoneNo").val()),
				newPwd: pwd1,
				newPwd2: pwd2,
				veriCode: GHutils.trim($("#verifyCodeNo").val())
			},
			type: "post",
			callback: function(result) {
				if(result.code == 10000) {
					$('#step2').css('display', 'none');
					$('#step3').css('display', 'block');
					$(".find_pwd_tips2").hide()
				} else {
					$(".find_pwd_tips2").show()
					$(_this.tips2).html(GHutils.errorMessage(result.message));
				}
				$("#findpwd_step2").removeClass("btn_loading");
			},
			errcallback: function() {
				$("#findpwd_step2").removeClass("btn_loading");
			}
		})
	}
}

$(function() {
	new FindPwd().init();
})