var ZYWechat = require('./lib/wechat');
export {ZYWechat}