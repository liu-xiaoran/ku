<template>
  <div class="edit">
    <p class="account">正在下载APP</p>
    <!-- <input type="text" class="inp" placeholder="请输入手机号"> -->
    <!-- <img src="../../assets/edit.png" class="goapp" @click="editphone"> -->
    <!-- <p class="tishi">手机号修改后将在下次抢红包时生效</p> -->
    <img src="../../assets/goapp.png" class="goapp" @click="goapp" />
    <div class="tishi" v-show="showtishi">
      <div class="shade" @click="closeshade">
        <img class="jiantou" src="../../assets/arrow.png" />
        <ul class="dianji">
          <li>1.点击右上角的按钮</li>
          <li>2.选择在浏览器中打开</li>
          <li>3.下载掌悦理财APP</li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import router from '../../router'
export default {
  name: 'edit',
  data() {
    return {
      phone: "",
      showtishi:false,
      channelid: '999920170828234606'
    }
  },
  methods: {
    goapp() {
      //判断设备类型和浏览器环境
      function ue() {
        var e = navigator.userAgent.toLowerCase();
        return {
          iphone: /iphone/.test(e),
          android: /android/.test(e),
          winphone: /windows phone/.test(e),
          weixin: /micromessenger/.test(e),
          qqnews: /qqnews/.test(e),
          mqqbrowser: /mqqbrowser/.test(e),
          qq: /\sqq/.test(e)
        }
      }
      //下载app
      if (ue().weixin == true) {
        this.showtishi = true;
        document.getElementById("html").className = 'ovfHiden'
      } else {
        if (ue().iphone == true) {
          location.href = 'https://itunes.apple.com/app/id1203692435';
        } else if (ue().android == true) {
          var _url = this.channelid.substr(0, 12) + "4" + this.channelid.substring(13);
          location.href = '/app/' + _url + '.apk';
        }
      }
    },
    closeshade() {
      var timers = null;
      document.getElementById("html").className = ''
      this.showtishi = false;
    },
  },
  created() {
    function ue() {
        var e = navigator.userAgent.toLowerCase();
        return {
          iphone: /iphone/.test(e),
          android: /android/.test(e),
          winphone: /windows phone/.test(e),
          weixin: /micromessenger/.test(e),
          qqnews: /qqnews/.test(e),
          mqqbrowser: /mqqbrowser/.test(e),
          qq: /\sqq/.test(e)
        }
      }
      //下载app
      if (ue().weixin == true) {
        this.showtishi = true;
        document.getElementById("html").className = 'ovfHiden'
      } else {
        if (ue().iphone == true) {
          location.href = 'https://itunes.apple.com/app/id1203692435';
        } else if (ue().android == true) {
          var _url = this.channelid.substr(0, 12) + "4" + this.channelid.substring(13);
          location.href = '/app/' + _url + '.apk';
        }
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='scss'>
@import "../../style/utils.scss";
.edit {
  position: relative;
  text-align: center;
}

.account {
  padding-top: 1.3333rem;
  padding-bottom: 0.7333rem;
  color: #fee9b7;
  @include font-dpr(16px);
}

.inp {
  width: 7.1467rem;
  height: 1.2rem;
  border-radius: 0.1867rem;
  background: #ffffff;
  color: #a98dcc;
  text-align: center;
  margin-bottom: 0.8267rem;
  @include font-dpr(14px);
}

.edit .goapp {
  width: 7.1467rem;
  margin: 0 auto;
  padding-bottom: 0.4267rem;
}
.tishi {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 100;
}

.shade {
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, .7);
}

.jiantou {
  width: 4.9rem;
  height: 4.84rem;
  position: absolute;
  top: .4rem;
  right: .41rem;
}

.dianji {
  // padding: 5.66rem 0 0 2.25rem;
  padding-top: 5.66rem;
  margin: 0 auto;
}

.dianji li {
  color: #fff;
  @include font-dpr(20px);
  margin-bottom: 2.05rem;
}
</style>
