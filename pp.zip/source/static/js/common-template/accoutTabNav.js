define([],
function() {
  return {
  	name: 'accoutTabNav',
    init:function(){
      this.pageInit();
    },
    pageInit:function(){
      var _this = this;
      var onnav = $("#tabnav-box").attr("data-navname");
      if(onnav){      	
	      $("#"+onnav).addClass("active").attr("href","javascript:;");
      }
    }
  }
})
