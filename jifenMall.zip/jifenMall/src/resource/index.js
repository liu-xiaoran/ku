import Vue from 'vue'
import Resource from 'vue-resource'


Vue.use(Resource)

