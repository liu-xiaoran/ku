var AccountRecord = function() {
	return this;
}

AccountRecord.prototype =  {
	init: function() {
        this.param = {
            productType: "",
            startTime: "",
            endTime: "",
            orderType: "",
            pageInfo: {
                pageSize: 7,
                pageNo: 1
            }
        }
		this.pageInit();
		this.bindEvent();
	},
	pageInit: function() {
    var _this = this
		_this.getRecord(_this.param)
	},
	ProcessDate: function(num) {   
		var currentTime = new Date(); //得到当前的时间
		var currentYear = currentTime.getFullYear(); //得到当前的年份
		var currentMoon = currentTime.getMonth(); //得到当前的月份
		var currentDay = currentTime.getDate(); //得到当前的天数
		//2.0获取当前时间的一个月内的年月日：（一个月内的大众业务需求为：当前时间的月份-1，当前时间的天数+1）
		var agoDay = currentDay ;   
		var agoMoon = currentMoon;   
		var agoYear = currentYear;   
		var max = "";
		agoMoon = currentMoon - num;
		max = new Date(agoYear, agoMoon+1, 0).getDate(); //获取上个月的总天数 
		if(agoDay > max) {    
			agoDay = max;   
		}    //如果月份当月为1月的时候， 那么一个月内： 年：-1 月：12 日：依然不变  
		if(agoMoon < 0) {    
			agoMoon = 12 + agoMoon;
			agoYear = currentYear - 1;   
		}
		function Appendzero(obj) {   
			if(obj < 10) {    
				return "0" + obj;   
			} else {    
				return obj;   
			}  
		}
		currentMoon = Appendzero(currentMoon);
		currentDay = Appendzero(currentDay);
		agoMoon = Appendzero(agoMoon + 1);
		agoDay = Appendzero(agoDay);
		var pretimes = agoYear + "-" + agoMoon + "-" + agoDay
		return pretimes  
	},
	getRecord:function(param){
		var _this = this
		var getRecord = function(){
			GHutils.load({
				url: "/zybusiness/user/myTrad/pc",
				data: param,
				type: "post",
				callback: function(result) {
					if(result.code !=10000){
						return false;
					}
					if(result.data.list) {
                        $('#noReCord').addClass('none')
                        $('#hadRecord').removeClass('none')
					} else {
                        $('#hadRecord').addClass('none')
                        $('#noReCord').removeClass('none')
					}
					var records = '';
					GHutils.forEach(result.data.list,function(idx,record){
						records+= '<ul class="container-fluid-content"><li>'+record.productInfo.productName+'</li><li>'+GHutils.formatCurrency(record.orderAmount)+'元</li><li>'+record.orderTypeCh+'</li><li style="color:#ec9437;">'+record.orderStatusCh+'</li><li>'+GHutils.formatTimestamp({time:record.createTime,showtime:"true"})+'</li><li>'+record.orderNo+'</li></ul>'
					})
                    $('#tradeRecord').html(records)
                    _this.createPage(Math.ceil(result.data.pageInfo.totalSize/7),param.pageInfo.pageNo)
				}
			})
		}()
	},
	bindEvent:function() {
		var _this = this;
		$('#productOptions li a').on('click',function(){
			if($(this).attr('class') == 'active'){
				return false;
			}
			$('#productOptions').find('a').removeClass('active')
			$(this).addClass('active')
            _this.param.productType =  $(this).attr('data-proType')
			$('#moreRecord').attr('data-page',1)
            _this.param.pageInfo.pageNo=1
			parseParam(_this.param)
		})
		
		$('#timeTypeOptions li a').on('click',function(){
			if($(this).attr('class') == 'active'){
				return false;
			}
			$('#timeTypeOptions').find('a').removeClass('active')
			// if($(this).attr('data-timeType')) {
				$(this).addClass('active')
			// } else {
			// 	$('.quanbu').addClass('active')
			// }
			if($(this).attr('data-timeType')) {
                _this.param.startTime =  _this.ProcessDate($(this).attr('data-timeType'))
                _this.param.endTime = new Date().getFullYear() + "-" + (new Date().getMonth()*1+1).toString() + "-" + new Date().getDate()
			} else {
                _this.param.startTime = '';
                _this.param.endTime = '';
			}
			$('#moreRecord').attr('data-page',1)
            _this.param.pageInfo.pageNo=1
			parseParam(_this.param)
		})
		
		$('#orderTypeOptions li a').on('click',function(){
			if($(this).attr('class') == 'active'){
				return false;
			}
			$('#orderTypeOptions').find('a').removeClass('active')
			$(this).addClass('active')
			var orderType = $(this).attr('data-tradetype')
			$('#moreRecord').attr('data-page',1)
            _this.param.pageInfo.pageNo=1
            _this.param.orderType = orderType
			parseParam(_this.param)
		})
		
		$('#moreRecord').on('click',function(){
			if($(this).is('.active')){
				return false;
			}
            _this.param.pageInfo.pageNo = parseInt($(this).attr('data-page'))+1
			$(this).attr('data-page',_this.param.pageInfo.pageNo)
			parseParam(_this.param)
		})
		
		$('#orderTimeBegin').on('dp.change',function(){
			if(_this.param.startTime == $(this).val()){
		 		return
		 	}
			$('#moreRecord').attr('data-page',1)
            _this.param.pageInfo.pageNo=1
			var endTime = $('#orderTimeEnd').val()
			var startTime =  $(this).val()
            _this.param.startTime = startTime
			if(endTime && startTime){
				if(new Date(startTime).getTime() > new Date(endTime).getTime()){
					$('#orderTimeEnd').val('')
                    _this.param.endTime = ''
				}
			}
			$(this).removeClass('change')
			parseParam(_this.param)
		})
		
		//选择结束时间
		$('#orderTimeEnd').on('dp.change',function(){
			if(_this.param.endTime == $(this).val()){
		 		return
		 	}
			$('#moreRecord').attr('data-page',1)
            _this.param.pageInfo.pageNo=1
			var  startTime = $('#orderTimeBegin').val()
			var endTime=  $(this).val()
            _this.param.endTime = endTime == null || endTime == ''? endTime: GHutils.addDate(endTime,1)
			if(endTime && startTime){
				if(new Date(startTime).getTime() > new Date(endTime).getTime()){
					$('#orderTimeEnd').val('')
                    _this.param.endTime = ''
				}
			}
			parseParam(_this.param)
		})
		function parseParam(param){
			_this.getRecord(param)
		}
	},
    createPage: function(pageCount,current) {
        $(".tcdPageCode").show()
        if(pageCount <= 1) {
            $(".tcdPageCode").hide()
        }
        var _this = this;
        $(".tcdPageCode").createPage({
            pageCount: pageCount,
            current: current,
            backFn: function(page) {
                _this.param.pageInfo.pageNo = page;
                _this.getRecord(_this.param);
            }
        });
    }
}

$(function() {
	new AccountRecord().init();
})
		