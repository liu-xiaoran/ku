var ProductRedeem = function() {
	this.tips1 = $("#modify_pay_tips");
	return this;
}

ProductRedeem.prototype = {
	init: function() {
		this.pageInit();
		this.bindEvent();
		this.timer=""
		this.formKey=""
		var hasPayPwd = false
		var currencyFee, factorage, limitData;
	},
	checkFactorage: function(money) {
		_this = this
		if(_this.timer)
    		clearTimeout(_this.timer);
    	if(_this.request)
    		_this.request.abort()
    	
		_this.formKey=""
		$(".factorage").html("")
		$('#ok_pay').removeClass("app_btn_loading")
		if(!money || parseFloat(money) <= 0) {
			return;
		};

		$('#buyProduct').html('')
		if(money > _this.limitData.maxRedeemAmount) { //2.不可超过剩余可转让金额
			$('#buyProduct').html(GHutils.errorMessage('不可超过剩余可转让金额'))
			$('#ok_pay').addClass("app_btn_loading")
			return false;
		} else if(money < _this.limitData.minSingleRedeemAmount) { //3.不可小于最低可转让金额
			$('#buyProduct').html(GHutils.errorMessage('不可小于最低可转让金额' + _this.limitData.minSingleRedeemAmount + '元'))
			$('#ok_pay').addClass("app_btn_loading")
			return false;
		} else if(GHutils.Fdiv(GHutils.Fsub(money, _this.limitData.minSingleRedeemAmount), _this.limitData.increaseRedeemAmount).toString().indexOf('.') > 0) { //4.转让金额必须为最低金额+递增金额的整数倍
			$('#buyProduct').html(GHutils.errorMessage('转让金额必须为最低金额' + _this.limitData.minSingleRedeemAmount + '元+递增金额' + _this.limitData.increaseRedeemAmount + '元的整数倍'))
			$('#ok_pay').addClass("app_btn_loading")
			return false;
		} 
		// else if(money > _this.limitData.dayRemainAmount) {
		// 	$('#buyProduct').html(GHutils.errorMessage('本日累计转让金额不可超过本日转让上限'))
		// 	$('#ok_pay').addClass("app_btn_loading")
		// 	return false;
		// }
		$('#ok_pay').removeClass("app_btn_loading")
		_this.formKey=(new Date()).getTime()
		$(".factorage").html("本次转让手续费<span>计算中</span>");
		
    	_this.timer=setTimeout(function(){
    		_this.request=GHutils.load({
		        url: "/assignTrans/order/redeem/getFee",
		        data: {
		            "formKey": _this.formKey,
				    "orderAmount": money,
				    "feeType": _this.limitData.feeType,
				    "feeAmount": _this.limitData.feeAmount,
				    "minFee": _this.limitData.minFee,
				    "freeAmount": _this.limitData.freeAmount,
				    "principal": _this.limitData.principal,
				    "holdAmount": _this.limitData.holdAmount
		        },
		        type: "post",
		        callback: function(res) {
		            if (res.code == 10000) {
		                if (res.data.formKey == _this.formKey) {
		                    $(".factorage").html("本次转让手续费<span>" + res.data.fee + "元</span> 实际到账金额<span>" + GHutils.formatCurrency(GHutils.Fsub(money,res.data.fee)) + "元</span>");
		                } else {
		                    $(".factorage").html("本次转让手续费<span>计算中</span>");
		                }
		            }
		        }
		    })
    	},500);
		
	},
	pageInit: function() {
		var _this = this
		var uraParam = GHutils.parseUrlParam(window.location.href)
		// 转让前置接口
		GHutils.load({
			url: "/assignTrans/order/transfer/prepose",
			data: {
				"productId": uraParam.productOid
			},
			type: "post",
			loginStatus: function(resp) {
				GHutils.loginOut(true)
			},
			callback: function(result) {
				if(result.code != 10000) {
					$('#buyProduct').html(GHutils.errorMessage(result.message))
					return false;
				}
				var resultData = result.data
				if(resultData.maxSingleDayRedeemAmount == 0) {
					resultData.dayRemainAmount = resultData.maxRedeemAmount - 0 + 100000 // 如果单日转让金额上限无限额，则单日剩余可转让金额必为0
				}
				_this.limitData = resultData
				// 解锁输入框
				setTimeout(function() {
					$(".from_input_spwd").removeAttr("disabled");
				}, 500)
				// 添加提示 
				// $('#redeemAmount').html(GHutils.formatCurrency(Math.min(resultData.dayRemainAmount, resultData.remainAmount)))
				$('#redeemAmount').html(GHutils.formatCurrency(resultData.maxRedeemAmount))
				// resultData.increaseRedeemAmount ? $("#pc_minAddRredeem").html(GHutils.formatCurrency(resultData.increaseRedeemAmount)) : $("#pc_minAddRredeem").html('0.01')
				resultData.minSingleRedeemAmount ? $("#pc_minRredeem").html(GHutils.formatCurrency(resultData.minSingleRedeemAmount) + '元') : $("#pc_minRredeem").html('无限制')
				resultData.maxSingleDayRedeemAmount ? $("#pc_maxRredeem").html(GHutils.formatCurrency(resultData.maxSingleDayRedeemAmount) + '元') : $("#pc_maxRredeem").html('无限制')
				//债权改动
				// $(".pc_limitDay").html(resultData.limitDay)
				// $("#pc_limitDayTypsCh").html(resultData.pc_limitDayTypsCh)
				// $("#pc_factorage").html(resultData.feeType == 'AMOUNT' ? resultData.feeAmount + "元" : resultData.feeAmount + "%")
				// 点击全部转让
				$('#redeemAll').on('click', function() {
					// $('#redeemMoney').val(Math.min(resultData.dayRemainAmount, resultData.remainAmount))
					$('#redeemMoney').val(resultData.maxRedeemAmount)  //转让不控
					$('#redeemMoney').trigger("input")
				})
			}
		});

	},
	bindEvent: function() {
		var _this = this
		//用户改变转让金额
		$("#redeemMoney").on("input", function() {
			console.log("change");
			_this.checkFactorage($(this).val());
		});
		function hasOrNot(param) {
			if(typeof(param) == "undefined") param = '暂无'
			return param
		}
		$('#inputPayPwd').on('blur', function() {
			$('#ok_pay').removeClass("app_btn_loading")
		})
		//点击确认支付
		$('#ok_pay').on('click', function() {
			$(".from_input_spwd").attr("disabled");
			// 转让相关验证
			var redeemMoney = Number($('#redeemMoney').val())
			if(!redeemMoney) {
				$('#buyProduct').html(GHutils.errorMessage('转让金额不能为 0 或空'))
				return false
			}
			if($(this).hasClass("app_btn_loading")) {
				return
			}
			$('#ok_pay').addClass("app_btn_loading")
			redeemProduct()
		})

		//转让
		function redeemProduct() {
			var productOid = GHutils.parseUrlParam(window.location.href).productOid,
				orderAmount = Number($('#redeemMoney').val());
			GHutils.load({
				url: "/assignTrans/order/transfer",
				data: {
					productId: productOid,
					orderAmount: orderAmount,
					redeemType: 'FASTREDEEM',
					payPasswd: Number($('#inputPayPwd').val()),
					fee: _this._factorage||0
				},
				type: "post",
				loginStatus: function(resp) {
					$('#buyProduct').html(GHutils.errorMessage(resp.errorMessage))
				},
				callback: function(result) {
					$('#ok_pay').removeClass("app_btn_loading")
					if(result.code != 10000) {
						$('#buyProduct').html(GHutils.errorMessage(result.errorMessage || result.message))
						return false;
					}
					//转让成功
					window.location.href = 'result.html?type=redeem&money=' + GHutils.formatCurrency(orderAmount)+"&fee="+_this._factorage
					
				},
				errcallback: function() {
					$('#ok_pay').removeClass("app_btn_loading")
				}
			})
		}

	},
	callBackFun: function() {
		var _this = this
		_this.pageInit();
	},
}

$(function() {
	new ProductRedeem().init();
	window.pageFun = new ProductRedeem();
})