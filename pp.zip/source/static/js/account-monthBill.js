var AccountMonthBill = function () {
	return this;
}

AccountMonthBill.prototype = {
	init: function () {
        this.selectMouth = true;
		this.pageInit();
		this.bindEvent();
	},
	pageInit: function () {
        var _this = this
        _this.getBillDate("")
    },
    getBillDate: function(param){
        var _this = this
        var param = {
            month:param
        }
        var getDate = function(){
            GHutils.load({
				url: "/payment/account/month/bill",
				data: param,
				type: "post",
				callback: function (result) {
					if(result.code == 10001){
						window.location.href = '/index.html';
						return false
                    }
                    if(result.code == 10000){
						var datas = result.data
						_this.initChart(result.data)
                        if(_this.selectMouth){
                            _this.getListDate(datas.billMonth)
                            _this.selectMouth = false
                        }
                        $("#totalAsset").html(GHutils.formatCurrency(datas.totalAsset))
                        $("#totalAssets").html(GHutils.formatCurrency(datas.totalAsset))
                        $("#tatalIncomoe").html(GHutils.formatCurrency(datas.monthlyIncome))
                        $("#part_t0CapitalAmount").html(GHutils.formatCurrency(datas.currentAsset)+"元")
                        $("#part_tnCapitalAmount").html(GHutils.formatCurrency(datas.regularAsset)+"元")
                        $("#part_balance").html(GHutils.formatCurrency(datas.cashBalance)+"元")
                        $("#part_onWayBalance").html(GHutils.formatCurrency(datas.frozenBalance)+"元")
                        $("#rechargeAmount").html(GHutils.formatCurrency(datas.rechargeAmount))  //充值金额
                        $("#withdrawAmount").html(GHutils.formatCurrency(datas.withdrawAmount))
                        $("#investAmount ").html(GHutils.formatCurrency(datas.investAmount))
                        $("#transferApply").html(GHutils.formatCurrency(datas.transferApply))
                        $("#withdrawFee").html(GHutils.formatCurrency(datas.withdrawFee))
                        $("#gainPoint").html(datas.gainPoint||0)
                        $("#usedPoint").html(datas.usedPoint||0)
                        $("#currentIncome").html(GHutils.formatCurrency(datas.currentIncome))
                        $("#regularIncome").html(GHutils.formatCurrency(datas.regularIncome))
                        $("#voucherIncome").html(GHutils.formatCurrency(datas.voucherIncome)) 
                    }
				}
			})
        }()
    },
    getListDate: function(billMonth){
        var _this = this
        var getDate = function(){
            GHutils.load({
				url: "/payment/account/bill/month/list",
				data: {},
				type: "post",
				callback: function (result) {
					if(result.code == 10001){
						window.location.href = '/index.html';
						return false
                    }
                    // active
                    if(result.code == 10000){
                        var billMonthList = result.data.billMonthList,listHtml=""
                        GHutils.forEach(billMonthList, function (idx, billMonthList) {
                            if(billMonthList.month==billMonth){
                                listHtml += '<a href="javascript:;" class="col-xs-3 active" data-month='+billMonthList.month+'>'+billMonthList.monthName+'</a>'
                            }else{
                                listHtml += '<a href="javascript:;" class="col-xs-3" data-month='+billMonthList.month+'>'+billMonthList.monthName+'</a>'
                            }
                        })
                        $("#monthOptions").html(listHtml)
                    }
				}
			})
        }()
    },
    initChart: function(result){
        var _this = this
        var result = result||{}
        initChart(result)
        //初始化chart，
		function initChart(result) {
			var subtext = GHutils.formatCurrency(result.totalAsset)
			// 基于准备好的dom，初始化echarts实例
			_this.myChartOfPie = echarts.init(document.getElementById('assetPartsPie'));
			option = {
				tooltip: {
					trigger: 'item',
					formatter: "{a} <br/>{b}: {c} ({d}%)"
				},
				color: ['#ffaa25', '#ffc435', '#9c4cd1', '#2e8ef2'],
				series: [{
					name: '资产分布',
					type: 'pie',
					radius: ['55%', '73%'],
					center: [145, 140],
					avoidLabelOverlap: false,
					label: {
						normal: {
							show: false,
							position: 'center'
						},
						emphasis: {
							show: false
						}
					},
					labelLine: {
						normal: {
							show: false
						}
					},
					data: [{
							value: result.currentAsset || 0,
							name: '掌薪宝资产'
						},
						{
							value: result.regularAsset || 0,
							name: '定期资产'
						},
						{
							value: result.cashBalance || 0,
							name: '可用余额'
						},
						{
							value: result.frozenBalance || 0,
							name: '冻结金额'
						}
					]
				}]
			};
			// 使用刚指定的配置项和数据显示图表。
			_this.myChartOfPie.setOption(option);
		}
    },
	bindEvent: function () {
		var _this = this;
        $(document).on("click","#monthOptions a",function(){
            $(this).addClass('active').siblings().removeClass("active")
            _this.getBillDate($(this).attr('data-month'))
        })
	},
}

$(function () {
	new AccountMonthBill().init();
})