var AccountMyTn = function() {
	return this;
}

AccountMyTn.prototype =  {
	init: function() {
		this.pageInit();
		this.bindEvent();
		this.param = {
			page:1,
			orderType:'',
			createTime:'',
			orderTimeBegin:'',
			orderTimeEnd:'',
			productOid:''
		}
	},
	pageInit: function(){
		var _this = this
		_this.getRecords(1,'HOLDING',true)
//		_this.getRecords(1,'TOCONFIRM',true)
//		_this.getRecords(1,'CLEARED',true)
	},
	getRecords: function(page,status,isFlag) {
		var _this = this
		GHutils.load({
			url:"/zybusiness/user/myRegular",
			data:{holdStatus:status,pageInfo:{pageSize:5,pageNo:page}},
			type:'post',
			loginStatus:function(resp){
				GHutils.loginOut(true)
			},
			callback:function(result){
				if(result.code != 10000){
					return false;
				}
				$('#tnCapitalAmount').html(GHutils.formatCurrency(result.data.investAmount||0))
				$('#tnYesterdayIncome').html(GHutils.formatCurrency(result.data.yesterdayIncome||0))
				$('#totalIncomeAmount').html(GHutils.formatCurrency(result.data.totalIncome||0))
				$('a[href="#hold"]').html('计息中 ( '+result.data.holdingNum+' )')
				$('a[href="#toConfirmTn"]').html('待计息 ( '+result.data.toConfirmNum+' )')
				$('a[href="#closedTn"]').html('已结清 ( '+result.data.closedNum+' )')
				var contentstr = ''
				var str = ''
				var str1 = ''
				var str2 = ''
				if(!result.data.list) {
					if(status == 'HOLDING') {
						$('#holds').html(hasONoData(""))
					} else if(status == 'TOCONFIRM') {
						$('#toConfirmTns').html(hasONoData(""))
					} else if(status == 'CLEARED') {
						$('#closedTns').html(hasONoData(""))
					}
					return;
				}
				GHutils.forEach(result.data.list,function(idx,content){
					if(status == 'HOLDING') {
						var record = ''
						record = '<a href="/account-depositRecord.html">资金记录</a>'
						var expYearRate = '';
						if(content.productInfo.rewardRate) {
							expYearRate += '<span class="expYearRates">'+(content.productInfo.baseRate).toFixed(2)+'<i class="yuan">%+</i>'+(content.productInfo.rewardRate).toFixed(2)+'<i class="yuan">%</i></span>';
						} else {
							expYearRate += '<span class="expYearRates">'+(content.productInfo.baseRate).toFixed(2)+'<i class="yuan">%</i></span>';
						}
						str+='<div class="fixed_list clearfix"><ul class="clearfix"><li class="col-xs-3 productTite" style="width: 20%"><p><a href="/product-tn.html?productOid='+content.productInfo.productId+'">'+content.productInfo.productName
					    +'</a></p><p class="investFiles"><a href= "/actives1/public/agreement?orderId='+content.orderId+'">《'+(content.productInfo.detail.investCompactFile>=136?'借款协议':'定向委托投资协议')+'》</a></p></li><li class="col-xs-3" style="width: 30%"><p style="margin-bottom:12px;">历史年化收益率</p>'+expYearRate+'<p style="margin-top:12px">到期时间</p><span class="names">'+GHutils.formatTimestamp({time:content.productInfo.expectDurationEndDate,showtime:"true"})
					    +'</span></li><li class="col-xs-3" style="width: 28%"><p style="margin-bottom:12px;">投资金额</p><span class="prices">'+GHutils.formatCurrency(content.orderAmount+0)+'<i class="yuan">元</i></span><p style="margin-top:12px">收益方式</p>'
					    +'<span class="names">'+content.productInfo.payBackTypeCh+'</span></li><li class="col-xs-3" style="width: 22%">'+record+' </li></ul></div>'
						$('#holds').html(hasONoData(str))
						if(isFlag){
							_this.createPage(Math.ceil(result.data.holdingNum/5),status)
						}
					}  else if(status == 'TOCONFIRM') {
						str1+='<div class="fixed_list clearfix">'
						+'<ul class="clearfix"><li class="col-xs-4 productTite" style="width:45%"><p><a href="/product-tn.html?productOid='+content.productInfo.productId+'">'+content.productInfo.productName+'</a></p><p class="investFiles"><a class="invest-protocol" data-title="'+(content.productInfo.detail.investCompactFile>=136?'借款协议':'定向委托投资协议')+'" data-url="/actives1/static/protocolDetail?type=regular_dingxiang&pid='+content.productInfo.productId+'&orderId='+content.orderId+'">《'+(content.productInfo.detail.investCompactFile>=136?'借款协议':'定向委托投资协议')+'》</a></p></li><li class="col-xs-4" style="width:30%"><p style="margin-bottom:12px;">已确认金额</p><span class="prices">'+GHutils.formatCurrency(content.orderAmount == null?0:content.orderAmount)+'<i class="yuan">元</i></span></li>'
					    +'<li class="col-xs-4" style="text-align: right;width:25%"><p>产品预计成立日</p><span class="productTite">'+GHutils.formatTimestamp({time:content.productInfo.expectSetUpDate,showtime:"true"})+'</span></li></ul></div>'
						$('#toConfirmTns').html(hasONoData(str1))
						if(isFlag){
							_this.createPage(Math.ceil(result.data.toConfirmNum/5),status)
						}
						
					} else if(status == 'CLEARED') {
						var setupDate = ''
						setupDate = '<li class="col-xs-3"><p>产品成立日</p><span class="productTite">'+GHutils.formatTimestamp({time:content.productInfo.actualSetUpTime,showtime:"true"})+'</span></li>'
						str2+='<div class="fixed_list clearfix"><ul class="clearfix"><li class="col-xs-3 productTite" style="width: 23%"><p><a href="/product-tn.html?productOid='+content.productInfo.productId+'">'+content.productInfo.productName+'</a></p><p class="investFiles"><a href= "/actives1/public/agreement?orderId='+content.orderId+'">《'+(content.productInfo.detail.investCompactFile>=136?'借款协议':'定向委托投资协议')+'》</a></p></li>'
				        +setupDate+'<li class="col-xs-3" style="width: 27%"><p style="margin-bottom:12px;">本息金额</p><span class="prices">'+GHutils.formatCurrency(content.payAmount+0)+'<i class="yuan">元</i></span></li><li class="col-xs-3"><p>还本付息日</p><span class="productTite">'+GHutils.formatTimestamp({time:content.closedTime,showtime:"true"})+'</span></li></ul>'
				        +'</div></div>'
						$('#closedTns').html(hasONoData(str2))
						if(isFlag){
							_this.createPage(Math.ceil(result.data.closedNum/5),status)
						}
					}
				})
				GHutils.addProtocols($('.invest-protocol'),"","");
			},
			errcallback:function(error){
				
			}
		})
		function hasONoData(products){
			if(products == ''){
				products = '<div class="noDataTips"><img src="static/images/app-nodata1.png" alt="暂无收益_掌悦理财" /></div>'
			}
			return products
		}
	},
	bindEvent:function() {
		var _this = this;
		$("#nav-tabcons").on("click","a[href='#toConfirmTn']",function() {
			if(!$("#toConfirmTns").html()) {
				_this.getRecords(1,'TOCONFIRM',true)
			}
		})
		$("#nav-tabcons").on("click","a[href='#closedTn']",function() {
			if(!$("#closedTns").html()) {
				_this.getRecords(1,'CLEARED',true)
			}
		})
	},
	createPage: function(pageCount,status) {
		$("."+status).show()
		if(pageCount <= 1){
			$("."+status).hide()
		}
		var _this = this;
		$("."+status).createPage({
			pageCount: pageCount,
			current: 1,
			backFn: function(page) {
				_this.getRecords(page,status,false);
			}
		});
	}
}

$(function() {
	new AccountMyTn().init();
})
