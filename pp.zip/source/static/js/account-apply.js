var AccountApply = function() {
	this.tips1 = $("#modify_pay_tips");
	this.userinfo = {};
	this.product = {};
	this.coupon = {
		couponAmount: 0
	}
	this.rateCoupon = {
		couponAmount: 0
	}
	this.coupons = ""
	this.suitable = {}
	this.uraParam = 0
	return this;
}

AccountApply.prototype = {
	init: function() {
		this.pageInit();
		this.bindEvent();
		var hasPayPwd = false;
		var balance = 0;
		this.protocools();
	},
	pageInit: function() {
		var _this = this
		//参数放在地址栏，这种方式还有待修改改的？？？？？？？？？？？？？？？？？？？
		_this.uraParam = GHutils.parseUrlParam(window.location.href)
		//任意一个参数不存在或者格式不符合，页面回退回去
		if(!(_this.uraParam.productOid && _this.uraParam.moneyVolume && ('tn,t0'.indexOf(_this.uraParam.pType) > -1))) {
			window.location.href = "index.html"
		}

		//用户详情判断是否有交易密码
		$('#hasPayPwd').show()
		$('#noPayPwd').hide()
		//可用余额显示
		if(GHutils.getUserInfo()) {
			_this.userinfo = GHutils.getUserInfo();
			_this.hasPayPwd = _this.userinfo.isPayPwd
			if(_this.uraParam.pName) {
				$('#productName').html('投资产品 : <span style="color:#666;font-size:16px;margin-left:17px;">' + decodeURI(_this.uraParam.pName) + '</span>')
			}
		} else {
			window.location.href = "index.html"
		}
		if(_this.uraParam.pType == 'tn') { //定期
			// $('.t0_protocool').hide()
			// $('#coupon').show()
			// $('#needPay').parent().parent().show()
			$(".xieyiChange").hide()
		} else if(_this.uraParam.pType == 't0') { //掌薪宝
			// $('.tn_protocool').hide()
			$(".xieyiChanged").html('我已阅读并同意可能参与的项目协议 ')
            $(".xieyiChange").css({"display":"inline"})
		}
		mycouponofpro(_this.uraParam.productOid) //获取优惠券
		$('#moneyVolume').html(GHutils.formatCurrency(_this.uraParam.moneyVolume) + "元")

		//获取我的优惠券
		function mycouponofpro(productOid) {
			GHutils.load({
				url: _this.uraParam.pType == 'tn'?"/zybusiness/order/invest/prepose":"/assignTrans/order/invest/current/prepose",
				data: {
					productId: productOid
				},
				type: "post",
				callback: function(result) {
					if(result.code != 10000) {
						$(".apply_quan").removeClass('select_coupon')
						$('#apply-errorMessage').html(GHutils.errorMessage(result.message))
						return false;
					}
					$('#balance').html(GHutils.formatCurrency(result.data.availableBalance) + "元")
					if(_this.uraParam.pType == 'tn') {
						var valid = ''
						var invalid = ''
                        if(_this.uraParam.pType == 'tn'&&result.data.coupons) {
                            $('#coupon').show()
                            $('#needPay').parent().parent().show()
                        }

						GHutils.forEach(result.data.coupons, function(idx, coupon) {
							if(_this.uraParam.moneyVolume < (coupon.limitInvestAmount == null ? 0 : coupon.limitInvestAmount)) {
								invalid = joincoupon(invalid, coupon, false)
								return false;
							}
							if(_this.uraParam.moneyVolume < (coupon.couponAmount == null ? 0 : coupon.couponAmount)) {
								invalid = joincoupon(invalid, coupon, false)
								return false;
							}
							if(coupon.couponType.toLowerCase() == "rateCoupon".toLowerCase()) {
								if(_this.rateCoupon.couponAmount < coupon.couponAmount) {
									_this.rateCoupon = coupon
								}
							} else {
								if(_this.coupon.couponAmount < coupon.couponAmount) {
									_this.coupon = coupon
								}
							}
							valid = joincoupon(valid, coupon, true)
							_this.suitable[coupon.ucId] = coupon
						})
						if(getRegularCalculate(_this.rateCoupon) > getRegularCalculates(_this.coupon)) {
							_this.coupon = _this.rateCoupon
							_this.conpons = ""
						}
						$('.apply_quan').html((_this.coupon.ucId == null ? '<span style="color:#fff;font-size: 18px;">无' : '<span style="color:#fff;font-size: 18px;">' + _this.coupon.couponAmount + (_this.coupon.couponType.toLowerCase() == "rateCoupon".toLowerCase() ? ' %' : ' 元')) + '</span><span style="color:#fff;font-size: 18px;margin-left: 10px;">&gt;</span>')
						if(valid) {
							$('#valid').html(valid).show()
						}
						if(invalid) {
							$('#invalid').html(invalid).parent().show()
						}
						$('#needPay').html((_this.coupon && _this.coupon.couponType && _this.coupon.couponType.toLowerCase() == 'COUPON'.toLowerCase() ? GHutils.formatCurrency(GHutils.Fsub(_this.uraParam.moneyVolume, _this.coupon.couponAmount)) : GHutils.formatCurrency(_this.uraParam.moneyVolume)) + "元")
						if(result.data.coupons && result.data.coupons.length == 0) {
							$(".apply_quan").removeClass('select_coupon')
						} else if(!result.data.coupons) {
							$(".apply_quan").removeClass('select_coupon')
						}
						_this.choseCoupon();
					}
				}
			})
		}

		//代金券收益计算
		function getRegularCalculates(info) {
            if(_this.uraParam.dpDays&&_this.uraParam.income) {
                if(_this.uraParam.duration == 'DAY') {
                    return GHutils.Fadd(GHutils.Fadd(GHutils.Fmul(Math.floor(GHutils.Fmul(GHutils.Fmul(info.couponAmount,GHutils.Fmul(GHutils.Fmul(_this.uraParam.expAror,0.01),GHutils.Fdiv(_this.uraParam.dpDays,_this.uraParam.income))),100)),0.01)
							,GHutils.Fmul(Math.floor(GHutils.Fmul(GHutils.Fmul(info.couponAmount,GHutils.Fmul(GHutils.Fmul(_this.uraParam.reward,0.01),GHutils.Fdiv(_this.uraParam.dpDays,_this.uraParam.income))),100)),0.01))
                        	,info.couponAmount)
                } else if(_this.uraParam.duration == 'MONTH') {
                    return GHutils.Fadd(GHutils.Fadd(GHutils.Fmul(Math.floor(GHutils.Fmul(GHutils.Fmul(info.couponAmount,GHutils.Fmul(GHutils.Fmul(_this.uraParam.expAror,0.01),GHutils.Fdiv(_this.uraParam.dpDays,12))),100)),0.01)
							,GHutils.Fmul(Math.floor(GHutils.Fmul(GHutils.Fmul(info.couponAmount,GHutils.Fmul(GHutils.Fmul(_this.uraParam.reward,0.01),GHutils.Fdiv(_this.uraParam.dpDays,12))),100)),0.01))
							,info.couponAmount)
                }
			}
		}

		//加息劵计算
		function getRegularCalculate(info) {
			if(_this.uraParam.dpDays&&_this.uraParam.income) {
				if(_this.uraParam.duration == 'DAY') {
                    return GHutils.Fdiv(Math.floor(GHutils.Fmul(GHutils.Fmul(_this.uraParam.moneyVolume,GHutils.Fmul(GHutils.Fmul(info.couponAmount,0.01),GHutils.Fdiv(_this.uraParam.dpDays,_this.uraParam.income))),100)),100);
				} else if(_this.uraParam.duration == 'MONTH') {
                    return GHutils.Fdiv(Math.floor(GHutils.Fmul(GHutils.Fmul(_this.uraParam.moneyVolume,GHutils.Fmul(GHutils.Fmul(info.couponAmount,0.01),GHutils.Fdiv(_this.uraParam.dpDays,12))),100)),100);
				}
			}
		}
		//拼接卡券字符串
		function joincoupon(str, coup, isFlag) {
			if(isFlag) {
				str += '<li class="apply_nochoise clearfix" data-oid="' + coup.ucId + '">'
			} else {
				str += '<li class="apply_nochoise clearfix">'
			}
			var couponInformation = '';
			var couponType = '';
			if(coup.couponType.toLowerCase() == "rateCoupon".toLowerCase()) {
				couponInformation += '<div class="col-xs-3 applyC_font" style="color: #689ed5"><span>' + GHutils.formatCurrency(coup.couponAmount) + '<i class="tyName">%</i></span></div>'
                couponType += '<p style="margin-bottom: 8px;line-height: 20px;"><span class="biaoqiancon">加息券</span>'+coup.name+'</p>';
			} else {
				couponInformation += '<div class="col-xs-3 applyC_font"><span><i class="tyName">￥</i>' + GHutils.formatCurrency(coup.couponAmount) + '</span></div>'
                couponType += '<p style="margin-bottom: 8px;line-height: 20px;"><span class="biaoqiancon">代金券</span>'+coup.name+'</p>';
			}
			coup.limitInvestAmount = coup.limitInvestAmount == null ? '满0元可使用' : '满' + coup.limitInvestAmount + '元可使用'
			str += couponInformation + '<div class="col-xs-8 applyC_padding">' +
				'<div style="min-height: 77px;">'+couponType+'适用产品：' +
				(!coup.limitLabels ? (!coup.isLimitLabel ? '全场适用' : '') : coup.limitLabels) + '<br />使用规则：' +
				(coup.limitInvestAmount) + '</div><p class="apply_c">'+ '有效期至：' +
                GHutils.formatTimestamp({
                    time: coup.expireTime,
                    showtime: "false"
                })+'<span class="anniu"></span></p></div></li>'
			return str
		}
	},
	bindEvent: function() {
		var _this = this
		var param = {
			bankName: '',
			bankCode: ''
		}

		//点击 选择卡券 弹出卡券弹出层
		$(".apply_quan").on("click", function() {
			if(!$(this).is('.select_coupon')) {
				return false;
			}
			$('#valid li').each(function(i, dom) {
				if(dom) {
					if($(dom).attr('data-oid') == _this.coupon.ucId) {
						$(dom).removeClass('apply_nochoise')
					}
				}
			})
			$(".apply-c-div").show();
			$("body").addClass("modal-open");
		});

		//点击 弹出卡券弹出层关闭按钮  关闭弹出层
		$(".closes").on("click", function() {
			$(".apply-c-div").hide();
            $("body").removeClass("modal-open");
		});

		//我已阅读并同意  前面那个复选框样式  
		$("#deposit_span3").click(function() {
			$(".deposit_span3").removeClass("deposit_span2")
		})

		//点击确认支付
		$('#ok_pay').on('click', function() {
			$('#apply-errorMessage').html('')
			if($(this).is('.submitting')) {
				return false;
			}
			if(!GHutils.userinfo.isPayPwd) {
				$('#setBankPwd').modal('show');
				GHutils.boxSwitch(".modalBox", "#setPayPwdBox");
				return false
			}
			$(this).addClass('submitting')
			if(GHutils.validate('hasPayPwd')) {
				if(!$('#agree_t0').is('.deposit_span2')) {
					var message = '以下相关协议'
					$('#apply-errorMessage').html(GHutils.errorMessage('请同意' + message))
					$(this).removeClass('submitting')
					return false
				}
				if(GHutils.Fsub(_this.uraParam.moneyVolume, _this.coupon.couponAmount) > _this.balance) {
					$('#apply-errorMessage').html(GHutils.errorMessage('账户可用余额不足，请充值'))
					$(this).removeClass('submitting')
					return false
				}
				invest()
			} else {
				$(this).removeClass('submitting')
			}
		})
		

		//购买产品
		var invest = function() {
			var data = {
				productId: _this.uraParam.productOid,
				orderAmount: _this.uraParam.moneyVolume,
				payAmount: (_this.coupon.couponType != null && (_this.coupon.couponType.toLowerCase() == 'COUPON'.toLowerCase()) ? GHutils.Fsub(_this.uraParam.moneyVolume, _this.coupon.couponAmount) : _this.uraParam.moneyVolume),
				couponAmount: _this.coupon.couponAmount,
				payPasswd: $('#payPwd').val()
			};
			if(_this.coupon.couponType)
				data.couponType = _this.coupon.couponType
			if(_this.coupon.ucId)
				data.userCouponId = _this.coupon.ucId
			GHutils.load({
				url: _this.uraParam.pType == 'tn'?"/zybusiness/order/invest":"/assignTrans/order/invest/current",
				data: data,
				type: "post",
				callback: function(result) {
					$('#ok_pay').html('确认支付')
					$(".submitting").removeClass("submitting");
					if(result.code != 10000) {
						$('#apply-errorMessage').html(GHutils.errorMessage(result.message))
						return false;
					}
					window.location.href = 'result.html?productName=' + _this.uraParam.pName + '&moneyVolume=' + _this.uraParam.moneyVolume + '&pType=' + _this.uraParam.pType + '&expectInterestDate=' + result.data.expectInterestDate + '&expectViewIncomeDate=' + result.data.expectViewIncomeDate + '&mes=' + encodeURI(result.message) + '&orderId=' + result.data.orderId
				},
				errcallback: function() { //投资接口请求超时，停止
					$('#ok_pay').html('确认支付')
					$('#apply-errorMessage').html(GHutils.errorMessage('请求超时，请到&nbsp;<a href="/account-depositRecord.html" style="color: #ff4f3f;text-decoration:underline;">资金记录</a>&nbsp;查看是否提交成功'))
					$(".submitting").removeClass("submitting");
				}
			});
		}
	},
	choseCoupon: function() {
		var _this = this
		$('#valid li').on('click', function() {
			if($(this).is('.apply_nochoise')) {
				$('#valid li').addClass('apply_nochoise')
				$(this).removeClass('apply_nochoise')
				_this.coupon = _this.suitable[$(this).attr('data-oid')]
				$('#needPay').html((_this.coupon && _this.coupon.couponType.toLowerCase() == 'COUPON'.toLowerCase() ? GHutils.formatCurrency(_this.uraParam.moneyVolume - _this.coupon.couponAmount) : GHutils.formatCurrency(_this.uraParam.moneyVolume)) + "元")
				$('.apply_quan').html('<span style="color:#fff;font-size: 18px;">' + (_this.coupon.ucId == null ? '无' : _this.coupon.couponAmount + (_this.coupon.couponType.toLowerCase() == "rateCoupon".toLowerCase() ? ' %' : ' 元')) + '</span><span style="color:#fff;font-size: 18px;margin-left: 10px;">&gt;</span>')

			} else {
				_this.coupon = {
					'ucId': null,
					'couponType': null,
					'couponAmount': 0
				};
				$('.apply_quan').html('<span style="color:#fff;font-size: 18px;">请选择</span><span style="color:#fff;font-size: 18px;margin-left: 10px;">&gt;</span>')
				$('#valid li').addClass('apply_nochoise')
				$('#needPay').html(GHutils.formatCurrency(_this.uraParam.moneyVolume) + "元")
			}
		})
		$("#closed img").on('click', function() {
			$(".tishi_box").hide();
		})
	},
	protocools: function() {
		var _this = this
		GHutils.addProtocols($(".investFiles"),_this.uraParam.moneyVolume,(_this.uraParam.pType == "tn"?"regular_dingxiang":"current_borrow")+"&pid="+_this.uraParam.productOid);
		GHutils.addProtocols($(".serviceFiles"),_this.uraParam.moneyVolume,_this.uraParam.productOid);
	},
	turnType: function(type) {
		if(type.toLowerCase() == 'redPackets'.toLowerCase()) {
			type = '红包'
		} else if(type.toLowerCase() == 'coupon'.toLowerCase()) {
			type = '代金券'
		} else if(type.toLowerCase() == 'rateCoupon'.toLowerCase()) {
			type = '加息券'
		} else {
			type = '优惠券'
		}
		return type;
	},
	callBackFun: function() {
		var _this = this
		_this.pageInit();
	}
}

$(function() {
	new AccountApply().init();
	window.pageFun = new AccountApply();
})