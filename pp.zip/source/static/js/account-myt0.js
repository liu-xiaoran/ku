var AccountMyT0 = function() {
	return this;
}

AccountMyT0.prototype = {
	init: function() {
		this.pageInit();
		this.param = {
			orderType: '',
			createTime: '',
			orderTimeBegin: '',
			orderTimeEnd: '',
			productOid: ''
		}
	},
	pageInit: function() {
		var _this = this
		_this.loadMyt0(1, true)

	},
	loadMyt0: function(page, isFlag) {
		//我的掌薪宝列表
		var rows = 6
		var _this = this
		GHutils.load({
			//新的活期接口assignTrans
			url: "/assignTrans/user/myCurrent/pc",
			data: {
				pageInfo: {
					pageNo: page,
					pageSize: rows
				}
			},
			type: "post",
			callback: function(result) {
				if(result.code != 10000) {
					return false;
				}
				if(result.data.list) {
                    $('#noT0').hide()
                    $('#hasT0').show()
				} else {
                    $('#noT0').show()
                    $('#hasT0').hide()
				}
				var newProducts = ''
				GHutils.forEach(result.data.list, function(idx, record) {
					//待计息 计息中 已转让 
					var investProtocol = ((record.holdStatus!='TOCONFIRM')&&(record.createTime>1513822380000))?("<a class='xieyiDetails' attr-date="+record.orderId+">查看协议</a>"):""
					
					// if(record.holdStatus == 'TOCONFIRM') {
					// 	investProtocol = '<a class="investFiles invest-protocol" data-title="'+(record.createTime>1512126480000?'借款协议':'定向委托投资协议')+'" data-url="/actives1/static/protocolDetail?type=current_dingxiang&pid='+record.productInfo.productId+'&orderId='+record.orderId+'">《'+(record.createTime>1512126480000?'借款协议':'定向委托投资协议')+'》</a>'
					// } else {
					// 	investProtocol = '<a class="investFiles" href= "/actives1/public/agreement?orderId=' + record.orderId + '">《'+(record.createTime>1512126480000?'借款协议':'定向委托投资协议')+'》</a>'
					// }

					var debtDetail = (record.createTime>1513822380000)?'<a class="debtDetails" attr-dates='+record.orderNo+' attr-date='+record.productInfo.productId+' >债权详情</a>':'';
					var isShow = ""
					if(record.orderType!='INVEST') {
						if(record.income==record.orderAmount) {
                            investProtocol = ""
                            debtDetail = ""
						} else {
							if(record.createTime>1513822380000) {
                                isShow = '<div class="triangles" style="position: absolute;top: 49px;left: 32%;z-index: 200;display: none;">'
                                    +'<div class="triangle-inner" style="border: 1px solid #b4b4b4;border-left: 0;border-bottom: 0;left:50%;"></div>'
                                    +'<span style="display: inline-block;border: 1px solid #b4b4b4;background: #fff;padding: 0 10px;">本金：'+record.capital+'元，利息：'+record.income+'元</span></div>';
							} else {
                                isShow = ""
							}
						}
					}
					newProducts += '<ul class="prot0qrydetail-list" style="position: relative;"><li>' + record.productInfo.productName + '</li><li style="width:11.9%;margin-left:1.5%;">' + GHutils.formatTimestamp({
						time: record.createTime,
						showtime: "true"
					}) + '</li><li class="orderAmount" style="width:19.1%;margin-left:2%;'+(isShow?"cursor: pointer;":"")+'">'+ isShow + GHutils.formatCurrency(record.orderAmount) + '元</li><li style="color:#ec9437;width:17.4%;margin-right: 2%;">' + record.tradStatus + '</li>'+(record.holdStatus!="TOCONFIRM"?('<li class="debtDetail">'+debtDetail+'</li>'):'<li style="width:7.4%;"></li>')+'<li>' + investProtocol + '</li></ul>';
				})
				$("#hasT0-list").html(newProducts)
				var widths;
				for(var i = 0,len=document.getElementsByClassName("prot0qrydetail-list").length;i<len;i++) {
					if($(".prot0qrydetail-list").eq(i).children(".triangles")) {
                        widths = $(".prot0qrydetail-list").width()/2.35 - $(".prot0qrydetail-list").eq(i).find(".triangles").width()/2;
                        $(".prot0qrydetail-list").eq(i).find(".triangles").css({"left":widths});
					}
				}
				GHutils.addProtocols($('.invest-protocol'));
				var total = result.data.pageInfo.totalSize
				_this.nextPage();
				if(isFlag) {
					_this.createPage(Math.ceil(total / rows));
				}
				if(result.data.productId)
					$("#shuhui").attr("href", "/product-redeem.html?productOid=" + result.data.productId);
				else
					$("#shuhui").hide();
				$('#t0CapitalAmount').html(GHutils.formatCurrency(result.data.holdAmount || 0)) //掌薪宝资产总额
				$('#t0YesterdayIncome').html(GHutils.formatCurrency(result.data.yesterdayIncome || 0)) //掌薪宝昨日收益额
				$('#totalIncomeAmount').html(GHutils.formatCurrency(result.data.totalIncome || 0)) //累计收益总额
                $(".orderAmount").hover(function () {
                    $(this).children(".triangles").show()
                },function () {
                    $(this).children(".triangles").hide()
                })
			}
		})

	},
	createPage: function(pageCount) {
        if(pageCount <= 1) {
            $(".tcdPageCode").hide()
        }
		var _this = this;
		$(".tcdPageCode").createPage({
			pageCount: pageCount,
			current: 1,
			backFn: function(page) {
				_this.loadMyt0(page, false);
			}
		});
	},
	nextPage: function() {
		var _this = this
		$('.getnext').on('click', function() {
			$('.tcdPageCode span.current').next().click()
		})
		$('.getprevious').on('click', function() {
			$('.tcdPageCode span.current').prev().click()
		})

		$('.tnProductInfo').on('click', function() {
			var oid = $(this).attr('data-oid')
			if(oid) {
				window.location.href = 'product-tn.html?productOid=' + oid
			} else {
				if(_this.loginStatus == 'no') {
					
				} else {
					if(_this.loginStatus) {
						//显示弹窗
						$('#content-box').modal('show')
					} else {
						
					}
				}
			}
		})

		//债权详情详情弹框
		$(".debtDetails").on("click",function(){
			GHutils.load({
				url:"/assignTrans/hold/asset/list",
				data:{
					productId: $(this).attr('attr-date'),
                    orderNo: $(this).attr('attr-dates')
				},
				type: "post",
				callback: function(result){
					if(result.code==10000){
						var data = result.data,html = ""
						$('.modal-title').html('债权详情')
						$('.debtBody-header').html('<div>债权名称</div><div>借款方</div>')
						GHutils.forEach(data,function(index,item){
							html += '<div>'+item.assetName +'</div><div>'+item.borrowerName+'</div>'
						})
						$(".debeBody-body").html(html)
						$('#debtDetail').modal('show')
					}
				}
			})
		})
		//协议详情弹框
		$(".xieyiDetails").on("click",function(){
			GHutils.load({
				url:"/actives1/static/signAgreementList",
				data:{
					orderId: $(this).attr('attr-date')
				},
				type: "post",
				callback: function(result){
					if(result.code==10000){
						var data = result.data,html = ""
						$('.modal-title').html('协议详情')
						$('.debtBody-header').html('<div>协议</div><div>协议编号</div>')
						GHutils.forEach(data,function(index,item){
							html += '<div><a href="'+item.pdfUrl+'">《'+item.pactName +'》</a></div><div>'+item.pactId+'</div>'
						})
						$(".debeBody-body").html(html)
						$('#debtDetail').modal('show')
					}
				}
			})
		})
	}
}

$(function() {
	new AccountMyT0().init();
})