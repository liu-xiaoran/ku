var AccountMySetting = function() {
	this.tips1 = $("#pay_pwd_tips1");
	this.tips2 = $("#pay_pwd_tips2");
	this.tips3 = $('#modify_tips');
	this.tips4 = $('#setting_tips');
	this.tips5 = $('#modify_pay_tips');
	this.tips6 = $('#bind_bink_tips');
	this.newpwd = '';
	this.setProgress = 0;
	return this;
}

AccountMySetting.prototype =  {
	init: function() {
		this.pageInit();
		this.bindEvent();
		this.btntime = null;
	},
	callBackFun:function(){
		this.init();
	},
	pageInit: function() {
		var _this = this;
		_this.setProgress = 0
		
		$("#nowAddCard").on("click",function(){
			$('#getBanklist').trigger("click")
		})

		if (GHutils.userinfo.isRealVerifiedName) {
			//已经实名认证
			$('#nameIcon').addClass('bg_brown_blue');
			var idnumb =''
			if(GHutils.userinfo.isBindCard == 1){
				idnumb += '**** ***** ***** *** '  +GHutils.userinfo.bankCard.substr(-4)
			}else{
				idnumb += '未认证'
			}
			$('#realName').html(GHutils.userinfo.nickname||"--");
			$('#hasCard').html(idnumb)
			$('#getBanklist').remove();
			$('#have-realName').remove();
			$('#realNameIdentify').append('<div id="have-realName" class="col-xs-2">已认证</div>');
			_this.setProgress = _this.setProgress + 25;
		}
		if (GHutils.userinfo.phone != '') {
			//已经手机认证
			$('#phoneIcon').addClass('bg_brown_blue');
			var bankphone = GHutils.userinfo.phone;
			$('#bindPhone,#bindPhones').html(bankphone);
			_this.setProgress = _this.setProgress + 25;
		}
		if (GHutils.userinfo.isPwd == 1) {
			//已经设置登录密码
			$('#loginpwdIcon').addClass('bg_brown_blue');
			$("#modifyLoginPassword").show();
			$("#settingLoginpassword").hide();
			$("#dengluPwd").html('<span class="green"><img src="static/images/greenGou.png"/>已设置</span>');
			_this.setProgress = _this.setProgress + 25;
		}else{
			$("#settingLoginpassword").show();
			$("#modifyLoginPassword").hide();
			$("#dengluPwd").html("未设置");
		}
		if (GHutils.userinfo.isPayPwd == 1) {
			//已经设置交易密码
			$('#paypwdIcon').addClass('bg_brown_blue');
			$("#modifyPayPassword").show();
			$("#setPayPwd").hide();
			$("#jiaoyipwd").html('<span class="green"><img src="static/images/greenGou.png"/>已设置</span>');
			_this.setProgress = _this.setProgress + 25;
		}else{
			$("#setPayPwd").show();
			$("#modifyPayPassword").hide();
			$("#jiaoyipwd").html("未设置");
		}
		$('#progressbar').css('width',_this.setProgress + '%');
		$('#safetyCord').html(_this.setProgress);
		_this.bindEvent()
	},
	bindEvent: function() {
		var _this = this;

		var modifyLoginPwd = function() {
			$('#updateLoginPwd input').val('')
			$(_this.tips3).html('&nbsp;');
			$('#updateLoginPwd').modal('show');
		}
		//修改登录密码  判断是否登录 updateLoginPwd
		$('#modifyLoginPassword').off().on('click',function(){
			if(GHutils.getUserInfo()) {
				modifyLoginPwd()
			} else {
				window.location.href = "index.html"
			}
		})
		$('#modify_login_pwd').off().on('click', function() {
			$(_this.tips3).html('&nbsp;');
			var oldpwd = GHutils.trim($('#oldPassword').val());
			var newpwd = GHutils.trim($('#newPassword').val());
			_this.newpwd = newpwd;
			
			if (oldpwd == '') {
				$(_this.tips3).html(GHutils.errorMessage('请输入原始密码'));
				return;
			}
			if (newpwd == '') {
				$(_this.tips3).html(GHutils.errorMessage('请输入新密码'));
				return;
			}
			if(oldpwd == newpwd){
				$(_this.tips3).html(GHutils.errorMessage('原始密码和新密码不能一致'));
				return;
			}
			_this.modifypassword(oldpwd,newpwd);
			
		})
		var setLoginPwd = function() {
			$('#settingLoginPwd').modal('show');
		}
		//设置登录密码
		$('#settingLoginpassword').off().on('click', function() {
			if(GHutils.getUserInfo()) {
				setLoginPwd()
			} else {
				window.location.href = "index.html"
			}
		})
		
		$('#setting_login_pwd').off().on('click', function() {
			$(_this.tips4).html('&nbsp;');
			var pwd = GHutils.trim($('#newPassword1').val());
			
			if (pwd == '') {
				$(_this.tips4).html(GHutils.errorMessage('新密码不能为空'));
				return;
			}
			_this.settingPassword(pwd);
		})
		
		$('.updateLoginPwdOk').off().on('click',function(){
			window.location.href = window.location.href
		})
	},
	//修改登录密码
	modifypassword: function(oldpwd,newpwd) {
		var _this = this;
		_this.loginpwdStatus = 'faild';
		
		GHutils.load({
			url: "/platform1/userpub/updpwd",
			data: {
				oldPwd:oldpwd,
				newPwd: newpwd,
				newPwd2: newpwd,
				platform:'pc'
			},
			type: "post",
			loginStatus:function(resp){
				$(_this.tips3).html(GHutils.errorMessage(resp.message));
			},
			callback: function(result) {
				$('#updateLoginPwd').modal('hide');
				if (result.code == 10000) {
					$('#updateLoginPwdSucced').modal('show');

					GHutils.loginOut()
					_this.pageInit()
				} else {
					if(result.message) {
                        $('#FailedText').html(result.message);
					}
					$('#updateLoginPwdFaild').modal('show');
				} 
			}
		})
	},
	// 设置登录密码
	settingPassword: function(val) {
		var _this = this;
		var newpwd = val;
		
		GHutils.load({
			url: "/platform1/userpub/setpwd",
			data: {
				newPwd: newpwd,
				newPwd2:newpwd,
				platform:'pc'
			},
			type: "post",
			loginStatus:function(resp){
				$(_this.tips4).html(GHutils.errorMessage(resp.message));
			},
			callback: function(result) {
				$('#settingLoginPwd').modal('hide');
				if (result.code == 10000) {
					$('#settingLoginPwdSucced').modal('show');

					GHutils.loginOut()
				} else {
					$('#settingLoginPwdFaild').modal('show');
				}
				_this.pageInit()
			}
		})
	}
}

$(function() {
	new AccountMySetting().init();
	window.pageFun = new AccountMySetting();
})

