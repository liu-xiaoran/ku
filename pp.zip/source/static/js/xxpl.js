$(function() {
    if(GHutils.parseUrlParam(window.location.href).one == 1&&!GHutils.parseUrlParam(window.location.href).t) {
        document.title = '信息披露_掌悦理财'
        $(".xxpl").addClass("active").siblings().removeClass("active")
    } else {
        document.title = '关于我们_掌悦理财'
        $(".aboutUs").addClass("active").siblings().removeClass("active")
    }
    var tab = [{
        tabs1: '关于我们',
        tabs2: [{
            name: '公司简介',
            url: './xxpl/aboutUs.html?types=introduce'
        },{
            name: '管理团队',
            url: './xxpl/aboutUs.html?types=manage'
        },{
            name: '企业文化',
            url: './xxpl/aboutUs.html?types=culture'
        },{
            name: '联系我们',
            url: './xxpl/aboutUs.html?types=contact'
        },{
            name: '荣誉证书',
            url: './xxpl/aboutUs.html?type=honor'
        }]
    },{
        tabs1: '信息披露',
        tabs2: [{
                name: '承诺函',
                url: './xxpl/commitment.html'
            },{
                name: '银行存管',
                urls: '/yhcg.html'
            },{
            name: '组织信息',
            url: './xxpl/organizational.html',
            tabs3: [{
                names: '工商信息',
                url: './xxpl/organizational.html?typed=business'
            },{
                names: '股东信息',
                url: './xxpl/organizational.html?typed=shareholder'
            },{
                names: '组织架构',
                url: './xxpl/organizational.html?typed=organization'
            },{
                names: '分支机构',
                url: './xxpl/organizational.html?typed=mechanism'
            },{
                names: '官方渠道',
                url: './xxpl/organizational.html?typed=channel'
            }]
        },{
            name: '平台数据',
            url: './xxpl/platform_data.html'
        },{
            name: '运营报告',
            url: './xxpl/operation-report.html'
        },{
            name: '风险控制',
            urls: '/safety.html'
        }, {
            name: '重大事项',
            url: './xxpl/major_matters.html'
        },{
            name: '收费标准',
            url: './xxpl/charge_standard.html'
        },{
            name: '法律声明',
            url: './xxpl/legal_declaration.html'
        }]
    }];
    var html = '',htmls = '',htmlss = ''
    for(var i = 0;i<tab.length;i++) {
        if(tab[i].tabs2&&tab[i].tabs2.length>0) {
            htmls = ''
            twoTabs(tab[i].tabs2)
            html += '<li class="onetabs"><p class="tabbtnss1">'+tab[i].tabs1+'<i class="i_imgs"></i></p><ul class="onetabList">'+htmls+'</ul></li>'
        } else {
            html += '<li class="onetabs"><p class="tabbtnss1">'+tab[i].tabs1+'</p></li>'
        }
    }
    $("#tabs").html(html)
    function twoTabs(ts) {
        for(var j = 0;j<ts.length;j++) {
            if(ts[j].tabs3&&ts[j].tabs3.length>0) {
                htmlss = ''
                sanTabs(ts[j].tabs3)
                htmls += '<li class="twotabs twotabsacts"><p class="tabbtnss2 tabbtnssed">'+ts[j].name+'<i class="i_img"></i></p><ul class="santabList">'+htmlss+'</ul></li>'
            } else {
                if(ts[j].url) {
                    htmls += '<li class="twotabs"><p class="tabbtnss2 tabbtnsseds" data-url="'+ts[j].url+'">'+ts[j].name+'<i class="i_img"></i><p></li>'
                } else if(ts[j].urls) {
                    htmls += '<li class="twotabs"><p class="tabbtnss2 tabbtnsseds" data-urls="'+ts[j].urls+'">'+ts[j].name+'<i class="i_img"></i><p></li>'
                }
            }
        }
    }
    function sanTabs(t) {
        for(var z = 0;z<t.length;z++) {
            htmlss += '<li class="santabs"><p class="tabbtnss3" data-url="'+t[z].url+'">'+t[z].names+'<p></li>'
        }
    }
    $(".tabbtnss1").on("click",function () {
        var num = $(this).height();
        var nums = $(this).parent(".onetabs").children(".onetabList").height() + $(this).parent(".onetabs").find(".santabList").height() + num;
        if($(this).hasClass("actI_imgs")) {
            $(this).parent(".onetabs").stop().animate({
                'height': num + 'px'
            }, 400)
        } else {
            $(this).parent(".onetabs").stop().animate({
                'height': nums + 'px'
            }, 400)
        }
        if($(this).parent(".onetabs").siblings().find(".tabbtnss1").hasClass("actI_imgs")) {
            $(this).parent(".onetabs").siblings().find(".tabbtnss1").removeClass("actI_imgs").parent(".onetabs").stop().animate({
                'height': num + 'px'
            }, 400)
        }
        $(this).toggleClass("actI_imgs")
        if($(this).siblings().find(".tabbtnssed").hasClass("actTabbtnssed")) {
            $(this).siblings().find(".tabbtnssed").removeClass("actTabbtnssed")
            $(this).siblings().find(".tabbtnssed").parent(".twotabsacts").stop().animate({
                'height': $(".tabbtnssed").height() + 'px'
            }, 400)
        }
    })

    $(".tabbtnssed").on("mouseenter",function () {
        var numed = $(this).height();
        var numeds = $(this).parent(".twotabsacts").children(".santabList").height() + numed;
        if($(this).hasClass("actTabbtnssed")) {
        } else {
            $(this).parent(".twotabsacts").stop().animate({
                'height': numeds + 'px'
            }, 400)
            $(this).addClass("actTabbtnssed")
        }
        if($(this).parent(".twotabsacts").siblings().find(".tabbtnssed").hasClass("actTabbtnssed")) {
            $(this).parent(".twotabsacts").siblings().find(".tabbtnssed").removeClass("actTabbtnssed").parent(".twotabsacts").stop().animate({
                'height': nums + 'px'
            }, 400)
        }
    }).on("click",function () {
        var numed = $(this).height();
        var numeds = $(this).parent(".twotabsacts").children(".santabList").height() + numed;
        if($(this).hasClass("actTabbtnssed")) {
            $(this).parent(".twotabsacts").stop().animate({
                'height': numed + 'px'
            }, 400)
            $(this).removeClass("actTabbtnssed")
        } else {
            $(this).parent(".twotabsacts").stop().animate({
                'height': numeds + 'px'
            }, 400)
            $(this).addClass("actTabbtnssed")
        }
    })
    $(".tabbtnsseds").on("click",function () {
        if($(this).attr("data-url")) {
            if($(this).attr("data-url").indexOf("aboutUs")>=0) {
                document.title = '关于我们_掌悦理财'
                $(".aboutUs").addClass("active").siblings().removeClass("active")
            } else {
                document.title = '信息披露_掌悦理财'
                $(".xxpl").addClass("active").siblings().removeClass("active")
            }
            $(this).parent(".twotabs").siblings(".twotabsacts").stop().animate({
                'height': $(".tabbtnssed").height() + 'px'
            }, 400).find(".tabbtnssed").removeClass("actTabbtnssed")
            $(this).parents("#tabs").find(".tabbtnss3").removeClass("sanActList")
            $(this).parents(".onetabs").siblings().find(".tabbtnsseds").removeClass("tabbtnssedsAct")
            $(this).addClass("tabbtnssedsAct").parent(".twotabs").siblings().find(".tabbtnsseds").removeClass("tabbtnssedsAct")
            setIframeHeight("showIframe")
            $(".showIframe").attr("src",$(this).attr("data-url"))
            if(GHutils.parseUrlParam($(this).attr("data-url")).types) {
                var t = GHutils.parseUrlParam($(this).attr("data-url")).types
                if(t == "manage") {
                    scrollss("1010px")
                } else if(t == "introduce") {
                    scrollss("450px")
                } else if(t == "culture") {
                    scrollss("1750px")
                } else if(t == "contact") {
                    scrollss("2480px")
                }
            }
        } else if($(this).attr("data-urls")) {
            location.href = $(this).attr("data-urls");
        }
    })
    $(".tabbtnss3").on("click",function () {
        $(".xxpl").addClass("active").siblings().removeClass("active")
        $(this).addClass("sanActList").parent(".santabs").siblings().children(".tabbtnss3").removeClass("sanActList")
        $(this).parents(".twotabs").siblings().find(".tabbtnsseds").removeClass("tabbtnssedsAct")
        $(this).parents(".onetabs").siblings().find(".tabbtnsseds").removeClass("tabbtnssedsAct")
        $(this).parents(".twotabs").siblings().find(".tabbtnss3").removeClass("sanActList")
        $(this).parents(".onetabs").siblings().find(".tabbtnss3").removeClass("sanActList")
        setIframeHeight("showIframe")
        $(".showIframe").attr("src",$(this).attr("data-url"))
        var t = GHutils.parseUrlParam($(this).attr("data-url")).typed
        if(t == "business") {
            scrollss("200px")
        } else if(t == "shareholder") {
            scrollss("950px")
        } else if(t == "organization") {
            scrollss("1180px")
        } else if(t == "mechanism") {
            scrollss("2030px")
        } else if(t == "channel") {
            scrollss("2200px")
        }
    })
    setIframeHeight("showIframe")
    function setIframeHeight(id){
        var UA = navigator.userAgent.toLowerCase().toString();
        try{
            var iframe = document.getElementById(id);
            if(iframe.attachEvent){
                iframe.attachEvent("onload", function(){
                    iframe.height =  iframe.contentWindow.document.documentElement.scrollHeight;
                    firefox_ie(id)
                });
                return;
            }else{
                iframe.onload = function(){
                    iframe.height = iframe.contentDocument.body.scrollHeight;
                    firefox_ie(id)
                };
                return;
            }
        }catch(e){
            throw new Error('setIframeHeight Error');
        }
    }
    function firefox_ie(id) {
        var frm = document.getElementById(id); //将iframe1替换为你的ID名
        var subWeb = document.frames ? document.frames[id].document :frm.contentDocument;
        if (frm != null && subWeb != null) {
            frm.style.height = "0px"; //初始化一下,否则会保留大页面高度
            frm.style.height = subWeb.documentElement.scrollHeight + "px";
            subWeb.body.style.overflowX = "auto";
            subWeb.body.style.overflowY = "auto";
        }
    }
    function scrollss(num) {
        $('body,html').animate({
            'scrollTop': num
        }, 300);
    }
    function scrolls(num) {
        var time = setTimeout(function () {
            $('body,html').animate({
                'scrollTop': num
            }, 300);
            clearTimeout(time)
        },500)
    }
    (function () {
        var parseUrlParam = GHutils.parseUrlParam(window.location.href);
        // if(GHutils.parseUrlParam($("#showIframe").attr("src")).types) {
        //    $(window).scroll(function(){
        //        if($(window).scrollTop()>=2480) {
        //            $("#tabs").children(".onetabs").eq(0).children(".onetabList").find(".twotabs").eq(3).children(".tabbtnsseds").addClass("tabbtnssedsAct")
        //            $("#tabs").children(".onetabs").eq(0).children(".onetabList").find(".twotabs").eq(3).siblings().children(".tabbtnsseds").removeClass("tabbtnssedsAct")
        //        } else if($(window).scrollTop()<2480&&$(window).scrollTop()>=1750) {
        //            $("#tabs").children(".onetabs").eq(0).children(".onetabList").find(".twotabs").eq(2).children(".tabbtnsseds").addClass("tabbtnssedsAct")
        //            $("#tabs").children(".onetabs").eq(0).children(".onetabList").find(".twotabs").eq(2).siblings().children(".tabbtnsseds").removeClass("tabbtnssedsAct")
        //        } else if($(window).scrollTop()<1750&&$(window).scrollTop()>=450) {
        //            $("#tabs").children(".onetabs").eq(0).children(".onetabList").find(".twotabs").eq(1).children(".tabbtnsseds").addClass("tabbtnssedsAct")
        //            $("#tabs").children(".onetabs").eq(0).children(".onetabList").find(".twotabs").eq(1).siblings().children(".tabbtnsseds").removeClass("tabbtnssedsAct")
        //        } else if($(window).scrollTop()<450) {
        //            $("#tabs").children(".onetabs").eq(0).children(".onetabList").find(".twotabs").eq(0).children(".tabbtnsseds").addClass("tabbtnssedsAct")
        //            $("#tabs").children(".onetabs").eq(0).children(".onetabList").find(".twotabs").eq(0).siblings().children(".tabbtnsseds").removeClass("tabbtnssedsAct")
        //        }
        //    });
        // } else if(GHutils.parseUrlParam($("#showIframe").attr("src")).typed) {
        //    $(window).scroll(function(){
        //        if($(window).scrollTop()>=2200) {
        //            $(".santabList").children(".santabs").eq(4).find(".tabbtnss3").addClass("sanActList")
        //            $(".santabList").children(".santabs").eq(4).siblings().find(".tabbtnss3").removeClass("sanActList")
        //        } else if($(window).scrollTop()<2200&&$(window).scrollTop()>=2030) {
        //            $(".santabList").children(".santabs").eq(3).find(".tabbtnss3").addClass("sanActList")
        //            $(".santabList").children(".santabs").eq(3).siblings().find(".tabbtnss3").removeClass("sanActList")
        //        } else if($(window).scrollTop()<2030&&$(window).scrollTop()>=1180) {
        //            $(".santabList").children(".santabs").eq(2).find(".tabbtnss3").addClass("sanActList")
        //            $(".santabList").children(".santabs").eq(2).siblings().find(".tabbtnss3").removeClass("sanActList")
        //        } else if($(window).scrollTop()<1180&&$(window).scrollTop()>=950) {
        //            $(".santabList").children(".santabs").eq(1).find(".tabbtnss3").addClass("sanActList")
        //            $(".santabList").children(".santabs").eq(1).siblings().find(".tabbtnss3").removeClass("sanActList")
        //        } else if($(window).scrollTop()<950) {
        //            $(".santabList").children(".santabs").eq(0).find(".tabbtnss3").addClass("sanActList")
        //            $(".santabList").children(".santabs").eq(0).siblings().find(".tabbtnss3").removeClass("sanActList")
        //        }
        //    });
        // }
        if(parseUrlParam.one) {
            var num = $(".onetabs").eq(parseUrlParam.one).find(".tabbtnss1").height();
            var nums = $(".onetabs").eq(parseUrlParam.one).children(".onetabList").height() + $(".onetabs").eq(parseUrlParam.one).find(".santabList").height() + num;
            $(".onetabs").eq(parseUrlParam.one).find(".tabbtnss1").addClass("actI_imgs")
            $(".onetabs").eq(parseUrlParam.one).stop().animate({
                'height': nums + 'px'
            }, 400)
            if(parseUrlParam.two) {
                if($(".onetabs").eq(parseUrlParam.one).children(".onetabList").find(".twotabs").eq(parseUrlParam.two).children(".tabbtnss2").hasClass("tabbtnsseds")) {
                    $(".onetabs").eq(parseUrlParam.one).children(".onetabList").find(".twotabs").eq(parseUrlParam.two).children(".tabbtnsseds").addClass("tabbtnssedsAct")
                } else if($(".onetabs").eq(parseUrlParam.one).children(".onetabList").find(".twotabs").eq(parseUrlParam.two).children(".tabbtnss2").hasClass("tabbtnssed")) {
                    $(".onetabs").eq(parseUrlParam.one).children(".onetabList").find(".twotabs").eq(parseUrlParam.two).children(".tabbtnssed").addClass("actTabbtnssed")
                    var numed = $(".onetabs").eq(parseUrlParam.one).find(".twotabs").eq(parseUrlParam.two).children(".tabbtnss2 ").height();
                    var numeds = $(".onetabs").eq(parseUrlParam.one).find(".twotabs").eq(parseUrlParam.two).children(".santabList").height() + numed;
                    $(".onetabs").eq(parseUrlParam.one).children(".onetabList").find(".twotabs").eq(parseUrlParam.two).stop().animate({
                        'height': numeds + 'px'
                    }, 400)
                }
                if(parseUrlParam.three) {
                    $(".onetabs").eq(parseUrlParam.one).children(".onetabList").find(".twotabs").eq(parseUrlParam.two).find(".santabList").children(".santabs").eq(parseUrlParam.three).children(".tabbtnss3").addClass("sanActList")
                }
            }
        }
        if(parseUrlParam.one&&parseUrlParam.two&&parseUrlParam.three) {
            if(tab[parseUrlParam.one]&&tab[parseUrlParam.one].tabs2[parseUrlParam.two]&&tab[parseUrlParam.one].tabs2[parseUrlParam.two].tabs3[parseUrlParam.three]&&tab[parseUrlParam.one].tabs2[parseUrlParam.two].tabs3[parseUrlParam.three].url) {
                $(".showIframe").attr("src",tab[parseUrlParam.one].tabs2[parseUrlParam.two].tabs3[parseUrlParam.three].url)
                if(GHutils.parseUrlParam(tab[parseUrlParam.one].tabs2[parseUrlParam.two].tabs3[parseUrlParam.three].url).typed) {
                    var t = GHutils.parseUrlParam(tab[parseUrlParam.one].tabs2[parseUrlParam.two].tabs3[parseUrlParam.three].url).typed
                    if(t == "business") {
                        scrolls("200px")
                    } else if(t == "shareholder") {
                        scrolls("950px")
                    } else if(t == "organization") {
                        scrolls("1180px")
                    } else if(t == "mechanism") {
                        scrolls("2030px")
                    } else if(t == "channel") {
                        scrolls("2200px")
                    }
                }
            } else {
                $(".showIframe").attr("src",'./xxpl/aboutUs.html')
            }
        } else if(parseUrlParam.one&&parseUrlParam.two&&!parseUrlParam.three) {
            if(tab[parseUrlParam.one]&&tab[parseUrlParam.one].tabs2[parseUrlParam.two]&&tab[parseUrlParam.one].tabs2[parseUrlParam.two].url) {
                $(".showIframe").attr("src",tab[parseUrlParam.one].tabs2[parseUrlParam.two].url)
                if(GHutils.parseUrlParam(tab[parseUrlParam.one].tabs2[parseUrlParam.two].url).types) {
                    var t = GHutils.parseUrlParam(tab[parseUrlParam.one].tabs2[parseUrlParam.two].url).types
                    if(t == "manage") {
                        scrolls("1010px")
                    } else if(t == "introduce") {
                        scrolls("450px")
                    } else if(t == "culture") {
                        scrolls("1750px")
                    } else if(t == "contact") {
                        scrolls("2480px")
                    }
                }
            } else {
                $(".showIframe").attr("src",'./xxpl/aboutUs.html')
            }
        } else {
            var num = $(".onetabs").eq(0).find(".tabbtnss1").height();
            var nums = $(".onetabs").eq(0).children(".onetabList").height() + $(".onetabs").eq(0).find(".santabList").height() + num;
            $(".onetabs").eq(0).find(".tabbtnss1").addClass("actI_imgs")
            $(".onetabs").eq(0).stop().animate({
                'height': nums + 'px'
            }, 400)
            $(".showIframe").attr("src",'./xxpl/aboutUs.html')
        }
    })()
})
GHutils.writePageLoad('HelpCenter')