<template>
  <div class="activites">
    <img :src="arr[acts]" class="bg">
    <p class="money">{{amount}}<span v-if="amount">元</span> </p>
    <p class="account"><span >{{text}}</span> 
      <span class="num">{{phone}}</span>
      <span id="edit" @click="edit" v-show="editshow">修改></span>
    </p>
    <div class="prompt" v-show="show">
      {{prompt}}
    </div>
    <img src="../../assets/goapp.png" class="goapp" @click="goapp" />
    <div class="tishi" v-show="showtishi">
      <div class="shade" @click="closeshade">
        <img class="jiantou" src="../../assets/arrow.png" />
        <ul class="dianji">
          <li>1.点击右上角的按钮</li>
          <li>2.选择在浏览器中打开</li>
          <li>3.下载掌悦理财APP</li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
import router from '../../router'
import Loading from '../Loading'
export default {
  name: 'activites',
  data() {
    return {
      prompt: "",
      show: false,
      acts: "int",
      arr: {
        int: require("../../assets/int.png"),
        act: require("../../assets/get.png"),
        lose1: require("../../assets/lose1.png"),
        lose3: require("../../assets/lose3.png"),
        lose4: require("../../assets/lose4.png")
      },
      showtishi:false,
      text:"",
      phone:"",
      amount:"",
      editshow:false,
      channelid: '999920170828234606'
    }
  },
  components: {
    Loading
  },
  methods: {
    edit(){
      router.push({ name: 'First', params: { data: JSON.stringify({ phone:this.phone})} })
    },
    goapp() {
      location.href = "static/downLoad.html?cid="+this.channelid;
      return
    },
    closeshade() {
      var timers = null;
      document.getElementById("html").className = ''
      this.showtishi = false;
    },
    promptshow(str) {
      clearTimeout(t);
      this.prompt = str
      var _this = this;
      this.show = true;
      var t = setTimeout(function () {
        _this.show = false;
      }, 2000)
    }
  },
  created(){
      Loading.show("加载中...");
      function getQueryString(name) {
				var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
				var r = window.location.search.substr(1).match(reg);
				if(r != null) return unescape(r[2]);
				return null;
      }
      try {
        global.boxOid = getQueryString("boxOid").split('/')[0]
      } catch (error) {
         if(getQueryString("code")!=90999){
            this.promptshow("请重新获取分享！！！")
         }
      }
      this.$http.post("/actives/activity/chocolateGet",{"data":{'boxOid':global.boxOid}}).then((response) => {
          Loading.hide()
          if(response.body.code==11){  //活动已结束
              this.acts = 'lose4'
              this.text = ""
              // this.phone = response.body.data.info.phone
              this.phone = ""
              this.editshow = false
              return
          }
          if(response.body.code==10){  //活动未开始
              this.acts = 'int'
              this.text = "活动尚未开始"
              this.phone = ""
              this.editshow = false
              return
          }
          if(response.body.code==10001){  //未登录或登陆失效
              router.push({ name: 'First', params: { data: "{}" } })
              return
          }
          if(response.body.code==88){  //非第一次领取盒子
              this.acts = 'act'
              this.amount = response.body.data.info.amount
              this.phone = response.body.data.info.phone
              this.editshow = true
              this.promptshow("你已领取过该盒巧克力啦！")
              this.text = "已存入你的巧克力账户："
               return
          } 
          if(response.body.code==66){  //盒子已经被领完
              this.acts = 'lose1'
              this.text = "领取手机号："
              this.editshow = true
              this.phone = response.body.data.info.phone
               return
          }
          if(response.body.code==33){  //今日领取已达上限
              this.acts = 'lose3'
              this.text = "领取手机号："
              this.editshow = true
              this.phone = response.body.data.info.phone
               return
          }
          if(response.body.code==10000){
              this.acts = 'act'
              this.amount = response.body.data.info.amount
              this.phone = response.body.data.info.phone
              this.text = "已存入你的巧克力账户："
              this.editshow = true
          }else{
              this.promptshow(response.body.message)
          }
      })
	}
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang='scss'>
@import "../../style/utils.scss";
.activites {
  position: relative;
  text-align: center;
}
.activites .bg {
  width: 7.1333rem;
  margin: 0 auto; // padding-top: 1.28rem;
  padding-top: 0.6667rem;
}

.account {
  height: 1.4267rem;
  line-height: 1.4267rem;
  padding-bottom: 0.1067rem;
  @include font-dpr(12px);
  color: #fee9b7;
}

.account .num {
  color: #e25858;
}

#edit {
  color: #e25858;
  padding-left: 0.16rem;
  text-decoration: underline; // border-bottom:1px solid #e25858;
}

.activites .goapp {
  width: 7.1333rem;
  margin: 0 auto;
}

.money {
  text-align: center;
  position: absolute;
  top: 1.84rem;
  width: 100%;
  color: #c22900;
  @include font-dpr(58px);
  margin: 0 auto;
}
.money span{
  margin-left: 0.04rem;
  @include font-dpr(18px);
}
.tishi {
  width: 100%;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 100;
}

.shade {
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, .7);
}

.jiantou {
  width: 4.9rem;
  height: 4.84rem;
  position: absolute;
  top: .4rem;
  right: .41rem;
}

.dianji {
  // padding: 5.66rem 0 0 2.25rem;
  padding-top: 5.66rem;
  margin: 0 auto;
}

.dianji li {
  color: #fff;
  @include font-dpr(20px);
  margin-bottom: 2.05rem;
}
.prompt {
  position: absolute;
  text-align: center;
  background: rgba(0, 0, 0, .5);
  color: #FFFFFF;
  width: 60%;
  height: 1.2rem;
  line-height: 1.2rem;
  top: 40%;
  left: 20%;
  @include font-dpr(14px);
}
</style>
