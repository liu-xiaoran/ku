//判断设备类型和浏览器环境
function ue() {
    var e = navigator.userAgent.toLowerCase();
    return {
        iphone: /iphone/.test(e),
        android: /android/.test(e),
        winphone: /windows phone/.test(e),
        weixin: /micromessenger/.test(e),
        qqnews: /qqnews/.test(e),
        mqqbrowser: /mqqbrowser/.test(e),
        qq: /\sqq/.test(e)
    }
}
function _down(){
    if (ue().iphone == true) {
        // location.href = 'https://itunes.apple.com/app/id1203692435';
        location.href = 'https://lnk0.com/I58ENp';
   } else if (ue().android == true) {
        var _url=window.cid.substr(0,12)+"4"+window.cid.substring(13);
        location.href = '/app/'+_url+'.apk';
    }
}
//下载app
$(".down,.downs,.down_btn").on("touchend", function () {
	if(ue().weixin == true) {
		$(".shade_box").show();
		$(".shade").show();
		$("html,body").addClass("ovfHiden");
	} else {
		_down();
	}
})

var timers = null;
$(".shade").on("touchend",function() {
	$(this).hide();
	$("html,body").removeClass("ovfHiden");
	timers = setTimeout(function() {
		$(".shade_box").hide();
		if($(".shade_box").css("display") == "none") {
			clearTimeout(timers);
		}
	},100)
})

if(!ue().weixin){
    if (ue().iphone == true) {
       setTimeout(function(){
            _down();
        },1000); 
    }else{
        _down();
    }
}

$(function(){

if(ue().weixin == true) {
    $(".shade_box").show();
    $(".shade").show();
    $("html,body").addClass("ovfHiden");
} else {
    _down();
}

})

