var AccountMyCoupon = function () {
	return this;
}

AccountMyCoupon.prototype = {
	init: function () {
		this.pageInit();
	},
	pageInit: function () {
		var _this = this
        //增加点击事件
        $(document).on("click",'#timeconClick',function(){
            if ($(this).attr("couponType") == "REDPACKETS") {
				//现金红包
				GHutils.load({
                    url: "/zybusiness/coupon/useRedPacket",
                    data: {
                        ucId: $(this).attr("data-uid")
                    },
                    type: 'post',
                    callback: function (result) {
						if(result.code == 10000) {
							$(".couponModeTitle").html("领取成功")
							$(".couponModeText").html("红包将自动进入账户余额")
							$(".couponMode").show()
						}
                    }
                })
			}else if($(this).attr("couponType") == "TASTECOUPON"){
				//体验金
				GHutils.load({
                    url: "/zybusiness/coupon/useTasteCoupon",
                    data: {
                        ucId: $(this).attr("data-uid")
                    },
                    type: 'post',
                    callback: function (result) {
						if(result.code == 10000) {
                            $(".couponModeTitle").html("使用成功")
							$(".couponModeText").html("次日起，体验金派息将自动进入账户余额")
							$(".couponMode").show()
						}
                    }
                })
			}else{
				window.location.href = 'product-tn-list.html'
			}

		})
		//领取红包或体验金后的点击事件
		$(document).on("click",'.couponModeBtn',function(){
			$(".couponMode").hide()
			location.reload()
		})
		_this.getRecords(1, 'NOTUSED', true)
		_this.getRecords(1, 'USED', true)
		_this.getRecords(1, 'EXPIRED', true)
	},
	getRecords: function (page, status, isFlag) {
		var _this = this
		GHutils.load({
			url: "/zybusiness/coupon/myCoupon",
			data: {
				couponStatus: status,
				pageInfo: {
					pageSize: 6,
					pageNo: page
				}
			},
			type: 'post',
			// loginStatus: function (resp) {
			// 	GHutils.loginOut(true)
			// },
			callback: function (result) {
				var couponstr = ''
				if (result.data.list) {
					GHutils.forEach(result.data.list, function (idx, coupon) {
						couponstr += joincoupon(coupon, status)
					})
				} else {
					couponstr += '<img style="margin-top: 80px" src="static/images/app-nodata1.png" alt="暂无收益_掌悦理财" />'
				}
				hasONoData(couponstr, status)
				var listTotalSize = [];
				GHutils.forEach(result.data.list, function (idx,coupon) {
					listTotalSize.push(coupon)
				})
				$('.' + status.toLocaleLowerCase() + '_total').html(result.data.pageInfo.totalSize)
				if (isFlag) {
					_this.createPage(result.data.pageInfo.totalPage, status)
				}
			},
			errcallback: function (error) {

			}
		})

		function joincoupon(coupon, status) {

			var couponAmount = 0;
			if (coupon.couponAmount == null) {
				couponAmount = 0;
			} else {
				couponAmount = coupon.couponAmount;
			}
			var timecon = "";
			if (status == 'NOTUSED') {
				timecon = "可使用";
			} else if (status == 'USED') {
				timecon = "已使用";
			} else if (status == 'EXPIRED') {
				timecon = "已失效";
			}
			var couponClass = ''  //代金券样式
			var timeconClass = ''   //可使用按钮的样式

			var str = ""


			if (status == 'NOTUSED') {
				if(coupon.couponType.toLowerCase() == 'REDPACKETS'.toLowerCase()) {
                    timecon = "可领取";
				}
				if (coupon.couponType.toLowerCase() == 'RATECOUPON'.toLowerCase()) {
					//现金红包
					couponClass = 'content-couponjiaxi';
					timeconClass = 'timeconjiaxi'

					strTo()
				}else if(coupon.couponType.toLowerCase() == 'TASTECOUPON'.toLowerCase()){
					couponClass = 'content-coupontiyan';
					timeconClass = 'timecontiyan'
					//体验金样式略微不同
					tiyanjinStr()

				} else {
					//代金券加息券
					couponClass = 'content-coupon';
					timeconClass = 'timecon'	
					strTo()
					//体验金

				}
			} else {
				//不可使用
				couponClass = 'content-couponguoqi';
				timeconClass = 'timeconguoqi'
				strTo()
				
				if(coupon.couponType.toLowerCase() == 'TASTECOUPON'.toLowerCase()){
					tiyanjinStr()
				}

				
			}

			function tiyanjinStr(){
				str = '<li class="col-xs-4"><div class="' + couponClass + '"><div class="coupon-header coupon-headers">' +
				coupon.couponAmount + '<i class="yuan">' + (coupon.couponType.toLowerCase() == 'RATECOUPON'.toLowerCase() ? '%' : '元') + '</i><div class="tiyanjin">' +
				coupon.couponTypeCh + '</div></div><div class="body-coupon"><p style="margin-bottom: 10px;font-weight: 600;">' +
				coupon.name + '</p><p style="margin-bottom: 5px;">年化利率：' +
				coupon.yearRate +'</p><p>计息天数：' +
				coupon.incomeDays + '天</p><p style="margin-bottom: 10px;">' +
				GHutils.formatTimestamp({
					time: coupon.effectTime,
					showtime: "true"
				}) + ' 至 ' + GHutils.formatTimestamp({
					time: coupon.expireTime,
					showtime: "true"
				}) +
				'</p><p id='+(status=='NOTUSED'?"timeconClick":"unclick")+' class="'+ timeconClass +'"couponType="'+coupon.couponType+ '" data-uid="'+coupon.ucId+'">' + timecon + '</p></div></div><p class="leadTime">发放时间 : ' +
				GHutils.formatTimestamp({
					time: coupon.lenderTime,
					showtime: "false"
				}) + '</p></li>'

			}
			function strTo(){

			str = '<li class="col-xs-4"><div class="' + couponClass + '"><div class="coupon-header">' +
				couponAmount + '<i class="yuan">' + (coupon.couponType.toLowerCase() == 'RATECOUPON'.toLowerCase() ? '%' : '元') + '<span>' +
				coupon.couponTypeCh + '</span></i></div><div class="body-coupon"><p style="margin-bottom: 10px;font-weight: 600;">' +
				coupon.name + '</p><p style="margin-bottom: 5px;">' +
				joincouponRules(coupon) + '</p><p style="margin-bottom: 10px;">' +
				GHutils.formatTimestamp({
					time: coupon.effectTime,
					showtime: "true"
				}) + ' 至 ' + GHutils.formatTimestamp({
					time: coupon.expireTime,
					showtime: "true"
				}) +
				'</p><p class="rule">' +
				(!coupon.limitLabels ? (!coupon.isLimitLabel ? '全场适用' : '') : coupon.limitLabels.replace(/,/g, "/")) + '</p><p id='+(status=='NOTUSED'?"timeconClick":"unclick")+' class="' + timeconClass +'"couponType="'+coupon.couponType+ '" data-uid="'+coupon.ucId+'">' + timecon + '</p></div></div><p class="leadTime">发放时间 : ' +
				GHutils.formatTimestamp({
					time: coupon.lenderTime,
					showtime: "false"
				}) + '</p></li>'

			}
			return str
		}

		function joincouponRules(coup) {
			return (coup.limitInvestAmount == null ? '满0元可使用' : '满' + coup.limitInvestAmount + '元可使用')
		}

		function hasONoData(str, status) {
			$('#' + status.toLocaleLowerCase() + "-data").html(str)
		}

		function turnType(type) {
			if (type.toLowerCase() == 'redPackets'.toLowerCase()) {
				type = '红包'
			} else if (type.toLowerCase() == 'coupon'.toLowerCase()) {
				type = '代金券'
			} else if (type.toLowerCase() == 'rateCoupon'.toLowerCase()) {
				type = '加息券'
			} else {
				type = '优惠券'
			}
			return type;
		}

	},
	createPage: function (pageCount, status) {
		
		$("." + status.toLocaleLowerCase()).show()
		if (pageCount <= 1) {
			$("." + status.toLocaleLowerCase()).hide()
		}

		var _this = this;
		$("." + status.toLocaleLowerCase()).createPage({
			pageCount: pageCount,
			current: 1,
			backFn: function (page) {
				_this.getRecords(page, status, false);
			}
		});
	}
}

$(function () {
	new AccountMyCoupon().init();
})